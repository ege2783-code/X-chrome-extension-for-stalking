        let currentFilter = 'all';
        let currentView = 'home';
        let searchTimeout = null;
        let allUsersData = [];
        let currentLoadedPosts = [];
        const allLoadedPostsMap = {};
        let previousProfileUser = null;
        let previousSearchQuery = "";
        let previousSearchTab = "top";
        let activeDetailPostId = null;
        let selectedUsername = 'all';
        let allLogsData = [];
        let currentProfileFilter = 'all';
        let activeMenuTweet = null;
        let activeProfileUsername = '';
        let profileCachedPosts = [];

        // 2 Dakikalık Kesintisiz Otomatik Yenileme Zamanlayıcısı (Sekme arka planda kalsa dahi şaşmaz)
        let autoRefreshIntervalSec = 120;
        let nextAutoRefreshTime = Date.now() + (autoRefreshIntervalSec * 1000);
        function resetAutoRefreshCountdown() {
            nextAutoRefreshTime = Date.now() + (autoRefreshIntervalSec * 1000);
            updateTimerDisplay(autoRefreshIntervalSec);
        }
        function updateTimerDisplay(remainingSec) {
            const timerEl = document.getElementById('autoRefreshTimerText');
            if (timerEl) {
                const m = Math.floor(remainingSec / 60);
                const s = remainingSec % 60;
                timerEl.innerText = `${m}:${s < 10 ? '0' : ''}${s}`;
            }
        }
        function startAutoRefreshTimer() {
            resetAutoRefreshCountdown();
            setInterval(() => {
                const now = Date.now();
                const remainingSec = Math.max(0, Math.ceil((nextAutoRefreshTime - now) / 1000));
                updateTimerDisplay(remainingSec);
                if (remainingSec <= 0) {
                    nextAutoRefreshTime = Date.now() + (autoRefreshIntervalSec * 1000);
                    refreshAll(true);
                }
            }, 1000);
        }

        // Kendi Hesabını Tanımlama Fonksiyonları
        function getMyAccountHandle() {
            return (localStorage.getItem('my_user_handle') || '').trim();
        }

        function setMyAccountHandle(handle) {
            localStorage.setItem('my_user_handle', handle.trim().replace(/^@/, '').toLowerCase());
            updateBottomLeftProfile();
        }

        function openSetMyAccountModal() {
            const current = getMyAccountHandle();
            const input = document.getElementById('myAccountNickInput');
            if (input) input.value = current;
            openModal('setMyAccountModal');
            setTimeout(() => input?.focus(), 100);
        }

        async function saveMyAccountNick() {
            const input = document.getElementById('myAccountNickInput');
            const nick = (input?.value || '').trim().replace(/^@/, '').toLowerCase();
            if (!nick) {
                alert("Lütfen geçerli bir kullanıcı adı girin.");
                return;
            }
            setMyAccountHandle(nick);
            closeModal('setMyAccountModal');
                closeActivityPredictionModal();

            // Eğer hesap henüz takip edilenlerde yoksa otomatik ekle
            const exists = allUsersData.some(x => x.username.toLowerCase() === nick);
            if (!exists) {
                await fetch('/api/users', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username: nick })
                });
            }

            showToast(`@${nick} stalk hedefi olarak tanımlandı!`);
            loadUsers();
            navigateTo('profile');
            renderProfileView(nick);
            autoPollProfileUntilLoaded(nick);
        }
        function setAsMyAccount(handle) {
            setMyAccountHandle(handle);
            showToast(`@${handle} stalk hedefi olarak tanımlandı!`);
            renderProfileView(handle);
            autoPollProfileUntilLoaded(handle);
        }

        function clearMyAccountHandle() {
            localStorage.removeItem('my_user_handle');
            updateBottomLeftProfile();
            showToast("Tanımlı hedef kişi kaldırıldı.");
            if (currentView === 'profile') {
                renderMyProfileEmptyState();
            }
        }

        function updateBottomLeftProfile() {
            const myHandle = getMyAccountHandle();
            const myAvatar = document.getElementById('myAvatarImg');
            const myName = document.getElementById('myDisplayName');
            const myHandleEl = document.getElementById('myHandle');
            const compAvatar = document.getElementById('composerAvatarImg');

            if (!myHandle) {
                if (myName) myName.innerText = 'Hedef Kişi Tanımla';
                if (myHandleEl) myHandleEl.innerText = 'Stalklanacak @kullanıcıyı seç';
                if (myAvatar) {
                    delete myAvatar.dataset.remote;
                    handleAvatarError(myAvatar, 'X');
                }
                if (compAvatar) {
                    delete compAvatar.dataset.remote;
                    handleAvatarError(compAvatar, 'X');
                }
                return;
            }

            const matchedUser = allUsersData.find(x => x.username.toLowerCase() === myHandle.toLowerCase());
            if (matchedUser) {
                if (myName) myName.innerText = matchedUser.display_name || matchedUser.username;
                if (myHandleEl) myHandleEl.innerText = `@${matchedUser.username}`;
                if (myAvatar && matchedUser.avatar_url) myAvatar.src = matchedUser.avatar_url;
                if (compAvatar && matchedUser.avatar_url) compAvatar.src = matchedUser.avatar_url;
            } else {
                if (myName) myName.innerText = myHandle;
                if (myHandleEl) myHandleEl.innerText = `@${myHandle}`;
            }
        }

        // Yerel Yer İmleri (Bookmarks) & Kişisel Arşiv Notları Yöneticisi (O(1) Bellek Önbellekli)
        let _bookmarksCache = null;
        let _bookmarksSet = new Set();
        let _postNotesCache = null;

        function invalidateLocalMetaCaches() {
            _bookmarksCache = null;
            _bookmarksSet = new Set();
            _postNotesCache = null;
        }

        function getBookmarks() {
            if (_bookmarksCache !== null) return _bookmarksCache;
            try {
                const parsed = JSON.parse(localStorage.getItem('x_bookmarks') || '[]');
                _bookmarksCache = Array.isArray(parsed) ? parsed : [];
            } catch(e) {
                _bookmarksCache = [];
            }
            _bookmarksSet = new Set(_bookmarksCache);
            return _bookmarksCache;
        }

        function isPostBookmarked(postId) {
            getBookmarks();
            return _bookmarksSet.has(postId);
        }

        function setBookmarks(arr) {
            _bookmarksCache = Array.isArray(arr) ? arr : [];
            _bookmarksSet = new Set(_bookmarksCache);
            localStorage.setItem('x_bookmarks', JSON.stringify(_bookmarksCache));
        }

        function syncBookmarkIcons(postId) {
            const isSaved = isPostBookmarked(postId);
            document.querySelectorAll(`[data-bookmark-post="${postId}"]`).forEach(icon => {
                icon.className = isSaved ? 'fa-solid fa-bookmark text-[#1d9bf0]' : 'fa-regular fa-bookmark';
            });
            if (activeDetailPostId === postId) {
                const heroIcon = document.getElementById('heroBookmarkIcon');
                const heroBtn = document.getElementById('heroBookmarkBtn');
                if (heroIcon) heroIcon.className = isSaved ? 'fa-solid fa-bookmark text-[#1d9bf0]' : 'fa-regular fa-bookmark';
                if (heroBtn) heroBtn.classList.toggle('text-[#1d9bf0]', isSaved);
            }
        }

        function toggleBookmark(postId) {
            const b = getBookmarks().slice();
            const idx = b.indexOf(postId);
            if (idx > -1) {
                b.splice(idx, 1);
                showToast("Yer İmlerinden kaldırıldı");
            } else {
                b.push(postId);
                showToast("Yer İmlerine eklendi");
            }
            setBookmarks(b);
            syncBookmarkIcons(postId);
            if (currentView === 'bookmarks') {
                renderBookmarksView();
            }
        }

        function getPostNotes() {
            if (_postNotesCache !== null) return _postNotesCache;
            try {
                const raw = JSON.parse(localStorage.getItem('x_post_notes') || '{}');
                _postNotesCache = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
            } catch {
                _postNotesCache = {};
            }
            return _postNotesCache;
        }

        function getPostNote(postId) {
            if (!postId) return '';
            const notes = getPostNotes();
            return typeof notes[postId] === 'string' ? notes[postId] : '';
        }

        function setPostNote(postId, text) {
            if (!postId) return;
            const notes = getPostNotes();
            const clean = (text || '').trim();
            if (clean) {
                notes[postId] = clean;
            } else {
                delete notes[postId];
            }
            localStorage.setItem('x_post_notes', JSON.stringify(notes));
        }

        // ================= MEDYA OPTİMİZASYONU (TIKLAYINCA YÜKLE) =================
        function isAutoLoadMediaEnabled() {
            return localStorage.getItem('x_auto_load_media') === '1';
        }

        function toProxyMediaUrl(url) {
            if (!url || typeof url !== 'string') return '';
            return url;
        }

        function stopCardEvent(event) {
            if (event) event.stopPropagation();
        }

        function openPostDetailStop(event, postId) {
            if (event) {
                event.stopPropagation();
                event.preventDefault();
            }
            if (postId) openTweetDetail(postId);
        }

        function handleMediaImgError(img) {
            if (!img) return;
            if (img.dataset.proxy && img.src !== img.dataset.proxy && !img.dataset.triedProxy) {
                img.dataset.triedProxy = '1';
                img.src = img.dataset.proxy;
                return;
            }
            if (img.dataset.hideOnError === '1') {
                img.style.display = 'none';
            }
        }

        function handleMediaVideoError(vid) {
            if (!vid) return;
            if (vid.dataset.proxy && vid.src !== vid.dataset.proxy && !vid.dataset.triedProxy) {
                vid.dataset.triedProxy = '1';
                vid.src = vid.dataset.proxy;
                vid.load();
            }
        }

        function syncAutoLoadMediaUI() {
            const autoOn = isAutoLoadMediaEnabled();
            const btn = document.getElementById('btnMediaSaverToggle');
            const icon = document.getElementById('mediaSaverIcon');
            const label = document.getElementById('mediaSaverLabel');
            const moreState = document.getElementById('moreMenuMediaState');
            const modalBadge = document.getElementById('mediaOptStatusBadge');
            const modalBtn = document.getElementById('btnModalMediaModeToggle');

            if (btn) {
                btn.className = autoOn
                    ? 'flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border border-[#1d9bf0]/40 bg-[#1d9bf0]/10 text-[#1d9bf0] hover:bg-[#1d9bf0]/20 transition font-semibold'
                    : 'flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border border-[#00ba7c]/40 bg-[#00ba7c]/10 text-[#00ba7c] hover:bg-[#00ba7c]/20 transition font-semibold';
                btn.title = autoOn
                    ? 'Medyalar otomatik yükleniyor (Tıkla-Yükle tasarruf moduna geçmek için tıklayın)'
                    : 'Videolar ve fotoğraflar sadece tıklayınca yüklenir (Veri ve hız optimizasyonu)';
            }
            if (icon) {
                icon.className = autoOn ? 'fa-solid fa-images text-[11px]' : 'fa-solid fa-bolt text-[11px]';
            }
            if (label) {
                label.innerText = autoOn ? 'Oto Medya' : 'Tıkla-Yükle';
            }
            if (moreState) {
                moreState.innerText = autoOn ? 'Otomatik' : 'Tıkla-Yükle';
                moreState.className = autoOn ? 'text-[11px] font-bold text-[#1d9bf0]' : 'text-[11px] font-bold text-[#00ba7c]';
            }
            if (modalBadge) {
                modalBadge.innerText = autoOn ? 'Otomatik Yükleme Açık' : 'Tıkla-Yükle Aktif';
                modalBadge.className = autoOn
                    ? 'text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#1d9bf0]/15 text-[#1d9bf0] border border-[#1d9bf0]/30'
                    : 'text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#00ba7c]/15 text-[#00ba7c] border border-[#00ba7c]/30';
            }
            if (modalBtn) {
                modalBtn.innerText = autoOn ? 'Tıkla-Yükle Moduna Geç' : 'Otomatik Yüklemeyi Aç';
            }
        }

        async function loadMediaCacheStats() {
            const summaryEl = document.getElementById('mediaCacheSummaryText');
            if (!summaryEl) return;
            try {
                const res = await fetch('/api/media-settings');
                if (!res.ok) return;
                const data = await res.json();
                if (data.is_extension) {
                    summaryEl.innerText = 'Eklenti modu: Videolar ve fotoğraflar yerel diskte depolanmaz; yalnız tıklandığında yüklenir.';
                    const clearBtn = document.getElementById('btnClearMediaCache');
                    if (clearBtn) clearBtn.classList.add('hidden');
                    return;
                }
                const c = data.cache || {};
                const mb = Number(c.total_mb || 0).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                summaryEl.innerText = `Disk Önbelleği: ${mb} MB (${c.videos_count || 0} video, ${c.images_count || 0} görsel, ${c.avatars_count || 0} avatar)`;
            } catch {}
        }

        async function clearMediaCacheConfirm() {
            if (!confirm('Önbellekte indirilen video ve fotoğraflar silinsin mi? (Arşivlenen tüm tweetler ve silinen gönderi kayıtları korunur.)')) return;
            try {
                const res = await fetch('/api/media-cache/clear', { method: 'POST' });
                const data = await res.json();
                if (data.status === 'ok') {
                    showToast(`Önbellek temizlendi: ${data.removed_files || 0} dosya (${data.freed_mb || 0} MB) boşaltıldı.`);
                    loadMediaCacheStats();
                    refreshVisibleMediaView();
                } else {
                    showToast(data.detail || 'Önbellek temizlenemedi');
                }
            } catch {
                showToast('Önbellek temizlenirken hata oluştu');
            }
        }

        function refreshVisibleMediaView() {
            if (currentView === 'home') {
                loadPosts(false);
            } else if (currentView === 'profile' && activeProfileUsername) {
                filterProfileCachedPosts();
            } else if (currentView === 'explore') {
                renderExploreView();
            } else if (currentView === 'bookmarks') {
                renderBookmarksView();
            } else if (currentView === 'search') {
                setSearchTab(currentSearchTab);
            } else if (currentView === 'tweet' && activeDetailPostId) {
                openTweetDetail(activeDetailPostId);
            }
        }

        function toggleAutoLoadMedia() {
            const nextVal = !isAutoLoadMediaEnabled();
            localStorage.setItem('x_auto_load_media', nextVal ? '1' : '0');
            syncAutoLoadMediaUI();
            fetch('/api/media-settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ auto_download_media: nextVal })
            }).catch(() => {});

            if (nextVal) {
                loadAllDeferredMediaIn(document);
                showToast('Otomatik medya yükleme açıldı.');
            } else {
                refreshVisibleMediaView();
                showToast('Tıkla-Yükle aktif: İzlemeyeceğiniz video ve fotoğraflar artık otomatik yüklenmeyecek.');
            }
        }

        function loadDeferredPhotoCard(el, event) {
            if (event) {
                event.stopPropagation();
                event.preventDefault();
            }
            if (!el) return;
            if (el.dataset.loaded === '1') {
                const targetUrl = el.dataset.openUrl || el.querySelector('img')?.src;
                if (targetUrl) window.open(targetUrl, '_blank');
                return;
            }
            if (el.dataset.loading === '1') return;
            el.dataset.loading = '1';

            const src = el.dataset.src || '';
            const proxy = el.dataset.proxy || '';
            const alt = el.dataset.alt || 'Medya';
            const roundedClass = el.dataset.rounded || 'rounded-xl';
            const maxHClass = el.dataset.maxH || 'max-h-[380px]';
            const gridTile = el.dataset.gridTile === '1';
            const postId = el.dataset.postId || '';
            const hideOnError = el.dataset.hideOnError === '1';

            el.innerHTML = '';
            const loader = document.createElement('div');
            loader.className = 'absolute inset-0 flex items-center justify-center bg-black/50 pointer-events-none z-10';
            loader.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin text-lg text-[#1d9bf0]"></i>';
            el.appendChild(loader);

            const img = document.createElement('img');
            img.src = src || proxy;
            img.referrerPolicy = 'no-referrer';
            img.decoding = 'async';
            img.alt = alt;
            if (proxy) img.dataset.proxy = proxy;
            if (hideOnError) img.dataset.hideOnError = '1';
            img.className = gridTile
                ? 'w-full h-full object-cover group-hover:scale-102 transition duration-200'
                : `w-full h-full ${maxHClass} object-cover ${roundedClass} group-hover:scale-102 transition duration-200`;
            img.addEventListener('load', () => {
                loader.remove();
                el.dataset.loaded = '1';
                el.dataset.loading = '0';
                el.classList.remove('min-h-[130px]', 'p-4');
            });
            img.addEventListener('error', () => {
                if (img.dataset.proxy && img.src !== img.dataset.proxy && !img.dataset.triedProxy) {
                    img.dataset.triedProxy = '1';
                    img.src = img.dataset.proxy;
                    return;
                }
                loader.remove();
                el.dataset.loading = '0';
                if (hideOnError) {
                    el.style.display = 'none';
                } else {
                    el.innerHTML = '<div class="p-4 text-center text-xs text-[#71767b]"><i class="fa-regular fa-image text-lg mb-1 block"></i>Görsel yüklenemedi · Tekrar denemek için tıklayın</div>';
                }
            });
            el.appendChild(img);

            if (gridTile && postId) {
                const detailBtn = document.createElement('button');
                detailBtn.type = 'button';
                detailBtn.title = 'Gönderiye Git';
                detailBtn.className = 'absolute top-1.5 right-1.5 z-20 w-7 h-7 rounded-full bg-black/75 hover:bg-[#1d9bf0] text-white flex items-center justify-center text-[10px] transition';
                detailBtn.innerHTML = '<i class="fa-solid fa-up-right-from-square"></i>';
                detailBtn.addEventListener('click', (ev) => openPostDetailStop(ev, postId));
                el.appendChild(detailBtn);
            }
        }

        function activateDeferredVideoCard(el, event) {
            if (event) {
                event.stopPropagation();
                event.preventDefault();
            }
            if (!el) return;
            if (el.dataset.loaded === '1') return;

            const isPlayable = el.dataset.isPlayable === '1';
            const postId = el.dataset.postId || '';
            const vidSrc = el.dataset.vidSrc || '';
            const vidProxy = el.dataset.vidProxy || '';
            const poster = el.dataset.poster || '';
            const maxHClass = el.dataset.maxH || 'max-h-[380px]';
            const roundedClass = el.dataset.rounded || 'rounded-xl';

            if (!isPlayable || !vidSrc) {
                if (postId) playInlineVideo(el, postId, poster, event);
                return;
            }

            el.dataset.loaded = '1';
            el.removeAttribute('onclick');
            el.onclick = stopCardEvent;
            el.setAttribute('data-ext-click', 'stopCardEvent(event)');
            el.className = `relative bg-black flex items-center justify-center overflow-hidden ${roundedClass} ${maxHClass}`;
            el.innerHTML = '';

            const vid = document.createElement('video');
            vid.src = vidSrc;
            if (vidProxy) vid.dataset.proxy = vidProxy;
            if (poster) vid.poster = poster;
            vid.controls = true;
            vid.autoplay = true;
            vid.playsInline = true;
            vid.preload = 'none';
            vid.className = `w-full ${maxHClass} object-contain ${roundedClass}`;
            vid.addEventListener('error', () => handleMediaVideoError(vid));
            el.appendChild(vid);
            vid.play().catch(() => {});
        }

        function loadAllDeferredMediaIn(rootOrId) {
            const root = typeof rootOrId === 'string' ? document.getElementById(rootOrId) : (rootOrId || document);
            if (!root) return;
            root.querySelectorAll('[data-deferred-media="image"]').forEach(card => {
                if (card.dataset.loaded !== '1') loadDeferredPhotoCard(card);
            });
            root.querySelectorAll('[data-deferred-media="video"]').forEach(card => {
                if (card.dataset.isPlayable === '1' && card.dataset.loaded !== '1') {
                    // Otomatik moda geçildiğinde videoları sadece kontrollerle hazır hale getir (autoplay başlatma)
                    const vidSrc = card.dataset.vidSrc || '';
                    const vidProxy = card.dataset.vidProxy || '';
                    const poster = card.dataset.poster || '';
                    const maxHClass = card.dataset.maxH || 'max-h-[380px]';
                    const roundedClass = card.dataset.rounded || 'rounded-xl';
                    card.dataset.loaded = '1';
                    card.removeAttribute('onclick');
                    card.onclick = stopCardEvent;
                    card.setAttribute('data-ext-click', 'stopCardEvent(event)');
                    card.className = `relative bg-black flex items-center justify-center overflow-hidden ${roundedClass} ${maxHClass}`;
                    card.innerHTML = '';
                    const vid = document.createElement('video');
                    vid.src = vidSrc;
                    if (vidProxy) vid.dataset.proxy = vidProxy;
                    if (poster) vid.poster = poster;
                    vid.controls = true;
                    vid.playsInline = true;
                    vid.preload = 'none';
                    vid.className = `w-full ${maxHClass} object-contain ${roundedClass}`;
                    vid.addEventListener('error', () => handleMediaVideoError(vid));
                    card.appendChild(vid);
                }
            });
        }

        function buildSingleMediaCardHtml(m, opts = {}) {
            const postId = String(opts.postId || '');
            const maxHClass = opts.maxHClass || 'max-h-[380px]';
            const roundedClass = opts.roundedClass || 'rounded-xl';
            const altLabel = opts.altLabel || 'Medya';
            const gridTile = Boolean(opts.gridTile);
            const hideOnError = Boolean(opts.hideOnError);
            const index = opts.index || 0;
            const total = opts.total || 1;
            const autoLoad = isAutoLoadMediaEnabled();

            const rawSrc = typeof m === 'string' ? m : (m.local_url || m.url || m.remote_url || '');
            if (!rawSrc) return '';
            const remoteFallback = typeof m === 'object' ? (m.remote_url || m.url || '') : rawSrc;
            const safeImgProxy = toProxyMediaUrl(remoteFallback);
            const posterSrc = typeof m === 'object' ? (m.poster || m.remote_poster || '') : '';
            const safePosterProxy = toProxyMediaUrl(posterSrc);
            const isPlayableVideo = (rawSrc.includes('.mp4') || rawSrc.includes('/media/videos/') || rawSrc.includes('video.twimg.com') || rawSrc.includes('.m3u8')) && !rawSrc.match(/\.(jpg|jpeg|png|webp|gif)($|\?)/i);
            const isVideoThumb = (!isPlayableVideo) && ((typeof m === 'object' && (m.type === 'video' || m.is_video_thumb)) || rawSrc.includes('video_thumb') || rawSrc.includes('amplify_video_thumb'));
            const isLocallyCached = rawSrc.startsWith('/media/');

            if (isPlayableVideo) {
                const vidLocal = typeof m === 'object' ? (m.local_url || '') : (rawSrc.startsWith('/media/') ? rawSrc : '');
                const vidRemote = typeof m === 'object' ? (m.remote_url || m.url || '') : rawSrc;
                const vidSrc = vidLocal || rawSrc;
                const safeVidProxy = vidRemote.startsWith('http') ? toProxyMediaUrl(vidRemote) : (vidLocal || vidRemote);
                const effPoster = posterSrc ? (posterSrc.startsWith('http') ? safePosterProxy : posterSrc) : '';

                if (!autoLoad) {
                    const boxCls = gridTile
                        ? 'aspect-square bg-[#121418] overflow-hidden cursor-pointer relative group flex flex-col items-center justify-center p-2 text-center hover:bg-[#1a1e24] transition border border-[#2f3336]/60'
                        : `relative overflow-hidden group cursor-pointer bg-[#121418] hover:bg-[#1a1e24] border border-[#2f3336]/80 ${roundedClass} min-h-[145px] ${maxHClass} flex flex-col items-center justify-center p-5 text-center transition`;
                    return `
                        <div data-deferred-media="video"
                             data-post-id="${escapeHtml(postId)}"
                             data-vid-src="${escapeHtml(vidSrc)}"
                             data-vid-proxy="${escapeHtml(safeVidProxy)}"
                             data-poster="${escapeHtml(effPoster)}"
                             data-is-playable="1"
                             data-max-h="${escapeHtml(maxHClass)}"
                             data-rounded="${escapeHtml(roundedClass)}"
                             class="${boxCls}"
                             data-ext-click="activateDeferredVideoCard(this, event)">
                            ${gridTile && postId ? `<button type="button" data-ext-click="openPostDetailStop(event, '${escapeJsArg(postId)}')" class="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-black/75 hover:bg-[#1d9bf0] text-white flex items-center justify-center text-[10px] transition" title="Gönderiye Git"><i class="fa-solid fa-up-right-from-square"></i></button>` : ''}
                            <div class="w-11 h-11 rounded-full bg-[#1d9bf0]/15 border border-[#1d9bf0]/40 text-[#1d9bf0] flex items-center justify-center mb-2 group-hover:scale-110 transition">
                                <i class="fa-solid fa-play text-sm ml-0.5"></i>
                            </div>
                            <div class="text-xs font-bold text-[#e7e9ea]">Video${gridTile ? '' : ' · Yükle ve Oynat'}</div>
                            <div class="text-[10px] text-[#71767b] mt-0.5">${isLocallyCached ? 'Yerel önbellekte hazır · Tıkla' : 'Otomatik yükleme kapalı · Tıkla'}</div>
                        </div>
                    `;
                }

                const vidContainerCls = gridTile
                    ? 'aspect-square bg-black overflow-hidden cursor-pointer relative'
                    : `relative bg-black flex items-center justify-center overflow-hidden ${roundedClass} ${maxHClass}`;
                const vidCls = gridTile ? 'w-full h-full object-cover' : `w-full ${maxHClass} object-contain ${roundedClass}`;
                return `
                    <div class="${vidContainerCls}" data-ext-click="stopCardEvent(event)">
                        <video src="${escapeHtml(vidSrc)}" data-proxy="${escapeHtml(safeVidProxy)}" poster="${escapeHtml(effPoster)}" preload="none" playsinline controls class="${vidCls}" data-ext-error="handleMediaVideoError(this)"></video>
                    </div>
                `;
            }

            if (isVideoThumb) {
                if (!autoLoad) {
                    const thumbCls = gridTile
                        ? 'aspect-square bg-[#121418] overflow-hidden cursor-pointer relative group flex flex-col items-center justify-center p-2 text-center hover:bg-[#1a1e24] transition border border-[#2f3336]/60'
                        : `relative overflow-hidden group cursor-pointer bg-[#121418] hover:bg-[#1a1e24] border border-[#2f3336]/80 ${roundedClass} min-h-[145px] ${maxHClass} flex flex-col items-center justify-center p-5 text-center transition`;
                    return `
                        <div data-deferred-media="video"
                             data-post-id="${escapeHtml(postId)}"
                             data-vid-src=""
                             data-vid-proxy="${escapeHtml(safeImgProxy)}"
                             data-poster="${escapeHtml(safeImgProxy || rawSrc)}"
                             data-is-playable="0"
                             data-max-h="${escapeHtml(maxHClass)}"
                             data-rounded="${escapeHtml(roundedClass)}"
                             class="${thumbCls}"
                             data-ext-click="activateDeferredVideoCard(this, event)">
                            ${gridTile && postId ? `<button type="button" data-ext-click="openPostDetailStop(event, '${escapeJsArg(postId)}')" class="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-black/75 hover:bg-[#1d9bf0] text-white flex items-center justify-center text-[10px] transition" title="Gönderiye Git"><i class="fa-solid fa-up-right-from-square"></i></button>` : ''}
                            <div class="w-11 h-11 rounded-full bg-[#1d9bf0]/15 border border-[#1d9bf0]/40 text-[#1d9bf0] flex items-center justify-center mb-2 group-hover:scale-110 transition">
                                <i class="fa-solid fa-play text-sm ml-0.5"></i>
                            </div>
                            <div class="text-xs font-bold text-[#e7e9ea]">Video${gridTile ? '' : ' · Yükle ve Oynat'}</div>
                            <div class="text-[10px] text-[#71767b] mt-0.5">Kapak ve akış yalnız tıklayınca yüklenir</div>
                        </div>
                    `;
                }
                const autoThumbWrap = gridTile
                    ? 'aspect-square bg-black overflow-hidden cursor-pointer relative group'
                    : `relative overflow-hidden group cursor-pointer ${maxHClass} ${roundedClass} bg-black flex items-center justify-center`;
                return `
                    <div class="${autoThumbWrap}" data-ext-click="activateDeferredVideoCard(this, event)" data-deferred-media="video" data-post-id="${escapeHtml(postId)}" data-is-playable="0" data-poster="${escapeHtml(safeImgProxy || rawSrc)}">
                        <img src="${escapeHtml(rawSrc)}" data-proxy="${escapeHtml(safeImgProxy)}" data-ext-error="handleMediaImgError(this)" loading="lazy" decoding="async" class="w-full h-full ${gridTile ? 'object-cover' : `${maxHClass} object-cover`} group-hover:scale-102 transition duration-200" alt="Video">
                        <div class="absolute inset-0 flex items-center justify-center bg-black/35 group-hover:bg-black/20 transition">
                            <div class="w-12 h-12 rounded-full bg-[#1d9bf0] hover:bg-[#1a8cd8] text-white flex items-center justify-center shadow-xl group-hover:scale-110 active:scale-95 transition">
                                <i class="fa-solid fa-play text-lg ml-0.5 text-white"></i>
                            </div>
                        </div>
                    </div>
                `;
            }

            // Fotoğraf / Görsel
            if (!autoLoad) {
                const countBadge = total > 1 ? ` (${index + 1}/${total})` : '';
                const photoBoxCls = gridTile
                    ? 'aspect-square bg-[#121418] overflow-hidden cursor-pointer relative group flex flex-col items-center justify-center p-2 text-center hover:bg-[#1a1e24] transition border border-[#2f3336]/60'
                    : `relative overflow-hidden group cursor-pointer bg-[#121418] hover:bg-[#1a1e24] border border-[#2f3336]/80 ${roundedClass} min-h-[120px] ${maxHClass} flex flex-col items-center justify-center p-4 text-center transition`;
                return `
                    <div data-deferred-media="image"
                         data-src="${escapeHtml(rawSrc)}"
                         data-proxy="${escapeHtml(safeImgProxy)}"
                         data-open-url="${escapeHtml(rawSrc)}"
                         data-alt="${escapeHtml(altLabel)}"
                         data-max-h="${escapeHtml(maxHClass)}"
                         data-rounded="${escapeHtml(roundedClass)}"
                         data-grid-tile="${gridTile ? '1' : '0'}"
                         data-post-id="${escapeHtml(postId)}"
                         data-hide-on-error="${hideOnError ? '1' : '0'}"
                         class="${photoBoxCls}"
                         data-ext-click="loadDeferredPhotoCard(this, event)">
                        ${gridTile && postId ? `<button type="button" data-ext-click="openPostDetailStop(event, '${escapeJsArg(postId)}')" class="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-black/75 hover:bg-[#1d9bf0] text-white flex items-center justify-center text-[10px] transition" title="Gönderiye Git"><i class="fa-solid fa-up-right-from-square"></i></button>` : ''}
                        <div class="w-9 h-9 rounded-full bg-white/[0.06] border border-[#2f3336] text-[#71767b] group-hover:text-[#1d9bf0] group-hover:border-[#1d9bf0]/40 flex items-center justify-center mb-1.5 transition">
                            <i class="fa-regular fa-image text-sm"></i>
                        </div>
                        <div class="text-xs font-semibold text-[#e7e9ea]">${escapeHtml(altLabel)}${countBadge}</div>
                        <div class="text-[10px] text-[#71767b] mt-0.5">${isLocallyCached ? 'Yerel önbellekte hazır · Tıkla' : 'Görüntülemek için tıkla'}</div>
                    </div>
                `;
            }

            const autoImgWrap = gridTile
                ? 'aspect-square bg-[#16181c] overflow-hidden cursor-pointer relative group'
                : `relative overflow-hidden group cursor-pointer ${roundedClass}`;
            return `
                <div class="${autoImgWrap}" data-ext-click="${gridTile && postId ? `openPostDetailStop(event, '${escapeJsArg(postId)}')` : `stopCardEvent(event); window.open('${escapeJsArg(rawSrc)}', '_blank')`}">
                    <img src="${escapeHtml(rawSrc)}" data-proxy="${escapeHtml(safeImgProxy)}" ${hideOnError ? 'data-hide-on-error="1"' : ''} data-ext-error="handleMediaImgError(this)" loading="lazy" decoding="async" class="w-full h-full ${gridTile ? 'object-cover' : `${maxHClass} object-cover`} group-hover:scale-102 transition duration-200" alt="${escapeHtml(altLabel)}">
                </div>
            `;
        }

        function buildMediaGalleryHtml(rawMedias, postId, opts = {}) {
            const cleanMedias = getDeduplicatedMedia(rawMedias);
            if (!cleanMedias.length) return '';
            const gridCols = cleanMedias.length >= 2 ? 'grid-cols-2' : 'grid-cols-1';
            const wrapCls = opts.wrapperClass || 'grid ' + gridCols + ' gap-2 rounded-2xl overflow-hidden mt-3 max-h-[450px] border border-[#2f3336]';
            const inner = cleanMedias.map((m, idx) => buildSingleMediaCardHtml(m, {
                postId,
                maxHClass: opts.maxHClass || 'max-h-[380px]',
                roundedClass: opts.roundedClass || 'rounded-xl',
                altLabel: opts.altLabel || 'Fotoğraf',
                hideOnError: Boolean(opts.hideOnError),
                index: idx,
                total: cleanMedias.length
            })).join('');
            return `<div class="${wrapCls}">${inner}</div>`;
        }

        function syncDetailNoteUI(postId) {
            const input = document.getElementById('detailReplyInput');
            const badge = document.getElementById('detailNoteSavedBadge');
            const clearBtn = document.getElementById('btnClearDetailNote');
            const note = getPostNote(postId);
            if (input) input.value = note;
            if (badge) badge.classList.toggle('hidden', !note);
            if (clearBtn) clearBtn.classList.toggle('hidden', !note);
        }

        function appendNoteTag(tag) {
            const input = document.getElementById('detailReplyInput');
            if (!input) return;
            const cur = input.value.trim();
            input.value = cur ? `${cur} ${tag}` : `${tag} `;
            input.focus();
        }

        function saveDetailArchiveNote() {
            if (!activeDetailPostId) return;
            const input = document.getElementById('detailReplyInput');
            const val = (input?.value || '').trim();
            setPostNote(activeDetailPostId, val);
            syncDetailNoteUI(activeDetailPostId);
            showToast(val ? "Kişisel arşiv notu kaydedildi" : "Arşiv notu temizlendi");
            if (currentView === 'bookmarks' && currentBookmarkTab === 'notes') {
                renderBookmarksView();
            }
        }

        function clearDetailArchiveNote() {
            if (!activeDetailPostId) return;
            setPostNote(activeDetailPostId, '');
            syncDetailNoteUI(activeDetailPostId);
            showToast("Arşiv notu silindi");
        }

        function focusDetailNote() {
            const input = document.getElementById('detailReplyInput');
            if (input) {
                input.focus();
                input.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }

        function copyDetailPostText(postId) {
            const post = allLoadedPostsMap[postId] || currentLoadedPosts.find(x => x.post_id === postId) || (typeof profileCachedPosts !== 'undefined' ? profileCachedPosts.find(x => x.post_id === postId) : null);
            const text = post?.content || '';
            if (!text) {
                showToast("Kopyalanacak metin bulunamadı");
                return;
            }
            navigator.clipboard.writeText(text).then(() => {
                showToast("Gönderi metni panoya kopyalandı");
            }).catch(() => {});
        }

        function triggerExploreLiveSearch() {
            const val = document.getElementById('exploreSearchInput')?.value?.trim() || '';
            if (val) {
                openSearchPage(val);
            } else {
                document.getElementById('exploreSearchInput')?.focus();
            }
        }

        function triggerImportJsonPicker() {
            document.getElementById('importJsonFileInput')?.click();
        }

        async function importJsonBackupFile(inputEl) {
            const file = inputEl?.files?.[0];
            if (!file) return;
            try {
                const rawText = await file.text();
                const parsed = JSON.parse(rawText);
                const res = await fetch('/api/import-json', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(parsed)
                });
                const data = await res.json().catch(() => ({}));
                if (!res.ok) throw new Error(data.detail || 'İçe aktarma başarısız');
                const imp = data.imported || {};
                showToast(`Yedek yüklendi: ${imp.posts ?? 0} gönderi, ${imp.users ?? 0} hesap`);
                closeModal('exportModal');
                refreshAll();
            } catch (e) {
                showToast(`Yedek yüklenemedi: ${e.message}`);
            } finally {
                inputEl.value = '';
            }
        }

        // ================= 1. SAYFA NAVİGASYON YÖNETİCİSİ =================
        function navigateTo(viewName) {
            currentView = viewName;

            const navItems = ['home', 'explore', 'notifications', 'lists', 'bookmarks', 'profile'];
            navItems.forEach(item => {
                const btn = document.getElementById(`nav-${item}`);
                if (btn) {
                    if (item === viewName) {
                        btn.classList.add('font-bold', 'text-white');
                        btn.classList.remove('text-[#e7e9ea]', 'font-normal');
                    } else {
                        btn.classList.remove('font-bold', 'text-white');
                        btn.classList.add('text-[#e7e9ea]', 'font-normal');
                    }
                }
            });

            document.querySelectorAll('.page-view').forEach(el => el.classList.add('hidden'));
            const targetView = document.getElementById(`view-${viewName}`);
            if (targetView) targetView.classList.remove('hidden');

            const homeTabs = document.getElementById('homeTabsContainer');
            const mainTitle = document.getElementById('mainHeaderTitle');
            const mainSub = document.getElementById('mainHeaderSubtitle');
            const backBtn = document.getElementById('mainBackBtn');

            if (backBtn) backBtn.classList.add('hidden');
            if (mainSub && viewName !== 'profile') mainSub.classList.add('hidden');

            const headerSearch = document.getElementById('headerSearchContainer');

            if (viewName === 'home') {
                if (homeTabs) homeTabs.classList.remove('hidden');
                if (mainTitle) { mainTitle.classList.remove('hidden'); mainTitle.innerText = 'Anasayfa'; }
                if (headerSearch) headerSearch.classList.add('hidden');
                loadPosts();
            } else if (viewName === 'tweet') {
                if (homeTabs) homeTabs.classList.add('hidden');
                if (headerSearch) headerSearch.classList.add('hidden');
                if (mainTitle) { mainTitle.classList.remove('hidden'); mainTitle.innerText = 'Gönderi'; }
                if (backBtn) backBtn.classList.remove('hidden');
            } else if (viewName === 'search') {
                if (homeTabs) homeTabs.classList.add('hidden');
                if (mainTitle) mainTitle.classList.add('hidden');
                if (headerSearch) headerSearch.classList.remove('hidden');
                if (backBtn) backBtn.classList.remove('hidden');
            } else {
                if (homeTabs) homeTabs.classList.add('hidden');
                if (headerSearch) headerSearch.classList.add('hidden');
                if (mainTitle) mainTitle.classList.remove('hidden');

                if (viewName === 'explore') {
                    if (mainTitle) mainTitle.innerText = 'Keşfet';
                    renderExploreView();
                } else if (viewName === 'notifications') {
                    if (mainTitle) mainTitle.innerText = 'Bildirimler';
                    const dot = document.getElementById('navNotifDot');
                    if (dot) dot.classList.add('hidden');
                    renderNotificationsView();
                } else if (viewName === 'lists') {
                    if (mainTitle) mainTitle.innerText = 'Listeler';
                    renderListsView();
                } else if (viewName === 'bookmarks') {
                    if (mainTitle) mainTitle.innerText = 'Yer İmleri';
                    renderBookmarksView();
                } else if (viewName === 'profile') {
                    if (mainTitle) mainTitle.innerText = 'Profilim';
                    const myHandle = getMyAccountHandle();
                    if (myHandle) {
                        renderProfileView(myHandle);
                    } else {
                        renderMyProfileEmptyState();
                    }
                }
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        // ================= 2. SEKME VE MAVİ ÇUBUK YÖNETİCİSİ =================
        function setFilter(filter) {
            currentFilter = filter;
            if (currentView !== 'home') {
                navigateTo('home');
            }
            const tabs = ['all', 'active', 'deleted'];
            tabs.forEach(t => {
                const btn = document.getElementById(t === 'all' ? 'tabAll' : (t === 'active' ? 'tabActive' : 'tabDeleted'));
                if (btn) {
                    const indicator = btn.querySelector('.tab-indicator');
                    if (t === filter) {
                        btn.classList.remove('text-[#71767b]', 'font-medium');
                        btn.classList.add('text-[#e7e9ea]', 'font-bold');
                        if (indicator) indicator.classList.remove('hidden');
                    } else {
                        btn.classList.remove('text-[#e7e9ea]', 'font-bold');
                        btn.classList.add('text-[#71767b]', 'font-medium');
                        if (indicator) indicator.classList.add('hidden');
                    }
                }
            });
            loadPosts();
        }

        // B) Profil Sekmeleri (Gönderiler, Aktif, Silinenler, Medya, Takip Edilen, Takipçiler)
        function setProfileTab(tabName) {
            currentProfileFilter = tabName;
            profileCursor = null;
            profileReachedEnd = false;
            const tabs = ['all', 'replies', 'reposts', 'media', 'deleted', 'following', 'followers'];
            tabs.forEach(t => {
                const btn = document.getElementById(`profTab_${t}`);
                if (btn) {
                    const indicator = btn.querySelector('.tab-indicator');
                    if (t === tabName) {
                        btn.classList.remove('text-[#71767b]', 'font-medium');
                        btn.classList.add('text-[#e7e9ea]', 'font-bold');
                        if (indicator) indicator.classList.remove('hidden');
                    } else {
                        btn.classList.remove('text-[#e7e9ea]', 'font-bold');
                        btn.classList.add('text-[#71767b]', 'font-medium');
                        if (indicator) indicator.classList.add('hidden');
                    }
                }
            });
            renderProfileSubContent();
        }

        // C) Bildirim Sekmeleri
        let currentNotifFilter = 'all';
        function filterNotifTab(type) {
            currentNotifFilter = type;
            const tabs = ['all', 'verified', 'mentions'];
            tabs.forEach(t => {
                const btn = document.getElementById(t === 'all' ? 'notifTabAll' : (t === 'verified' ? 'notifTabVer' : 'notifTabMen'));
                if (btn) {
                    const indicator = btn.querySelector('.tab-indicator');
                    if (t === type) {
                        btn.classList.remove('text-[#71767b]', 'font-medium');
                        btn.classList.add('text-[#e7e9ea]', 'font-bold');
                        if (indicator) indicator.classList.remove('hidden');
                    } else {
                        btn.classList.remove('text-[#e7e9ea]', 'font-bold');
                        btn.classList.add('text-[#71767b]', 'font-medium');
                        if (indicator) indicator.classList.add('hidden');
                    }
                }
            });
            renderNotificationsView();
        }

        // D) Yer İmleri Sekmeleri
        let currentBookmarkTab = 'deleted';
        function filterBookmarksTab(type) {
            currentBookmarkTab = type;
            const tabMap = { deleted: 'bmTabDeleted', saved: 'bmTabSaved', notes: 'bmTabNotes' };
            Object.entries(tabMap).forEach(([t, btnId]) => {
                const btn = document.getElementById(btnId);
                if (btn) {
                    const indicator = btn.querySelector('.tab-indicator');
                    if (t === type) {
                        btn.classList.remove('text-[#71767b]', 'font-medium');
                        btn.classList.add('text-[#e7e9ea]', 'font-bold');
                        if (indicator) indicator.classList.remove('hidden');
                    } else {
                        btn.classList.remove('text-[#e7e9ea]', 'font-bold');
                        btn.classList.add('text-[#71767b]', 'font-medium');
                        if (indicator) indicator.classList.add('hidden');
                    }
                }
            });
            renderBookmarksView();
        }

        // ================= 3. HER TWEET İÇİN 3 NOKTA MENÜSÜ =================
        function toggleTweetDropdown(event, postId, author) {
            event.stopPropagation();
            event.preventDefault();
            const dropdown = document.getElementById('tweetActionDropdown');
            if (!dropdown) return;

            if (activeMenuTweet && activeMenuTweet.postId === postId && !dropdown.classList.contains('hidden')) {
                dropdown.classList.add('hidden');
                activeMenuTweet = null;
                return;
            }

            activeMenuTweet = { postId, author };

            const unfollowText = document.getElementById('menuUnfollowText');
            if (unfollowText) unfollowText.innerText = `@${author} kullanıcısını takipten çık`;

            const bookmarks = getBookmarks();
            const isBookmarked = bookmarks.includes(postId);
            const bText = document.getElementById('menuBookmarkText');
            const bIcon = document.getElementById('menuBookmarkIcon');
            if (bText) bText.innerText = isBookmarked ? 'Yer İmlerinden Çıkar' : 'Yer İmlerine Ekle';
            if (bIcon) {
                bIcon.className = isBookmarked ? 'fa-solid fa-bookmark text-[#1d9bf0] w-5 text-center' : 'fa-regular fa-bookmark text-[#71767b] w-5 text-center';
            }

            const rect = event.currentTarget.getBoundingClientRect();
            dropdown.classList.remove('hidden');

            let top = rect.bottom + 6;
            let left = rect.right - 280;
            if (left < 10) left = 10;
            if (top + dropdown.offsetHeight > window.innerHeight) {
                top = rect.top - dropdown.offsetHeight - 6;
            }

            dropdown.style.top = `${top}px`;
            dropdown.style.left = `${left}px`;
        }

        async function execTweetAction(action) {
            const dropdown = document.getElementById('tweetActionDropdown');
            if (dropdown) dropdown.classList.add('hidden');
            if (!activeMenuTweet) return;

            const { postId, author } = activeMenuTweet;

            if (action === 'copy_link') {
                const link = `https://x.com/${author}/status/${postId}`;
                navigator.clipboard.writeText(link).then(() => {
                    showToast("Bağlantı panoya kopyalandı");
                }).catch(() => {
                    prompt("Bağlantıyı kopyalayabilirsiniz:", link);
                });
            } else if (action === 'open_x') {
                window.open(`https://x.com/${author}/status/${postId}`, '_blank');
            } else if (action === 'bookmark') {
                toggleBookmark(postId);
            } else if (action === 'refresh_user') {
                refreshUser(author);
            } else if (action === 'unfollow') {
                deleteUser(author);
            } else if (action === 'delete_archive') {
                if (confirm(`Gönderi (${postId}) yerel arşivden tamamen silinsin mi?`)) {
                    deleteSinglePost(postId);
                }
            }
        }

        async function deleteSinglePost(postId) {
            try {
                await fetch(`/api/posts/${postId}`, { method: 'DELETE' });
                showToast("Gönderi yerel arşivden silindi");
                refreshAll();
            } catch(e) {
                alert("Gönderi silinirken hata oluştu.");
            }
        }

        // ================= 4. CANLI X (TWITTER) GÜNDEMLERİ VE MENÜSÜ =================
        let activeTrends = [];
        let hiddenTrendKeywords = new Set((() => {
            try {
                const raw = JSON.parse(localStorage.getItem('x_hidden_trends') || '[]');
                return Array.isArray(raw) ? raw.map(x => String(x).toLowerCase()) : [];
            } catch { return []; }
        })());
        let selectedTrendForMenu = '';

        function saveHiddenTrends() {
            try {
                localStorage.setItem('x_hidden_trends', JSON.stringify(Array.from(hiddenTrendKeywords)));
            } catch {}
        }

        async function loadTrends() {
            const container = document.getElementById('trendsList');
            if (!container) return;

            try {
                const res = await fetch('/api/trends');
                if (!res.ok) throw new Error('Trend servisi hatası');
                const trends = await res.json();
                if (!trends || trends.length === 0) return;
                activeTrends = trends;
                renderTrends();
            } catch (e) {
                console.log("Trend verisi alınamadı:", e);
            }
        }

        function renderTrends() {
            const container = document.getElementById('trendsList');
            if (!container) return;

            const visibleTrends = activeTrends.filter(t => !hiddenTrendKeywords.has((t.keyword || t.name).toLowerCase()));
            let html = '';
            if (visibleTrends.length === 0) {
                html += '<div class="p-4 text-center text-xs text-[#71767b]">Tüm gündem başlıkları gizlenmiş veya yüklenemedi.</div>';
            } else {
                visibleTrends.slice(0, 6).forEach(t => {
                    const kw = (t.keyword || t.name);
                    const jsKw = escapeJsArg(kw);
                    const jsCat = escapeJsArg(t.category || '');
                    const jsCnt = escapeJsArg(t.tweet_count || '');
                    html += `
                        <div data-ext-click="searchTrend('${jsKw}', '${jsCat}', '${jsCnt}')" class="p-3.5 hover:bg-white/[0.03] transition cursor-pointer group">
                            <div class="text-xs text-[#71767b] flex justify-between items-center">
                                <span>${escapeHtml(t.category || 'Türkiye tarihinde gündemde')}</span>
                                <button data-ext-click="toggleTrendDropdown(event, '${jsKw}')" class="w-6 h-6 rounded-full hover:bg-white/10 flex items-center justify-center text-[#71767b]" title="Daha fazla"><i class="fa-solid fa-ellipsis"></i></button>
                            </div>
                            <div class="font-bold text-sm text-[#e7e9ea] group-hover:underline mt-0.5">${escapeHtml(t.name)}</div>
                            <div class="text-xs text-[#71767b] mt-0.5">${escapeHtml(t.tweet_count || '')}</div>
                        </div>
                    `;
                });
            }

            // Trendlerin altına yerel arşiv silinmişler göstergesi
            html += `
                <div data-ext-click="setFilter('deleted')" class="p-3.5 hover:bg-white/[0.03] transition cursor-pointer group">
                    <div class="text-xs text-[#71767b] flex justify-between items-center">
                        <span>Arşiv Etkinliği · Trend</span>
                        <button data-ext-click="toggleTrendDropdown(event, 'silinenler')" class="w-6 h-6 rounded-full hover:bg-white/10 flex items-center justify-center text-[#71767b]"><i class="fa-solid fa-ellipsis"></i></button>
                    </div>
                    <div class="font-bold text-sm text-[#e7e9ea] group-hover:underline mt-0.5">Silinmiş Gönderiler</div>
                    <div class="text-xs text-[#f4212e] mt-0.5" id="trendDeletedCount">0 silinmiş tespit</div>
                </div>
            `;
            container.innerHTML = html;

            // Keşfet ekranındaki hızlı etiket haplarını da canlı X gündemleriyle senkronize et
            const exploreTagsContainer = document.getElementById('exploreTrendingPills');
            if (exploreTagsContainer) {
                let pillsHtml = '';
                visibleTrends.slice(0, 5).forEach(t => {
                    const rawKw = t.keyword || t.name;
                    pillsHtml += `<button data-ext-click="searchTrend('${escapeJsArg(rawKw)}')" class="px-3 py-1.5 rounded-full bg-[#16181c] hover:bg-white/10 border border-[#2f3336] text-[#e7e9ea] font-medium transition shrink-0">${escapeHtml(rawKw)}</button>`;
                });
                pillsHtml += `<button data-ext-click="setFilter('deleted')" class="px-3 py-1.5 rounded-full bg-[#f4212e]/10 hover:bg-[#f4212e]/20 border border-[#f4212e]/30 text-[#f4212e] font-medium transition shrink-0">Silinen Tweetler</button>`;
                exploreTagsContainer.innerHTML = pillsHtml;
            }
        }

        function toggleTrendDropdown(event, keyword) {
            event.stopPropagation();
            selectedTrendForMenu = keyword;
            const dropdown = document.getElementById('trendActionDropdown');
            if (!dropdown) return;

            const rect = event.currentTarget.getBoundingClientRect();
            dropdown.classList.remove('hidden');
            dropdown.style.top = `${rect.bottom + 4}px`;
            dropdown.style.left = `${rect.right - 250}px`;
        }

        function execTrendAction(action) {
            const dropdown = document.getElementById('trendActionDropdown');
            if (dropdown) dropdown.classList.add('hidden');
            if (action === 'not_interested') {
                if (selectedTrendForMenu) hiddenTrendKeywords.add(selectedTrendForMenu.toLowerCase());
                saveHiddenTrends();
                renderTrends();
                showToast("Geri bildiriminiz alındı. Bu gündem daha az gösterilecek.");
            } else if (action === 'hide') {
                if (selectedTrendForMenu) hiddenTrendKeywords.add(selectedTrendForMenu.toLowerCase());
                saveHiddenTrends();
                renderTrends();
                showToast("Gündem başlığı akışınızdan gizlendi.");
            }
        }

        // ================= ARAMA SAYFASI VE X ARAMA MOTORU =================
        let currentSearchQuery = '';
        let currentSearchTab = 'top';
        let previousView = 'home';

        function searchTrend(keyword, category = '', count = '') {
            openSearchPage(keyword, category, count);
        }

        function openSearchPage(keyword, category = '', count = '') {
            document.getElementById('mainHeaderSubtitle')?.classList.add('hidden');
            if (currentView !== 'search') {
                previousView = currentView;
            }
            currentSearchQuery = (keyword || '').trim();
            recordTopicVisit(currentSearchQuery);

            navigateTo('search');

            const headerInput = document.getElementById('headerSearchInput');
            if (headerInput) headerInput.value = currentSearchQuery;

            const headerCard = document.getElementById('searchTrendHeaderCard');
            const catEl = document.getElementById('searchTrendCategory');
            const kwEl = document.getElementById('searchTrendKeyword');
            const volEl = document.getElementById('searchTrendVolume');
            const xBtn = document.getElementById('searchLiveXBtn');

            if (headerCard) {
                headerCard.classList.remove('hidden');
                if (catEl) catEl.innerText = category || 'Türkiye tarihinde gündemde';
                if (kwEl) kwEl.innerText = currentSearchQuery;
                if (volEl) volEl.innerText = count || 'Canlı X Gündemi';
                if (xBtn) xBtn.href = `https://x.com/search?q=${encodeURIComponent(currentSearchQuery)}`;
            }

            setSearchTab('top');
        }

        function clearHeaderSearch() {
            const input = document.getElementById('headerSearchInput');
            if (input) {
                input.value = '';
                input.focus();
            }
        }

        async function setSearchTab(tab) {
            currentSearchTab = tab;
            const tabs = ['top', 'latest', 'people', 'media'];
            tabs.forEach(t => {
                const btn = document.getElementById(`searchTab_${t}`);
                if (btn) {
                    const indicator = btn.querySelector('.tab-indicator');
                    if (t === tab) {
                        btn.classList.remove('text-[#71767b]');
                        btn.classList.add('text-[#e7e9ea]', 'font-bold');
                        if (indicator) indicator.classList.remove('hidden');
                    } else {
                        btn.classList.remove('text-[#e7e9ea]', 'font-bold');
                        btn.classList.add('text-[#71767b]');
                        if (indicator) indicator.classList.add('hidden');
                    }
                }
            });

            const feed = document.getElementById('searchResultsFeed');
            if (!feed) return;
            feed.innerHTML = `
                <div class="p-12 text-center text-[#71767b]">
                    <i class="fa-solid fa-spinner fa-spin text-2xl mb-3 text-[#1d9bf0]"></i>
                    <div class="text-sm">"${escapeHtml(currentSearchQuery)}" aranıyor...</div>
                </div>
            `;

            try {
                const res = await fetch(`/api/search?q=${encodeURIComponent(currentSearchQuery)}&tab=${tab}`);
                const data = await res.json();
                const results = data.results || [];

                if (Array.isArray(results)) {
                    results.forEach(p => {
                        if (p && p.post_id) allLoadedPostsMap[p.post_id] = p;
                    });
                }

                if (tab === 'people') {
                    if (results.length === 0) {
                        feed.innerHTML = `
                            <div class="p-12 text-center text-[#71767b]">
                                <i class="fa-regular fa-user text-3xl mb-3 text-[#2f3336]"></i>
                                <div class="text-sm font-semibold">"${escapeHtml(currentSearchQuery)}" ile eşleşen hesap bulunamadı</div>
                            </div>
                        `;
                    } else {
                        let html = '';
                        results.forEach(u => {
                            const initial = (u.username || 'U').charAt(0).toUpperCase();
                            html += `
                                <div class="p-4 hover:bg-white/[0.03] transition flex items-center justify-between gap-3 cursor-pointer" data-ext-click="renderProfileView('${escapeJsArg(u.username)}')">
                                    <div class="flex items-center gap-3 min-w-0">
                                        <img src="${u.avatar_url || ''}" loading="lazy" decoding="async" data-ext-error="handleAvatarError(this, '${escapeJsArg(initial)}')" class="w-10 h-10 rounded-full object-cover border border-[#2f3336] bg-[#16181c] shrink-0" alt="@${escapeHtml(u.username)}">
                                        <div class="min-w-0">
                                            <div class="font-bold text-sm text-[#e7e9ea] truncate hover:underline">${escapeHtml(u.display_name || u.username)}</div>
                                            <div class="text-xs text-[#71767b] truncate">@${escapeHtml(u.username)}</div>
                                            ${u.followers_count ? `<div class="text-[11px] text-[#71767b] mt-0.5">${Number(u.followers_count).toLocaleString('tr-TR')} Takipçi</div>` : ''}
                                        </div>
                                    </div>
                                    <button data-ext-click="event.stopPropagation(); renderProfileView('${escapeJsArg(u.username)}')" class="px-4 py-1.5 rounded-full bg-white text-black hover:bg-white/90 text-xs font-bold transition shrink-0">
                                        Profili Gör
                                    </button>
                                </div>
                            `;
                        });
                        feed.innerHTML = html;
                    }
                } else if (tab === 'media') {
                    let allMedia = [];
                    results.forEach(p => {
                        const cleanList = getDeduplicatedMedia(p.media_urls || []);
                        cleanList.forEach(m => {
                            allMedia.push({ media: m, post_id: p.post_id });
                        });
                    });
                    if (allMedia.length === 0) {
                        feed.innerHTML = `
                            <div class="p-12 text-center text-[#71767b]">
                                <i class="fa-regular fa-image text-3xl mb-3 text-[#2f3336]"></i>
                                <div class="text-sm font-semibold">"${escapeHtml(currentSearchQuery)}" ile ilgili medya bulunamadı</div>
                            </div>
                        `;
                    } else {
                        let toolbarHtml = '';
                        if (!isAutoLoadMediaEnabled()) {
                            toolbarHtml = `
                                <div class="px-3 py-2 bg-[#16181c] border-b border-[#2f3336] flex items-center justify-between gap-2 text-xs">
                                    <span class="text-[#71767b]"><i class="fa-solid fa-bolt text-[#00ba7c] mr-1"></i> ${allMedia.length} medya (otomatik yükleme kapalı)</span>
                                    <button type="button" data-ext-click="loadAllDeferredMediaIn('searchFeedList')" class="px-3 py-1 rounded-full bg-[#1d9bf0]/15 hover:bg-[#1d9bf0]/25 text-[#1d9bf0] font-bold transition">Hepsini Göster</button>
                                </div>
                            `;
                        }
                        let html = toolbarHtml + '<div class="grid grid-cols-3 gap-1 p-1">';
                        allMedia.forEach((entry, idx) => {
                            html += buildSingleMediaCardHtml(entry.media, {
                                postId: entry.post_id,
                                gridTile: true,
                                altLabel: 'Fotoğraf',
                                roundedClass: 'rounded-lg',
                                maxHClass: 'max-h-[260px]',
                                index: idx,
                                total: allMedia.length
                            });
                        });
                        html += '</div>';
                        feed.innerHTML = html;
                    }
                } else {
                    if (results.length === 0) {
                        feed.innerHTML = `
                            <div class="p-10 text-center">
                                <div class="w-14 h-14 rounded-full bg-[#1d9bf0]/10 text-[#1d9bf0] flex items-center justify-center mx-auto mb-3 text-xl">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </div>
                                <div class="text-lg font-bold text-[#e7e9ea] mb-1">"${escapeHtml(currentSearchQuery)}" için sonuç bulunamadı</div>
                                <p class="text-sm text-[#71767b] max-w-sm mx-auto mb-5 leading-relaxed">Bu arama veya gündem başlığı için canlı X tweetleri taranırken henüz bir gönderi bulunamadı. Yeniden aramayı deneyebilir veya X.com üzerinde canlı akışı görebilirsiniz.</p>
                                <div class="flex items-center justify-center gap-3 flex-wrap">
                                    <button data-ext-click="setSearchTab(currentSearchTab)" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#2f3336] hover:bg-[#3f4448] text-white text-xs font-bold transition">
                                        <i class="fa-solid fa-rotate-right"></i>
                                        <span>Yeniden Dene</span>
                                    </button>
                                    <a href="https://x.com/search?q=${encodeURIComponent(currentSearchQuery)}" target="_blank" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#1d9bf0] hover:bg-[#1a8cd8] text-white text-xs font-bold transition shadow-lg shadow-[#1d9bf0]/20">
                                        <i class="fa-brands fa-x-twitter text-sm"></i>
                                        <span>X.com'da Canlı Gönderileri Gör</span>
                                        <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                                    </a>
                                </div>
                            </div>
                        `;
                    } else {
                        renderPostsToContainer(results, feed, `"${escapeHtml(currentSearchQuery)}" için gönderi yok.`);
                    }
                }
            } catch (err) {
                console.error("Arama hatası:", err);
                feed.innerHTML = '<div class="p-8 text-center text-[#f4212e] text-sm">Arama sonuçları getirilirken bir hata oluştu.</div>';
            }
        }

        function debounceExploreSearch() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(renderExploreView, 250);
        }

        function debounceSearch() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(loadPosts, 250);
        }

        function renderHiddenTrendsList() {
            const container = document.getElementById('hiddenTrendsListContainer');
            if (!container) return;
            const list = Array.from(hiddenTrendKeywords);
            if (list.length === 0) {
                container.innerHTML = '<div class="p-4 rounded-xl bg-[#16181c] border border-[#2f3336] text-xs text-[#71767b] text-center">Şu anda gizlenmiş gündem başlığı yok.</div>';
                return;
            }
            container.innerHTML = list.map(kw => `
                <div class="flex items-center justify-between px-3 py-2 rounded-xl bg-[#16181c] border border-[#2f3336]">
                    <span class="text-xs font-semibold text-[#e7e9ea] truncate">${escapeHtml(kw)}</span>
                    <button data-ext-click="unhideTrendKeyword('${escapeJsArg(kw)}')" class="px-2.5 py-1 rounded-full bg-[#1d9bf0]/15 hover:bg-[#1d9bf0]/25 text-[#1d9bf0] text-xs font-bold transition shrink-0">Geri Getir</button>
                </div>
            `).join('');
        }

        function unhideTrendKeyword(kw) {
            hiddenTrendKeywords.delete(String(kw || '').toLowerCase());
            saveHiddenTrends();
            renderHiddenTrendsList();
            renderTrends();
            showToast("Gündem başlığı geri yüklendi.");
        }

        function restoreAllHiddenTrends() {
            hiddenTrendKeywords.clear();
            saveHiddenTrends();
            renderHiddenTrendsList();
            renderTrends();
            showToast("Gizlenen tüm gündemler geri yüklendi.");
        }

        async function refreshTrendsFromModal() {
            await loadTrends();
            renderHiddenTrendsList();
            showToast("Canlı gündem listesi güncellendi.");
        }

        function openTrendSettingsModal() {
            renderHiddenTrendsList();
            openModal('trendSettingsModal');
        }

        // ================= 5. GÖNDERİLERİN OLUŞTURULMASI =================

        // ================= SANA ÖZEL ETKİLEŞİM & PROFİL GEÇMİŞİ MOTORU =================
                // Paylaşıma hazır temiz durum: Önceki yerel arama geçmişini, ziyaret edilen profilleri ve önerileri sıfırla
        try {
            if (!localStorage.getItem('x_shared_clean_v2')) {
                localStorage.removeItem('x_visited_profiles');
                localStorage.removeItem('x_visited_topics');
                localStorage.removeItem('my_user_handle');
                localStorage.removeItem('x_bookmarks');
                invalidateLocalMetaCaches();
                localStorage.setItem('x_shared_clean_v2', 'true');
            }
        } catch(e) {}
        function clearSearchHistory() {
            try {
                localStorage.removeItem('x_visited_profiles');
                localStorage.removeItem('x_visited_topics');
                showToast("Arama ve öneri geçmişi temizlendi.");
            } catch(e) {}
        }
        function getVisitedProfiles() {
            try {
                return JSON.parse(localStorage.getItem('x_visited_profiles') || '[]');
            } catch(e) {
                return [];
            }
        }

        function recordProfileVisit(username) {
            if (!username) return;
            const clean = username.trim().replace(/^@/, '').toLowerCase();
            if (!clean) return;
            let list = getVisitedProfiles();
            list = list.filter(u => u !== clean);
            list.unshift(clean);
            if (list.length > 25) list = list.slice(0, 25);
            try {
                localStorage.setItem('x_visited_profiles', JSON.stringify(list));
            } catch(e) {}
        }

        function recordTopicVisit(topic) {
            if (!topic) return;
            const clean = topic.trim().toLowerCase();
            if (!clean) return;
            try {
                let list = JSON.parse(localStorage.getItem('x_visited_topics') || '[]');
                list = list.filter(t => t !== clean);
                list.unshift(clean);
                if (list.length > 25) list = list.slice(0, 25);
                localStorage.setItem('x_visited_topics', JSON.stringify(list));
            } catch(e) {}
        }

                let homeOffset = 0;
        const HOME_PAGE_SIZE = 20;
        let homeHasMore = true;
        let isLoadingHome = false;

        function createPostCardHtml(p) {
            const isDeleted = p.is_deleted === 1;
            const isRetweet = p.is_retweet === 1;
            const displayAuthor = isRetweet ? (p.original_author || p.username) : p.username;
            const displayName = isRetweet ? (p.original_name || displayAuthor) : displayAuthor;
            const initialLetter = displayAuthor.charAt(0).toUpperCase();

            let formattedDate = formatTweetDate(p.posted_at);

            // Medya Galeri HTML (Tıkla-Yükle destekli, otomatik yüklemesiz)
            const mediaHtml = buildMediaGalleryHtml(p.media_urls, p.post_id, {
                maxHClass: 'max-h-[380px]',
                roundedClass: 'rounded-xl',
                altLabel: 'Fotoğraf'
            });

            // Alıntılanan Gönderi (Quote Tweet) Kartı
            let quoteHtml = '';
            const hasQuote = p.is_quote === 1 || (p.quoted_content && p.quoted_content.length > 0) || (p.quoted_post_id && p.quoted_post_id.length > 0);
            if (hasQuote) {
                const qAuthor = p.quoted_author || '';
                const qName = p.quoted_name || qAuthor || 'Kullanıcı';
                const qAvatar = p.quoted_avatar || '';
                const qInitial = (qAuthor || qName || 'X').charAt(0).toUpperCase();

                const qMediaHtml = buildMediaGalleryHtml(p.quoted_media_urls, p.quoted_post_id || p.post_id, {
                    wrapperClass: 'grid ' + (getDeduplicatedMedia(p.quoted_media_urls).length >= 2 ? 'grid-cols-2' : 'grid-cols-1') + ' gap-1.5 rounded-xl overflow-hidden mt-2 max-h-[260px] border border-[#2f3336]',
                    maxHClass: 'max-h-[240px]',
                    roundedClass: 'rounded-lg',
                    altLabel: 'Alıntı Medya'
                });

                quoteHtml = `
                    <div class="mt-2.5 border border-[#2f3336] hover:border-[#71767b]/60 rounded-2xl p-3 bg-black/40 hover:bg-white/[0.02] transition cursor-pointer group/quote" data-ext-click="event.stopPropagation(); ${p.quoted_post_id ? `openTweetDetail('${escapeJsArg(p.quoted_post_id)}', '${escapeJsArg(qAuthor)}')` : (qAuthor ? `renderProfileView('${escapeJsArg(qAuthor)}')` : '')}">
                        <div class="flex items-center gap-2 mb-1.5">
                            <img src="${qAvatar}"
                                 loading="lazy"
                                 decoding="async"
                                 data-ext-error="handleAvatarError(this, '${qInitial}')"
                                 class="w-5 h-5 rounded-full object-cover border border-[#2f3336] bg-[#16181c]"
                                 alt="@${escapeHtml(qAuthor)}">
                            <span class="font-bold text-xs text-[#e7e9ea] truncate group-hover/quote:underline">${escapeHtml(qName)}</span>
                            <span class="text-xs text-[#71767b] truncate">@${escapeHtml(qAuthor)}</span>
                            ${p.quoted_post_id ? `<span class="ml-auto text-[10px] text-[#71767b] group-hover/quote:text-[#1d9bf0] flex items-center gap-1"><i class="fa-solid fa-arrow-up-right-from-square"></i></span>` : ''}
                        </div>
                        <div class="text-[13.5px] leading-snug text-[#e7e9ea] font-normal whitespace-pre-line break-words">
                            ${escapeHtml(p.quoted_content || '')}
                        </div>
                        ${qMediaHtml}
                    </div>
                `;
            }

            // Sana Özel Tavsiye Rozeti (Yalnızca Sana Özel sekmesinde görünür)
            let recommendHtml = '';
            if (currentFilter === 'all' && currentView === 'home' && p.recommend_reason) {
                recommendHtml = `
                    <div class="flex items-center gap-2 text-xs text-[#71767b] font-medium mb-1.5 pl-12">
                        <i class="fa-solid ${p.recommend_icon || 'fa-sparkles'} text-[#1d9bf0] text-[11px]"></i>
                        <span>${escapeHtml(p.recommend_reason)}</span>
                    </div>
                `;
            }

            const isBookmarked = isPostBookmarked(p.post_id);
            const hasNote = Boolean(getPostNote(p.post_id));

            return `
                <article id="post-${escapeHtml(p.post_id)}" class="tweet-item px-4 py-3 cursor-pointer ${isDeleted ? 'bg-[#f4212e]/[0.02]' : ''}" data-ext-click="openTweetDetail('${escapeJsArg(p.post_id)}', '${escapeJsArg(displayAuthor)}')">
                    ${recommendHtml}
                    ${isRetweet ? `
                        <div class="flex items-center gap-2 text-xs text-[#71767b] font-bold mb-1 pl-8">
                            <i class="fa-solid fa-retweet text-[#00ba7c]"></i>
                            <span><a href="#" data-ext-click="event.preventDefault(); event.stopPropagation(); renderProfileView('${escapeJsArg(p.username)}')" class="hover:underline text-[#71767b]">@${escapeHtml(p.username)}</a> repost etti</span>
                        </div>
                    ` : ''}

                    <div class="flex gap-3">
                        <div class="shrink-0">
                            <img src="${p.author_avatar || ''}"
                                 data-remote="${p.author_avatar || ''}"
                                 loading="lazy"
                                 decoding="async"
                                 data-ext-error="handleAvatarError(this, '${escapeJsArg(initialLetter)}')"
                                 data-ext-click="event.stopPropagation(); renderProfileView('${escapeJsArg(displayAuthor)}')"
                                 class="w-10 h-10 rounded-full object-cover border border-[#2f3336] bg-[#16181c] hover:opacity-90 transition cursor-pointer"
                                 alt="@${escapeHtml(displayAuthor)}">
                        </div>

                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between gap-2">
                                <div class="flex items-center gap-1.5 min-w-0 flex-wrap">
                                    <span data-ext-click="event.stopPropagation(); renderProfileView('${escapeJsArg(displayAuthor)}')" class="font-bold text-[#e7e9ea] hover:underline text-[15px] truncate cursor-pointer">${escapeHtml(displayName)}</span>
                                    <svg viewBox="0 0 24 24" class="w-4 h-4 fill-[#1d9bf0] shrink-0"><g><path d="M22.25 12c0-1.43-.88-2.67-2.19-3.34.46-1.39.2-2.9-.81-3.91s-2.52-1.27-3.91-.81c-.66-1.31-1.91-2.19-3.34-2.19s-2.67.88-3.33 2.19c-1.4-.46-2.91-.2-3.92.81s-1.26 2.52-.8 3.91c-1.31.67-2.2 1.91-2.2 3.34s.89 2.67 2.2 3.34c-.46 1.39-.21 2.9.8 3.91s2.52 1.26 3.91.81c.67 1.31 1.91 2.19 3.34 2.19s2.68-.88 3.34-2.19c1.39.45 2.9.2 3.91-.81s1.27-2.52.81-3.91c1.31-.67 2.19-1.91 2.19-3.34zm-11.71 4.2L6.8 12.46l1.41-1.42 2.26 2.26 4.8-5.23 1.47 1.36-6.2 6.77z"></path></g></svg>
                                    <span class="text-[#71767b] text-xs">@${escapeHtml(displayAuthor)}</span>
                                    <span class="text-[#71767b] text-xs">·</span>
                                    <a href="https://x.com/${encodeURIComponent(displayAuthor)}/status/${encodeURIComponent(p.post_id)}" target="_blank" data-ext-click="event.stopPropagation()" class="text-[#71767b] text-xs hover:underline">${formattedDate}</a>
                                    ${hasNote ? `<span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-[10px] font-semibold" title="Kişisel Arşiv Notu"><i class="fa-regular fa-note-sticky"></i> Notlu</span>` : ''}
                                </div>
                                <div class="relative shrink-0">
                                    <button data-ext-click="toggleTweetDropdown(event, '${escapeJsArg(p.post_id)}', '${escapeJsArg(displayAuthor)}')" class="w-8 h-8 rounded-full hover:bg-[#1d9bf0]/10 hover:text-[#1d9bf0] flex items-center justify-center transition text-[#71767b]" title="Daha fazla">
                                        <i class="fa-solid fa-ellipsis"></i>
                                    </button>
                                </div>
                            </div>

                            ${(p.is_reply || p.reply_to_username) ? `
                                <div class="flex items-center gap-1 text-[13px] text-[#71767b] my-1 font-normal">
                                    <span>Yanıtlanan kişi:</span>
                                    <span data-ext-click="event.stopPropagation(); renderProfileView('${escapeJsArg((p.reply_to_username || '').replace('@',''))}')" class="text-[#1d9bf0] hover:underline cursor-pointer">@${escapeHtml((p.reply_to_username || '').replace('@','')) || 'kullanıcı'}</span>
                                </div>
                            ` : ''}

                            ${isDeleted ? `
                                <div class="my-1.5 px-3 py-1.5 rounded-lg bg-[#f4212e]/10 border border-[#f4212e]/25 text-[#f4212e] text-xs font-semibold flex items-center justify-between">
                                    <div class="flex items-center gap-1.5">
                                        <i class="fa-solid fa-clock-rotate-left"></i>
                                        <span>Bu gönderi X'ten silindi</span>
                                    </div>
                                    <span class="text-[10px] opacity-75 font-mono">Yerel Arşiv</span>
                                </div>
                            ` : ''}

                            <div class="text-[15px] leading-snug text-[#e7e9ea] font-normal whitespace-pre-line break-words my-2">
                                ${formatTweetContent(p.content || '')}
                            </div>

                            ${mediaHtml}
                            ${quoteHtml}

                            <div class="flex items-center justify-between max-w-md pt-2 mt-1 text-[#71767b] text-xs">
                                <div class="flex items-center gap-1 hover:text-[#1d9bf0] group transition">
                                    <div class="w-8 h-8 rounded-full flex items-center justify-center group-hover:bg-[#1d9bf0]/10">
                                        <i class="fa-regular fa-comment"></i>
                                    </div>
                                    <span>${p.replies || 0}</span>
                                </div>
                                <div class="flex items-center gap-1 hover:text-[#00ba7c] group transition">
                                    <div class="w-8 h-8 rounded-full flex items-center justify-center group-hover:bg-[#00ba7c]/10">
                                        <i class="fa-solid fa-retweet"></i>
                                    </div>
                                    <span>${p.retweets || 0}</span>
                                </div>
                                <div class="flex items-center gap-1 hover:text-[#f91880] group transition">
                                    <div class="w-8 h-8 rounded-full flex items-center justify-center group-hover:bg-[#f91880]/10">
                                        <i class="fa-regular fa-heart"></i>
                                    </div>
                                    <span>${Number(p.likes || 0).toLocaleString('tr-TR')}</span>
                                </div>
                                <div class="flex items-center gap-1 hover:text-[#1d9bf0] group transition" data-ext-click="event.stopPropagation(); toggleBookmark('${escapeJsArg(p.post_id)}')">
                                    <div class="w-8 h-8 rounded-full flex items-center justify-center group-hover:bg-[#1d9bf0]/10" title="Yer İmlerine Ekle / Çıkar">
                                        <i data-bookmark-post="${escapeHtml(p.post_id)}" class="${isBookmarked ? 'fa-solid fa-bookmark text-[#1d9bf0]' : 'fa-regular fa-bookmark'}"></i>
                                    </div>
                                </div>
                                <a href="https://x.com/${encodeURIComponent(displayAuthor)}/status/${encodeURIComponent(p.post_id)}" target="_blank" data-ext-click="event.stopPropagation()" class="w-8 h-8 rounded-full flex items-center justify-center hover:bg-[#1d9bf0]/10 hover:text-[#1d9bf0] transition" title="X'te Aç">
                                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </article>
            `;
        }

        async function loadPosts(isAppend = false) {
            const postsContainer = document.getElementById('postsList');
            if (!postsContainer) return;
            if (isLoadingHome) return;

            if (!isAppend) {
                homeOffset = 0;
                homeHasMore = true;
                currentLoadedPosts = [];
            }

            const sentinel = document.getElementById('homeScrollSentinel');
            if (sentinel) sentinel.classList.remove('hidden');

            isLoadingHome = true;
            const searchVal = document.getElementById('searchInput')?.value?.trim() || '';

            try {
                let url = `/api/posts?filter_type=${currentFilter}&limit=${HOME_PAGE_SIZE}&offset=${homeOffset}`;
                if (selectedUsername && selectedUsername !== 'all') {
                    url += `&username=${encodeURIComponent(selectedUsername)}`;
                }
                if (searchVal) {
                    url += `&search=${encodeURIComponent(searchVal)}`;
                }
                if (currentFilter === 'all') {
                    const visited = getVisitedProfiles();
                    if (visited.length > 0) {
                        url += `&visited=${encodeURIComponent(visited.join(','))}`;
                    }
                }

                const res = await fetch(url);
                const posts = await res.json();

                if (posts.length < HOME_PAGE_SIZE) {
                    homeHasMore = false;
                }
                homeOffset += posts.length;

                if (!isAppend) {
                    currentLoadedPosts = posts;
                    renderPostsToContainer(posts, postsContainer, "Henüz gösterilecek gönderi bulunamadı.", 'homeScrollSentinel', homeHasMore);
                } else {
                    currentLoadedPosts = currentLoadedPosts.concat(posts);
                    appendPostsToContainer(posts, postsContainer, 'homeScrollSentinel', homeHasMore);
                }
            } catch (e) {
                console.error("Gönderiler yüklenemedi:", e);
                if (!isAppend) {
                    postsContainer.innerHTML = '<div class="p-8 text-center text-[#f4212e] text-sm">Gönderiler yüklenirken bir hata oluştu.</div>';
                }
            } finally {
                isLoadingHome = false;
            }
        }

        function loadMoreHomePosts() {
            if (homeHasMore && !isLoadingHome) {
                loadPosts(true);
            }
        }

        function renderPostsToContainer(posts, container, emptyMessage, sentinelId, hasMore = true) {
            if (!posts || posts.length === 0) {
                container.innerHTML = `
                    <div class="p-12 text-center text-[#71767b]">
                        <i class="fa-regular fa-comment-dots text-3xl mb-3 text-[#2f3336]"></i>
                        <div class="text-sm font-semibold">${emptyMessage || "Gönderi yok"}</div>
                    </div>
                `;
                return;
            }

            let html = '';
            posts.forEach(p => {
                if (p && p.post_id) allLoadedPostsMap[p.post_id] = p;
                html += createPostCardHtml(p);
            });
            if (sentinelId) {
                html += `<div id="${sentinelId}" class="${hasMore ? '' : 'hidden '}py-6 flex items-center justify-center text-[#71767b]"><i class="fa-solid fa-circle-notch fa-spin text-xl text-[#1d9bf0]"></i><span class="text-xs ml-2">Daha fazla tweet yükleniyor...</span></div>`;
            }
            container.innerHTML = html;
            setupInfiniteScrollObservers();
        }

        function appendPostsToContainer(posts, container, sentinelId, hasMore = true) {
            const sentinel = sentinelId ? document.getElementById(sentinelId) : null;
            if (!posts || posts.length === 0) {
                if (sentinel && !hasMore) sentinel.classList.add('hidden');
                return;
            }
            let html = '';
            posts.forEach(p => {
                if (p && p.post_id) allLoadedPostsMap[p.post_id] = p;
                if (!document.getElementById(`post-${p.post_id}`)) {
                    html += createPostCardHtml(p);
                }
            });
            if (html) {
                if (sentinel && sentinel.parentNode === container) {
                    sentinel.insertAdjacentHTML('beforebegin', html);
                } else {
                    container.insertAdjacentHTML('beforeend', html);
                }
            }
            if (sentinel) {
                sentinel.classList.toggle('hidden', !hasMore);
            }
        }

        // ================= 6. KEŞFET EKRANI =================
        async function renderExploreView() {
            document.getElementById('mainHeaderSubtitle')?.classList.add('hidden');
            const container = document.getElementById('explorePostsList');
            if (!container) return;
            const searchVal = document.getElementById('exploreSearchInput')?.value?.trim() || '';

            try {
                let url = `/api/posts?filter_type=all`;
                if (searchVal) url += `&search=${encodeURIComponent(searchVal)}`;
                const res = await fetch(url);
                const posts = await res.json();
                renderPostsToContainer(posts, container, `"${searchVal}" için gönderi bulunamadı.`);
            } catch (e) {
                container.innerHTML = '<div class="p-8 text-center text-[#71767b]">Keşfet gönderileri yüklenemedi.</div>';
            }
        }

        // ================= 7. BİLDİRİMLER EKRANI =================
        function renderNotificationsView() {
            const list = document.getElementById('fullNotificationsList');
            if (!list) return;

            let filtered = allLogsData;
            if (currentNotifFilter === 'verified') {
                filtered = allLogsData.filter(l => {
                    const low = (l.action || '').toLowerCase();
                    return l.action.includes('❤️') || low.includes('silin') || low.includes('sildi');
                });
            } else if (currentNotifFilter === 'mentions') {
                filtered = allLogsData.filter(l => l.action.includes('Yeni gönderi') || l.action.includes('takibe alındı'));
            }

            if (filtered.length === 0) {
                list.innerHTML = '<div class="p-12 text-center text-[#71767b]">Bu sekmede henüz bildirim bulunmuyor.</div>';
                return;
            }

            let html = '';
            filtered.forEach(log => {
                let iconClass = 'fa-solid fa-bell text-[#1d9bf0]';
                let borderClass = 'border-[#2f3336]';
                const lowAct = (log.action || '').toLowerCase();

                if (log.action.includes('❤️')) {
                    iconClass = 'fa-solid fa-heart text-[#f91880]';
                } else if (lowAct.includes('silin') || lowAct.includes('sildi')) {
                    iconClass = 'fa-solid fa-triangle-exclamation text-[#f4212e]';
                    borderClass = 'border-[#f4212e]/30 bg-[#f4212e]/[0.02]';
                } else if (log.action.includes('Yeni gönderi')) {
                    iconClass = 'fa-solid fa-sparkles text-[#00ba7c]';
                }

                html += `
                    <div class="p-4 flex gap-3.5 items-start hover:bg-white/[0.03] transition ${borderClass}">
                        <div class="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center shrink-0 mt-0.5">
                            <i class="${iconClass}"></i>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="text-sm text-[#e7e9ea] font-medium leading-snug">${escapeHtml(log.action)}</div>
                            <div class="text-xs text-[#71767b] mt-1">${log.timestamp || 'Az önce'}</div>
                        </div>
                    </div>
                `;
            });
            list.innerHTML = html;
        }

        // ================= 8. LİSTELER EKRANI =================
        function renderListsView() {
            const container = document.getElementById('fullListsContainer');
            if (!container) return;

            if (allUsersData.length === 0) {
                container.innerHTML = '<div class="p-12 text-center text-[#71767b]">Henüz takip edilen bir hesap bulunmuyor.</div>';
                return;
            }

            let html = '';
            allUsersData.forEach(u => {
                const initialLetter = u.username.charAt(0).toUpperCase();
                html += `
                    <div class="p-4 hover:bg-white/[0.03] transition flex items-center justify-between gap-3">
                        <div class="flex items-center gap-3 min-w-0 cursor-pointer" data-ext-click="renderProfileView('${u.username}')">
                            <img src="${u.avatar_url || ''}" data-remote="${u.remote_avatar_url || u.avatar_url || ''}" loading="lazy" decoding="async" referrerpolicy="no-referrer" data-ext-error="handleAvatarError(this, '${initialLetter}')"
                                 class="w-12 h-12 rounded-full object-cover border border-[#2f3336] shrink-0" alt="@${u.username}">
                            <div class="min-w-0">
                                <div class="font-bold text-base text-white flex items-center gap-1.5 truncate hover:underline">
                                    <span>${escapeHtml(u.display_name || u.username)}</span>
                                    <svg viewBox="0 0 24 24" class="w-4 h-4 fill-[#1d9bf0] shrink-0"><g><path d="M22.25 12c0-1.43-.88-2.67-2.19-3.34.46-1.39.2-2.9-.81-3.91s-2.52-1.27-3.91-.81c-.66-1.31-1.91-2.19-3.34-2.19s-2.67.88-3.33 2.19c-1.4-.46-2.91-.2-3.92.81s-1.26 2.52-.8 3.91c-1.31.67-2.2 1.91-2.2 3.34s.89 2.67 2.2 3.34c-.46 1.39-.21 2.9.8 3.91s2.52 1.26 3.91.81c.67 1.31 1.91 2.19 3.34 2.19s2.68-.88 3.34-2.19c1.39.45 2.9.2 3.91-.81s1.27-2.52.81-3.91c1.31-.67 2.19-1.91 2.19-3.34zm-11.71 4.2L6.8 12.46l1.41-1.42 2.26 2.26 4.8-5.23 1.47 1.36-6.2 6.77z"></path></g></svg>
                                </div>
                                <div class="text-xs text-[#71767b]">@${u.username} · ${Number(u.followers_count || 0).toLocaleString('tr-TR')} takipçi · ${u.deleted_count || 0} silinen gönderi</div>
                            </div>
                        </div>
                        <div class="flex items-center gap-2 shrink-0">
                            <button data-ext-click="refreshUser('${u.username}')" class="w-9 h-9 rounded-full border border-[#2f3336] hover:bg-white/10 flex items-center justify-center text-white transition text-xs" title="Güncelle">
                                <i class="fa-solid fa-arrows-rotate"></i>
                            </button>
                            <button data-ext-click="deleteUser('${u.username}')" class="px-3.5 py-1.5 rounded-full border border-[#2f3336] hover:border-[#f4212e] hover:text-[#f4212e] text-[#e7e9ea] font-bold text-xs transition">
                                Takipten Çık
                            </button>
                        </div>
                    </div>
                `;
            });
            container.innerHTML = html;
        }

        // ================= 9. YER İMLERİ VE ARŞİV NOTLARI EKRANI =================
        async function resolvePostsByIds(postIds) {
            if (!postIds || postIds.length === 0) return [];
            const missingIds = postIds.filter(id => !allLoadedPostsMap[id]);
            if (missingIds.length > 0) {
                await Promise.all(missingIds.map(async id => {
                    try {
                        const r = await fetch(`/api/posts/${encodeURIComponent(id)}`);
                        if (r.ok) {
                            const p = await r.json();
                            if (p && p.post_id) allLoadedPostsMap[p.post_id] = p;
                        }
                    } catch {}
                }));
            }
            return postIds.map(id => allLoadedPostsMap[id]).filter(Boolean);
        }

        async function renderBookmarksView() {
            document.getElementById('mainHeaderSubtitle')?.classList.add('hidden');
            const container = document.getElementById('bookmarksList');
            if (!container) return;

            if (currentBookmarkTab === 'deleted') {
                try {
                    const res = await fetch('/api/posts?filter_type=deleted');
                    const deletedPosts = await res.json();
                    renderPostsToContainer(deletedPosts, container, "Henüz silinmiş bir tweet tespit edilmedi.");
                } catch(e) {
                    container.innerHTML = '<div class="p-8 text-center text-[#71767b]">Silinen gönderiler yüklenemedi.</div>';
                }
            } else if (currentBookmarkTab === 'notes') {
                const notes = getPostNotes();
                const notedIds = Object.keys(notes);
                if (notedIds.length === 0) {
                    container.innerHTML = '<div class="p-12 text-center text-[#71767b]">Henüz hiçbir gönderiye kişisel arşiv notu eklemediniz. Bir gönderiye tıklayıp üstteki not alanından ekleyebilirsiniz.</div>';
                    return;
                }
                const notedPosts = await resolvePostsByIds(notedIds);
                renderPostsToContainer(notedPosts, container, "Not eklenen gönderiler yüklenemedi.");
            } else {
                const bookmarkedIds = getBookmarks();
                if (bookmarkedIds.length === 0) {
                    container.innerHTML = '<div class="p-12 text-center text-[#71767b]">Henüz yer imlerine kaydedilmiş bir gönderi yok. Tweetlerdeki yer imi simgesinden ekleyebilirsiniz.</div>';
                    return;
                }
                const saved = await resolvePostsByIds(bookmarkedIds);
                renderPostsToContainer(saved, container, "Kaydedilen yer imleri bulunamadı.");
            }
        }

        // ================= 10. PROFİL EKRANI (TAKİPÇİLER VE TAKİP EDİLENLER İÇERİDE) =================
        let profileOffset = 0;
        const PROFILE_PAGE_SIZE = 100;
        let profileHasMore = true;
        let isLoadingProfile = false;
        let profileCursor = null;
        let isAutoFetchingOlder = false;
        let profileReachedEnd = false;

        function setProfileFilterBarVisible(show) {
            const bar = document.getElementById('profileFilterBar');
            if (bar) bar.classList.toggle('hidden', !show);
        }

        function filterProfileCachedPosts() {
            const postsContainer = document.getElementById('profilePostsList');
            const input = document.getElementById('profileSearchInput');
            const sortEl = document.getElementById('profileSortSelect');
            const clearBtn = document.getElementById('profileFilterClearBtn');
            const countEl = document.getElementById('profileFilteredCount');
            if (!postsContainer) return;

            const query = (input?.value || '').trim().toLowerCase();
            const sortMode = sortEl?.value || 'newest';
            if (clearBtn) clearBtn.classList.toggle('hidden', !query);

            let list = (profileCachedPosts || []).slice();
            if (query) {
                list = list.filter(p => {
                    const txt = `${p.content || ''} ${p.original_author || ''} ${p.original_name || ''} ${p.quoted_content || ''} ${p.quoted_author || ''}`.toLowerCase();
                    return txt.includes(query);
                });
            }

            if (sortMode === 'oldest') {
                list.sort((a, b) => String(a.posted_at || '').localeCompare(String(b.posted_at || '')));
            } else if (sortMode === 'likes') {
                list.sort((a, b) => (Number(b.likes || 0) - Number(a.likes || 0)));
            } else if (sortMode === 'retweets') {
                list.sort((a, b) => (Number(b.retweets || 0) - Number(a.retweets || 0)));
            }

            if (countEl) {
                countEl.innerText = (query || sortMode !== 'newest') ? `${list.length} sonuç` : '';
            }

            const hasFilterActive = Boolean(query) || sortMode !== 'newest';
            renderPostsToContainer(
                list,
                postsContainer,
                query ? `"${escapeHtml(query)}" ile eşleşen gönderi bulunamadı.` : "Bu sekmede gösterilecek gönderi yok.",
                'profileScrollSentinel',
                hasFilterActive ? false : profileHasMore
            );
        }

        function clearProfileFilter() {
            const input = document.getElementById('profileSearchInput');
            const sortEl = document.getElementById('profileSortSelect');
            if (input) input.value = '';
            if (sortEl) sortEl.value = 'newest';
            filterProfileCachedPosts();
        }

        function renderMyProfileEmptyState() {
            const container = document.getElementById('profileHeaderBanner');
            const postsContainer = document.getElementById('profilePostsList');
            const subEl = document.getElementById('mainHeaderSubtitle');
            setProfileFilterBarVisible(false);
            if (subEl) subEl.classList.add('hidden');
            if (!container || !postsContainer) return;

            const trackedHtml = allUsersData.length > 0
                ? allUsersData.map(u => `
                    <div class="flex items-center justify-between p-3 rounded-xl bg-[#16181c] border border-[#2f3336] hover:border-[#1d9bf0]/50 transition">
                        <div class="flex items-center gap-3 min-w-0 cursor-pointer" data-ext-click="renderProfileView('${escapeJsArg(u.username)}')">
                            <div class="w-9 h-9 rounded-full bg-[#1d9bf0]/20 text-[#1d9bf0] flex items-center justify-center font-bold text-sm shrink-0">${escapeHtml(u.username.charAt(0).toUpperCase())}</div>
                            <div class="min-w-0">
                                <div class="font-bold text-sm text-[#e7e9ea] truncate">${escapeHtml(u.display_name || u.username)}</div>
                                <div class="text-xs text-[#71767b]">@${escapeHtml(u.username)}</div>
                            </div>
                        </div>
                        <div class="flex items-center gap-2 shrink-0">
                            <button data-ext-click="setAsMyAccount('${escapeJsArg(u.username)}')" class="px-3 py-1 rounded-full bg-[#1d9bf0]/15 text-[#1d9bf0] hover:bg-[#1d9bf0]/25 text-xs font-bold transition">Hedef Seç</button>
                            <button data-ext-click="renderProfileView('${escapeJsArg(u.username)}')" class="px-3 py-1 rounded-full border border-[#2f3336] hover:bg-white/10 text-xs font-semibold text-[#e7e9ea] transition">Aç</button>
                        </div>
                    </div>`).join('')
                : '<div class="text-xs text-[#71767b]">Henüz takip edilen hesap eklenmemiş.</div>';

            container.innerHTML = `
                <div class="p-6 border-b border-[#2f3336] text-center space-y-3">
                    <div class="w-14 h-14 rounded-full bg-[#1d9bf0]/15 border border-[#1d9bf0]/40 flex items-center justify-center mx-auto">
                        <i class="fa-solid fa-crosshairs text-2xl text-[#1d9bf0]"></i>
                    </div>
                    <h2 class="text-lg font-extrabold text-white">Stalklanacak Hedef Profil Henüz Tanımlı Değil</h2>
                    <p class="text-xs text-[#71767b] max-w-md mx-auto">Sol menüdeki "Profil" sekmesine tıkladığında doğrudan açılması için stalklamak istediğin kişinin @kullanıcı adını tanımlayabilir veya aşağıdan bir hesabı inceleyebilirsin.</p>
                    <button data-ext-click="openSetMyAccountModal()" class="px-5 py-2 rounded-full bg-[#1d9bf0] hover:bg-[#1a8cd8] text-white font-bold text-sm transition">
                        Stalklanacak Kişiyi Tanımla
                    </button>
                </div>
            `;
            postsContainer.innerHTML = `
                <div class="p-4 space-y-2.5">
                    <div class="text-xs font-bold text-[#71767b] uppercase tracking-wider px-1">Takip Edilen Hesaplar</div>
                    ${trackedHtml}
                </div>
            `;
        }

        async function renderProfileView(username) {
            const cleanUser = (username || '').replace(/^@/, '').trim();
            if (!cleanUser) return;
            recordProfileVisit(cleanUser);
            activeProfileUsername = cleanUser;
            currentView = 'profile';
            currentProfileFilter = 'all';
            profileOffset = 0;
            profileHasMore = true;
            profileCursor = null;
            isAutoFetchingOlder = false;
            profileReachedEnd = false;

            const pSearch = document.getElementById('profileSearchInput');
            const pSort = document.getElementById('profileSortSelect');
            const pCount = document.getElementById('profileFilteredCount');
            const pClear = document.getElementById('profileFilterClearBtn');
            if (pSearch) pSearch.value = '';
            if (pSort) pSort.value = 'newest';
            if (pCount) pCount.innerText = '';
            if (pClear) pClear.classList.add('hidden');
            setProfileFilterBarVisible(true);

            document.querySelectorAll('.page-view').forEach(el => el.classList.add('hidden'));
            document.getElementById('view-profile').classList.remove('hidden');
            document.getElementById('homeTabsContainer').classList.add('hidden');

            const backBtn = document.getElementById('mainBackBtn');
            if (backBtn) backBtn.classList.remove('hidden');

            const container = document.getElementById('profileHeaderBanner');
            const postsContainer = document.getElementById('profilePostsList');
            if (!container || !postsContainer) return;

            const u = allUsersData.find(x => x.username.toLowerCase() === cleanUser.toLowerCase()) || {
                username: cleanUser,
                display_name: cleanUser,
                avatar_url: '',
                followers_count: 0,
                following_count: 0,
                total_tweets: 0,
                deleted_count: 0,
                join_date: '',
                added_at: ''
            };

            const mySavedHandle = getMyAccountHandle();
            const isMyAccount = mySavedHandle.toLowerCase() === cleanUser.toLowerCase();
            const initialLetter = u.username.charAt(0).toUpperCase();
            const tweetDisplay = u.total_tweets > 0 ? Number(u.total_tweets).toLocaleString('tr-TR') : (u.post_count || 0);
            const likeDisplay = u.profile_likes > 0 ? Number(u.profile_likes).toLocaleString('tr-TR') : (u.total_likes_display || Number(u.total_likes || 0).toLocaleString('tr-TR'));

            const titleEl = document.getElementById('mainHeaderTitle');
            if (titleEl) titleEl.innerText = u.display_name || u.username;
            const subEl = document.getElementById('mainHeaderSubtitle');
            if (subEl) {
                subEl.innerText = `${tweetDisplay} Gönderi`;
                subEl.classList.remove('hidden');
            }

            container.innerHTML = `
                <div class="border-b border-[#2f3336]">
                    <!-- STALKLANACAK HEDEF HESAP TANIMLAMA / GEÇİŞ BARI -->
                    <div class="px-4 py-2 bg-[#16181c]/70 border-b border-[#2f3336] flex items-center justify-between gap-3 text-xs">
                        <div class="flex items-center gap-2 min-w-0">
                            <i class="fa-solid fa-crosshairs text-[#1d9bf0] text-sm shrink-0"></i>
                            <span class="text-[#71767b] truncate">Stalk Hedefi: <strong class="text-white">${mySavedHandle ? `@${escapeHtml(mySavedHandle)}` : 'Tanımlanmadı'}</strong></span>
                            ${isMyAccount ? `<span class="px-2 py-0.5 rounded-full bg-[#00ba7c]/15 text-[#00ba7c] text-[11px] font-bold border border-[#00ba7c]/30">Aktif</span>` : ''}
                        </div>
                        <div class="flex items-center gap-2 shrink-0">
                            ${isMyAccount ? `
                                <button data-ext-click="clearMyAccountHandle()" class="px-2.5 py-1 border border-[#2f3336] hover:border-[#f4212e] hover:text-[#f4212e] text-[#71767b] font-semibold rounded-full transition text-[11px]">
                                    Kaldır
                                </button>
                            ` : `
                                <button data-ext-click="setAsMyAccount('${escapeJsArg(u.username)}')" class="px-3 py-1 bg-white/10 hover:bg-white/20 text-[#e7e9ea] font-bold rounded-full transition text-xs">
                                    Bu Kişiyi Hedef Seç
                                </button>
                            `}
                            <button data-ext-click="openSetMyAccountModal()" class="px-3 py-1 bg-[#1d9bf0] hover:bg-[#1a8cd8] text-white font-bold rounded-full transition text-xs">
                                ${mySavedHandle ? 'Değiştir' : 'Hedef Kişi Tanımla'}
                            </button>
                        </div>
                    </div>

                    <!-- KAPAK FOTOĞRAFI -->
                    <div class="h-36 bg-gradient-to-r from-[#1d9bf0]/20 via-[#16181c] to-[#2f3336]/40 relative"></div>

                    <!-- PROFİL DETAYLARI -->
                    <div class="px-4 pb-4">
                        <div class="flex items-end justify-between relative -mt-16 mb-3">
                            <img src="${u.avatar_url || ''}" id="profHeaderAvatarImg" data-remote="${u.remote_avatar_url || u.avatar_url || ''}" referrerpolicy="no-referrer" data-ext-error="handleAvatarError(this, '${escapeJsArg(initialLetter)}')"
                                 class="w-32 h-32 rounded-full object-cover border-4 border-black bg-black shrink-0 shadow-lg">
                            <div class="flex items-center gap-2 flex-wrap justify-end">
                                <button data-ext-click="openActivityPredictionModal('${escapeJsArg(cleanUser)}')" class="px-3.5 py-1.5 rounded-full border border-[#1d9bf0] text-[#1d9bf0] hover:bg-[#1d9bf0]/10 text-xs font-bold transition flex items-center gap-1.5" title="Kullanıcının beğeni saatlerine göre canlı aktivite ve uyku tahmini">
                                    <i class="fa-solid fa-chart-line"></i>
                                    <span>Aktivite & Uyku Tahmini</span>
                                </button>
                                <button data-ext-click="triggerDeepSync('${escapeJsArg(u.username)}')" id="btnDeepSync" class="px-3 py-1.5 rounded-full border border-[#00ba7c] text-[#00ba7c] hover:bg-[#00ba7c]/10 text-xs font-bold transition flex items-center gap-1.5" title="Kullanıcının TÜM geçmiş gönderi ve retweetlerini belleğe kaydet">
                                    <i class="fa-solid fa-cloud-arrow-down"></i>
                                    <span>Tüm Arşivi İndir</span>
                                </button>
                                <button data-ext-click="refreshUser('${escapeJsArg(u.username)}')" class="w-9 h-9 rounded-full border border-[#2f3336] hover:bg-white/10 flex items-center justify-center text-white transition text-xs" title="Güncelle">
                                    <i class="fa-solid fa-arrows-rotate"></i>
                                </button>
                                <a href="https://x.com/${encodeURIComponent(u.username)}" target="_blank" class="w-9 h-9 rounded-full border border-[#2f3336] hover:bg-white/10 flex items-center justify-center text-white transition text-xs" title="X.com'da Aç">
                                    <i class="fa-brands fa-x-twitter"></i>
                                </a>
                                <button data-ext-click="deleteUser('${escapeJsArg(u.username)}')" class="px-4 py-1.5 rounded-full border border-[#2f3336] hover:border-[#f4212e] hover:text-[#f4212e] text-[#e7e9ea] font-bold text-xs transition">
                                    Takipten Çık
                                </button>
                            </div>
                        </div>

                        <div>
                            <div class="flex items-center gap-1.5 flex-wrap">
                                <h2 id="profHeaderName" class="text-xl font-bold text-[#e7e9ea]">${escapeHtml(u.display_name || u.username)}</h2>
                                <svg viewBox="0 0 24 24" class="w-4 h-4 fill-[#1d9bf0] shrink-0"><g><path d="M22.25 12c0-1.43-.88-2.67-2.19-3.34.46-1.39.2-2.9-.81-3.91s-2.52-1.27-3.91-.81c-.66-1.31-1.91-2.19-3.34-2.19s-2.67.88-3.33 2.19c-1.4-.46-2.91-.2-3.92.81s-1.26 2.52-.8 3.91c-1.31.67-2.2 1.91-2.2 3.34s.89 2.67 2.2 3.34c-.46 1.39-.21 2.9.8 3.91s2.52 1.26 3.91.81c.67 1.31 1.91 2.19 3.34 2.19s2.68-.88 3.34-2.19c1.39.45 2.9.2 3.91-.81s1.27-2.52.81-3.91c1.31-.67 2.19-1.91 2.19-3.34zm-11.71 4.2L6.8 12.46l1.41-1.42 2.26 2.26 4.8-5.23 1.47 1.36-6.2 6.77z"></path></g></svg>
                            </div>
                            <div class="text-sm text-[#71767b]">@${escapeHtml(u.username)}</div>

                            <div class="flex items-center gap-4 text-xs text-[#71767b] mt-3 flex-wrap">
                                <span class="flex items-center gap-1"><i class="fa-regular fa-calendar"></i> Katıldı: <span id="profHeaderJoinDate">${formatJoinDate(u.join_date || u.added_at)}</span></span>
                                <span class="flex items-center gap-1 text-[#536471]"><i class="fa-regular fa-clock"></i> Son kontrol: <span id="profHeaderLastChecked">${formatShortTime(u.last_checked)}</span></span>
                            </div>

                            <!-- GÖNDERİ, TAKİP EDİLEN, TAKİPÇİ VE TOPLAM BEĞENİ SAYILARI (NITTER & X) -->
                            <div class="flex items-center flex-wrap gap-4 text-sm text-[#71767b] mt-3">
                                <div class="flex items-center gap-1 text-[#e7e9ea]" title="Nitter / X Toplam Gönderi Sayısı">
                                    <i class="fa-solid fa-feather text-[#1d9bf0] text-xs"></i>
                                    <strong id="profHeaderTweetCount" class="text-white">${tweetDisplay}</strong>
                                    <span class="text-[#71767b]">Gönderi</span>
                                </div>
                                <button data-ext-click="setProfileTab('following')" class="hover:underline flex items-center gap-1 cursor-pointer">
                                    <strong id="profHeaderFollowingCount" class="text-[#e7e9ea]">${Number(u.following_count || 0).toLocaleString('tr-TR')}</strong>
                                    <span>Takip edilen</span>
                                </button>
                                <button data-ext-click="setProfileTab('followers')" class="hover:underline flex items-center gap-1 cursor-pointer">
                                    <strong id="profHeaderFollowersCount" class="text-[#e7e9ea]">${Number(u.followers_count || 0).toLocaleString('tr-TR')}</strong>
                                    <span>Takipçi</span>
                                </button>
                                <div class="flex items-center gap-1 text-[#e7e9ea]" title="Nitter Toplam Beğeni Sayısı (Kullanıcının Beğendikleri)">
                                    <i class="fa-solid fa-heart text-[#f91880] text-xs"></i>
                                    <strong id="profHeaderLikeCount" class="text-white">${likeDisplay}</strong>
                                    <span class="text-[#71767b]">Beğeni</span>
                                </div>
                                <button data-ext-click="setProfileTab('deleted')" class="hover:underline flex items-center gap-1 cursor-pointer">
                                    <strong id="profHeaderDeletedCount" class="${u.deleted_count > 0 ? 'text-[#f4212e]' : 'text-[#e7e9ea]'}">${u.deleted_count || 0}</strong>
                                    <span class="${u.deleted_count > 0 ? 'text-[#f4212e]' : ''}">Silinen</span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- PROFİL SEKMELERİ (GÖNDERİLER, YANITLAR, YENİDEN GÖNDERİLER, MEDYA, SİLİNENLER) -->
                    <div class="flex overflow-x-auto no-scrollbar text-center text-xs font-bold border-t border-[#2f3336]">
                        <button data-ext-click="setProfileTab('all')" id="profTab_all" class="relative py-3.5 px-4 hover:bg-white/[0.05] transition text-[#e7e9ea] flex flex-col items-center shrink-0">
                            <span>Gönderiler</span>
                            <div class="tab-indicator absolute bottom-0 h-1 w-10 bg-[#1d9bf0] rounded-full mx-auto inset-x-0"></div>
                        </button>
                        <button data-ext-click="setProfileTab('replies')" id="profTab_replies" class="relative py-3.5 px-4 hover:bg-white/[0.05] transition text-[#71767b] font-medium flex flex-col items-center shrink-0">
                            <span>Yanıtlar</span>
                            <div class="tab-indicator hidden absolute bottom-0 h-1 w-10 bg-[#1d9bf0] rounded-full mx-auto inset-x-0"></div>
                        </button>
                        <button data-ext-click="setProfileTab('reposts')" id="profTab_reposts" class="relative py-3.5 px-4 hover:bg-white/[0.05] transition text-[#71767b] font-medium flex flex-col items-center shrink-0">
                            <span>Yeniden Gönderiler</span>
                            <div class="tab-indicator hidden absolute bottom-0 h-1 w-14 bg-[#1d9bf0] rounded-full mx-auto inset-x-0"></div>
                        </button>
                        <button data-ext-click="setProfileTab('media')" id="profTab_media" class="relative py-3.5 px-4 hover:bg-white/[0.05] transition text-[#71767b] font-medium flex flex-col items-center shrink-0">
                            <span>Medya</span>
                            <div class="tab-indicator hidden absolute bottom-0 h-1 w-10 bg-[#1d9bf0] rounded-full mx-auto inset-x-0"></div>
                        </button>
                        <button data-ext-click="setProfileTab('deleted')" id="profTab_deleted" class="relative py-3.5 px-4 hover:bg-white/[0.05] transition text-[#71767b] font-medium flex flex-col items-center shrink-0">
                            <span>Silinenler</span>
                            <div class="tab-indicator hidden absolute bottom-0 h-1 w-12 bg-[#1d9bf0] rounded-full mx-auto inset-x-0"></div>
                        </button>
                        <button data-ext-click="setProfileTab('following')" id="profTab_following" class="relative py-3.5 px-4 hover:bg-white/[0.05] transition text-[#71767b] font-medium flex flex-col items-center shrink-0">
                            <span>Takip Edilen</span>
                            <div class="tab-indicator hidden absolute bottom-0 h-1 w-14 bg-[#1d9bf0] rounded-full mx-auto inset-x-0"></div>
                        </button>
                        <button data-ext-click="setProfileTab('followers')" id="profTab_followers" class="relative py-3.5 px-4 hover:bg-white/[0.05] transition text-[#71767b] font-medium flex flex-col items-center shrink-0">
                            <span>Takipçiler</span>
                            <div class="tab-indicator hidden absolute bottom-0 h-1 w-12 bg-[#1d9bf0] rounded-full mx-auto inset-x-0"></div>
                        </button>
                    </div>
                </div>
            `;
            // Sunucudan gerçek kullanıcı bilgilerini ve istatistiklerini anında doğrula ve ekrana uygula
            fetch(`/api/user/${encodeURIComponent(cleanUser)}`)
                .then(r => r.json())
                .then(userData => {
                    if (userData && activeProfileUsername.toLowerCase() === cleanUser.toLowerCase()) {
                        applyUserProfileData(userData);
                    }
                }).catch(() => {});

            loadProfilePosts(cleanUser, false);
        }

        async function loadProfilePosts(username, isAppend = false, isSilent = false) {
            const postsContainer = document.getElementById('profilePostsList');
            if (!postsContainer) return;
            if (isLoadingProfile) return;
            if (!isAppend) {
                profileOffset = 0;
                profileHasMore = true;
                if (!isSilent) {
                    postsContainer.innerHTML = `
                        <div id="profileLoading" class="p-12 text-center text-[#71767b]">
                            <i class="fa-solid fa-circle-notch fa-spin text-2xl text-[#1d9bf0] mb-3"></i>
                            <div class="text-sm font-semibold">Gönderiler yükleniyor...</div>
                        </div>
                    `;
                }
            }

            const sentinel = document.getElementById('profileScrollSentinel');
            if (sentinel) sentinel.classList.remove('hidden');

            isLoadingProfile = true;

            try {
                let url = `/api/posts?username=${encodeURIComponent(username)}&limit=${PROFILE_PAGE_SIZE}&offset=${profileOffset}`;
                if (currentProfileFilter !== 'all') {
                    url += `&filter_type=${encodeURIComponent(currentProfileFilter)}`;
                }

                const res = await fetch(url);
                const posts = await res.json();

                if (posts.length < PROFILE_PAGE_SIZE) {
                    profileHasMore = false;
                }
                profileOffset += posts.length;

                if (!isAppend) {
                    // isSilent modda: yeni post sayısı mevcut cache'ten fazlaysa veya farklıysa yenile
                    const prevCount = profileCachedPosts.length;
                    profileCachedPosts = posts;
                    const cleanU = (username || '').toLowerCase();
                    const matchedU = allUsersData.find(x => x.username.toLowerCase() === cleanU);
                    const isNewOrScanning = !matchedU || matchedU.total_tweets === 0 || (matchedU.post_count || 0) === 0 || matchedU.last_checked === 'Taranıyor...';
                    if (posts.length === 0 && isNewOrScanning) {
                        if (!isSilent) {
                            postsContainer.innerHTML = `
                                <div id="profileAutoLoading" class="p-12 text-center text-[#71767b]">
                                    <i class="fa-solid fa-circle-notch fa-spin text-3xl text-[#1d9bf0] mb-4"></i>
                                    <div class="text-base font-bold text-white mb-1">Gönderiler Taranıyor ve Yükleniyor...</div>
                                    <div class="text-xs text-[#71767b]">Lütfen bekleyin, profil ve gönderiler otomatik olarak yüklenecektir (sayfayı yenilemeniz gerekmez).</div>
                                </div>
                            `;
                        }
                        autoPollProfileUntilLoaded(username);
                    } else if (!isSilent || posts.length !== prevCount) {
                        // Sessiz değilse veya post sayısı değiştiyse filtreyi koruyarak render et
                        const pQuery = document.getElementById('profileSearchInput')?.value?.trim() || '';
                        const pSort = document.getElementById('profileSortSelect')?.value || 'newest';
                        if (pQuery || pSort !== 'newest') {
                            filterProfileCachedPosts();
                        } else {
                            renderPostsToContainer(posts, postsContainer, "Bu sekmede gösterilecek gönderi yok.", 'profileScrollSentinel', profileHasMore);
                        }
                    }
                } else {
                    profileCachedPosts = profileCachedPosts.concat(posts);
                    appendPostsToContainer(posts, postsContainer, 'profileScrollSentinel', profileHasMore);
                }
                // Gönderiler geldikten sonra profil beğeni veya gönderi sayısı 0 kalmışsa anında güncelle (RT beğenileri hariç)
                if (posts && posts.length > 0) {
                    const postLikesSum = profileCachedPosts.reduce((acc, p) => acc + (p.is_retweet ? 0 : (p.likes || 0)), 0);
                    const likeEl = document.getElementById('profHeaderLikeCount');
                    if (likeEl && (likeEl.innerText === '0' || likeEl.innerText === '')) {
                        likeEl.innerText = Number(postLikesSum).toLocaleString('tr-TR');
                    }
                    const tweetEl = document.getElementById('profHeaderTweetCount');
                    if (tweetEl && (tweetEl.innerText === '0' || tweetEl.innerText === '')) {
                        tweetEl.innerText = Number(profileCachedPosts.length).toLocaleString('tr-TR');
                        const subTitle = document.getElementById('mainHeaderSubtitle');
                        if (subTitle && currentView === 'profile') subTitle.innerText = `${profileCachedPosts.length} Gönderi`;
                    }
                }

                // Yerel arşiv bittiyse otomatik olarak Nitter/X arşivinden geçmiş tweetleri çek
                if (!profileHasMore && ['all', 'replies', 'reposts', 'media', 'deleted'].includes(currentProfileFilter)) {
                    autoFetchOlderProfilePosts(username);
                }
            } catch(e) {
                console.error("Profil gönderileri yüklenemedi:", e);
                if (!isAppend) {
                    postsContainer.innerHTML = '<div class="p-8 text-center text-[#71767b]">Profil gönderileri yüklenemedi.</div>';
                }
            } finally {
                isLoadingProfile = false;
            }
        }

        function loadMoreProfilePosts() {
            if (profileHasMore && !isLoadingProfile) {
                loadProfilePosts(activeProfileUsername, true);
            }
        }

        async function autoFetchOlderProfilePosts(username) {
            if (isAutoFetchingOlder || profileReachedEnd) return;
            isAutoFetchingOlder = true;

            const sentinel = document.getElementById('profileScrollSentinel');
            if (sentinel) {
                sentinel.innerHTML = '<div class="flex items-center justify-center gap-2 text-xs text-[#1d9bf0] font-semibold py-4"><i class="fa-solid fa-circle-notch fa-spin text-base"></i><span>Daha eski tweetler arşivden çekiliyor...</span></div>';
                sentinel.classList.remove('hidden');
            }

            try {
                let url = `/api/user/${encodeURIComponent(username)}/fetch-older?filter_type=${encodeURIComponent(currentProfileFilter)}`;
                if (profileCursor) {
                    url += `&cursor=${encodeURIComponent(profileCursor)}`;
                }
                const res = await fetch(url, { method: 'POST' });
                const data = await res.json();

                if (data.status === 'ok') {
                    profileCursor = data.next_cursor || null;
                    const addedCount = data.added !== undefined ? data.added : (data.new_posts_count !== undefined ? data.new_posts_count : (data.count || 0));

                    if (addedCount > 0 || (data.count && data.count > 0)) {
                        // Yeni eklenen eski tweetleri DB'den çek ve ekle
                        const postRes = await fetch(`/api/posts?username=${encodeURIComponent(username)}&filter_type=${encodeURIComponent(currentProfileFilter)}&limit=20&offset=${profileOffset}`);
                        const newPosts = await postRes.json();
                        if (newPosts && newPosts.length > 0) {
                            profileOffset += newPosts.length;
                            profileCachedPosts = profileCachedPosts.concat(newPosts);
                            const postsContainer = document.getElementById('profilePostsList');
                            appendPostsToContainer(newPosts, postsContainer, 'profileScrollSentinel', Boolean(data.next_cursor));
                        }
                        if (data.next_cursor) {
                            profileHasMore = true;
                            if (sentinel) {
                                sentinel.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin text-xl text-[#1d9bf0]"></i><span class="text-xs ml-2">Daha fazla tweet yükleniyor...</span>';
                            }
                        } else {
                            profileReachedEnd = true;
                            if (sentinel) {
                                sentinel.innerHTML = '<div class="text-xs text-[#71767b] py-2 flex items-center justify-center gap-1.5"><i class="fa-solid fa-check text-[#00ba7c]"></i><span>Arşivin sonuna ulaşıldı</span></div>';
                            }
                        }
                    } else {
                        profileReachedEnd = true;
                        if (sentinel) {
                            sentinel.innerHTML = '<div class="text-xs text-[#71767b] py-2 flex items-center justify-center gap-1.5"><i class="fa-solid fa-check text-[#00ba7c]"></i><span>Arşivin sonuna ulaşıldı</span></div>';
                        }
                    }
                } else {
                    profileReachedEnd = true;
                    if (sentinel) sentinel.classList.add('hidden');
                }
            } catch (e) {
                console.error("autoFetchOlder error:", e);
                profileReachedEnd = true;
                if (sentinel) {
                    sentinel.innerHTML = `<button data-ext-click="profileReachedEnd=false; autoFetchOlderProfilePosts('${escapeJsArg(username)}')" class="px-4 py-1.5 bg-[#1d9bf0] hover:bg-[#1a8cd8] text-white text-xs font-bold rounded-full transition flex items-center gap-1.5 mx-auto"><i class="fa-solid fa-arrows-rotate"></i><span>Tekrar Dene</span></button>`;
                }
            } finally {
                isAutoFetchingOlder = false;
            }
        }

        // PROFİL ALT İÇERİĞİ (GÖNDERİLER VEYA UYGULAMA İÇİ TAKİPÇİLER/TAKİP EDİLENLER)
        async function renderProfileSubContent() {
            const postsContainer = document.getElementById('profilePostsList');
            if (!postsContainer) return;

            // 1. EĞER TAKİPÇİLER VEYA TAKİP EDİLENLER İSTENİYORSA: UYGULAMA İÇİNDE ÇEK VE LİSTELE
            if (currentProfileFilter === 'followers' || currentProfileFilter === 'following') {
                setProfileFilterBarVisible(false);
                const relLabel = currentProfileFilter === 'followers' ? 'Takipçiler' : 'Takip Edilenler';
                postsContainer.innerHTML = `
                    <div class="p-12 text-center text-[#71767b]">
                        <i class="fa-solid fa-circle-notch fa-spin text-2xl text-[#1d9bf0] mb-3"></i>
                        <div class="text-sm font-semibold">${relLabel} taranıyor ve yükleniyor...</div>
                    </div>
                `;

                try {
                    const res = await fetch(`/api/user/${encodeURIComponent(activeProfileUsername)}/relationships?type=${currentProfileFilter}`);
                    const data = await res.json();
                    const users = data.users || [];

                    if (users.length === 0) {
                        postsContainer.innerHTML = `
                            <div class="p-12 text-center text-[#71767b]">
                                <i class="fa-solid fa-user-lock text-3xl mb-3 text-[#2f3336]"></i>
                                <div class="text-sm font-semibold">Bu hesabın ${relLabel.toLowerCase()} listesi korumalı veya henüz tespit edilemedi.</div>
                            </div>
                        `;
                        return;
                    }

                    let relHtml = `
                        <div class="p-3 bg-[#16181c]/50 border-b border-[#2f3336] flex items-center justify-between text-xs text-[#71767b]">
                            <span>Toplam <strong class="text-white">${users.length}</strong> ${relLabel.toLowerCase()} bulundu</span>
                            <span class="text-[11px]">Kullanıcıya tıklayarak profilini inceleyebilirsiniz</span>
                        </div>
                    `;

                    users.forEach(u => {
                        const initialLetter = u.username.charAt(0).toUpperCase();
                        const isTracked = allUsersData.some(x => x.username.toLowerCase() === u.username.toLowerCase());

                        relHtml += `
                            <div class="p-4 border-b border-[#2f3336] hover:bg-white/[0.03] transition flex items-start justify-between gap-3">
                                <div class="flex items-start gap-3 min-w-0 cursor-pointer" data-ext-click="renderProfileView('${u.username}')">
                                    <img src="${u.avatar_url || ''}" data-remote="${u.avatar_url || ''}" loading="lazy" decoding="async" data-ext-error="handleAvatarError(this, '${initialLetter}')"
                                         class="w-11 h-11 rounded-full object-cover border border-[#2f3336] bg-[#16181c] shrink-0" alt="@${u.username}">
                                    <div class="min-w-0 text-left">
                                        <div class="font-bold text-sm text-white hover:underline flex items-center gap-1">
                                            <span>${escapeHtml(u.display_name || u.username)}</span>
                                            <svg viewBox="0 0 24 24" class="w-3.5 h-3.5 fill-[#1d9bf0] shrink-0"><g><path d="M22.25 12c0-1.43-.88-2.67-2.19-3.34.46-1.39.2-2.9-.81-3.91s-2.52-1.27-3.91-.81c-.66-1.31-1.91-2.19-3.34-2.19s-2.67.88-3.33 2.19c-1.4-.46-2.91-.2-3.92.81s-1.26 2.52-.8 3.91c-1.31.67-2.2 1.91-2.2 3.34s.89 2.67 2.2 3.34c-.46 1.39-.21 2.9.8 3.91s2.52 1.26 3.91.81c.67 1.31 1.91 2.19 3.34 2.19s2.68-.88 3.34-2.19c1.39.45 2.9.2 3.91-.81s1.27-2.52.81-3.91c1.31-.67 2.19-1.91 2.19-3.34zm-11.71 4.2L6.8 12.46l1.41-1.42 2.26 2.26 4.8-5.23 1.47 1.36-6.2 6.77z"></path></g></svg>
                                        </div>
                                        <div class="text-xs text-[#71767b]">@${u.username}</div>
                                        ${u.bio ? `<div class="text-xs text-[#e7e9ea] mt-1.5 leading-snug line-clamp-2">${escapeHtml(u.bio)}</div>` : ''}
                                    </div>
                                </div>
                                <div class="shrink-0 flex items-center gap-2">
                                    ${isTracked ? `
                                        <button data-ext-click="deleteUser('${u.username}')" class="px-3.5 py-1.5 bg-[#eff3f4] hover:bg-[#f4212e]/10 hover:text-[#f4212e] text-black font-bold text-xs rounded-full border border-transparent hover:border-[#f4212e] transition" title="Takipten Çık">
                                            Takipte
                                        </button>
                                    ` : `
                                        <button data-ext-click="addUserByHandle('${u.username}')" class="px-3.5 py-1.5 bg-[#1d9bf0] hover:bg-[#1a8cd8] text-white font-bold text-xs rounded-full transition" title="Arşive Ekle">
                                            Takip Et
                                        </button>
                                    `}
                                </div>
                            </div>
                        `;
                    });

                    postsContainer.innerHTML = relHtml;
                } catch(e) {
                    postsContainer.innerHTML = '<div class="p-8 text-center text-[#71767b]">Bağlantılar yüklenirken bir hata oluştu.</div>';
                }
                return;
            }

            // 2. GÖNDERİ FİLTRELERİ: Sunucudan çek ve sonsuz kaydırmayı başlat
            setProfileFilterBarVisible(true);
            loadProfilePosts(activeProfileUsername, false);
        }

        function returnToPostsFeed() {
            document.getElementById('mainHeaderSubtitle')?.classList.add('hidden');
            if (currentView === 'tweet') {
                if (previousView === 'profile') {
                    renderProfileView(previousProfileUser || activeProfileUsername);
                    return;
                } else if (previousView === 'search') {
                    openSearchPage(previousSearchQuery, '', '', previousSearchTab);
                    return;
                } else if (previousView && previousView !== 'tweet') {
                    navigateTo(previousView);
                    return;
                }
            } else if (previousView && previousView !== 'search') {
                navigateTo(previousView);
                return;
            }
            navigateTo('home');
        }

        // ================= CANLI PROFİL VE VERİ GÜNCELLEYİCİSİ =================
        let activeProfilePollTimer = null;
        let activeProfilePollAttempts = 0;
        function applyUserProfileData(userData) {
            if (!userData || !userData.username) return;
            const clean = userData.username.toLowerCase();
            // allUsersData listesini tazele / ekle
            const idx = allUsersData.findIndex(x => x.username.toLowerCase() === clean);
            if (idx >= 0) {
                allUsersData[idx] = Object.assign({}, allUsersData[idx], userData);
            } else {
                allUsersData.unshift(userData);
            }
            if (activeProfileUsername.toLowerCase() !== clean) return;
            // Başlık ve İsim
            const dName = userData.display_name || userData.username;
            const nameEl = document.getElementById('profHeaderName');
            if (nameEl) nameEl.innerText = dName;
            const mainTitleEl = document.getElementById('mainHeaderTitle');
            if (mainTitleEl && currentView === 'profile') mainTitleEl.innerText = dName;
            // Profil Resmi
            const avatarEl = document.getElementById('profHeaderAvatarImg');
            if (avatarEl && (userData.avatar_url || userData.remote_avatar_url)) {
                if (userData.remote_avatar_url) {
                    avatarEl.dataset.remote = userData.remote_avatar_url;
                }
                const newSrc = userData.avatar_url || userData.remote_avatar_url;
                if (avatarEl.src !== newSrc && !avatarEl.src.includes(newSrc)) {
                    avatarEl.removeAttribute('data-failed-remote');
                    avatarEl.removeAttribute('data-failed-proxy');
                    avatarEl.src = newSrc;
                }
            }
            // İstatistikler
            const tDisplay = userData.total_tweets > 0 ? Number(userData.total_tweets).toLocaleString('tr-TR') : (userData.post_count || 0);
            const lDisplay = userData.total_likes > 0 ? Number(userData.total_likes).toLocaleString('tr-TR') : (userData.profile_likes || 0);
            const tweetEl = document.getElementById('profHeaderTweetCount');
            if (tweetEl) tweetEl.innerText = tDisplay;
            const likeEl = document.getElementById('profHeaderLikeCount');
            if (likeEl) likeEl.innerText = lDisplay;
            const fwingEl = document.getElementById('profHeaderFollowingCount');
            if (fwingEl && userData.following_count !== undefined) fwingEl.innerText = Number(userData.following_count).toLocaleString('tr-TR');
            const fwerEl = document.getElementById('profHeaderFollowersCount');
            if (fwerEl && userData.followers_count !== undefined) fwerEl.innerText = Number(userData.followers_count).toLocaleString('tr-TR');
            const delEl = document.getElementById('profHeaderDeletedCount');
            if (delEl && userData.deleted_count !== undefined) delEl.innerText = userData.deleted_count;
            const joinDateEl = document.getElementById('profHeaderJoinDate');
            if (joinDateEl && (userData.join_date || userData.added_at)) {
                joinDateEl.innerText = formatJoinDate(userData.join_date || userData.added_at);
            }
            const lastCheckedEl = document.getElementById('profHeaderLastChecked');
            if (lastCheckedEl && userData.last_checked) {
                lastCheckedEl.innerText = formatShortTime(userData.last_checked);
            }
            const subTitle = document.getElementById('mainHeaderSubtitle');
            if (subTitle && currentView === 'profile') {
                const archCount = Number(userData.post_count || 0).toLocaleString('tr-TR');
                subTitle.innerText = `${tDisplay} Gönderi · ${archCount} Arşivde`;
            }
        }
        function autoPollProfileUntilLoaded(username) {
            if (activeProfilePollTimer) {
                clearTimeout(activeProfilePollTimer);
                activeProfilePollTimer = null;
            }
            activeProfilePollAttempts = 0;
            const cleanU = (username || '').replace(/^@/, '').trim().toLowerCase();
            async function poll() {
                if (currentView !== 'profile' || activeProfileUsername.toLowerCase() !== cleanU) {
                    return;
                }
                activeProfilePollAttempts++;
                try {
                    // 1. Kullanıcı bilgilerini çek ve uygula
                    const uRes = await fetch(`/api/user/${encodeURIComponent(cleanU)}`);
                    if (uRes.ok) {
                        const uData = await uRes.json();
                        if (uData && activeProfileUsername.toLowerCase() === cleanU) {
                            applyUserProfileData(uData);
                            if (uData.last_checked && uData.last_checked.includes('bulunamadı')) {
                                const postsContainer = document.getElementById('profilePostsList');
                                if (postsContainer) {
                                    postsContainer.innerHTML = `<div class="p-12 text-center text-[#71767b]"><i class="fa-solid fa-user-xmark text-4xl text-[#f4212e] mb-3"></i><div class="text-base font-bold text-white mb-1">Hesap Bulunamadı</div><div class="text-xs text-[#71767b]">@${cleanU} kullanıcısı X üzerinde mevcut değil veya silinmiş.</div></div>`;
                                }
                                showToast(`@${cleanU} X üzerinde bulunamadı!`);
                                return;
                            }
                        }
                    }
                    // 2. Gönderileri çek
                    let postUrl = `/api/posts?username=${encodeURIComponent(cleanU)}&limit=${PROFILE_PAGE_SIZE}&offset=0`;
                    if (currentProfileFilter !== 'all') {
                        postUrl += `&filter_type=${encodeURIComponent(currentProfileFilter)}`;
                    }
                    const pRes = await fetch(postUrl);
                    if (pRes.ok) {
                        const posts = await pRes.json();
                        if (posts && posts.length > 0) {
                            const postsContainer = document.getElementById('profilePostsList');
                            if (postsContainer && activeProfileUsername.toLowerCase() === cleanU) {
                                profileCachedPosts = posts;
                                profileOffset = posts.length;
                                profileHasMore = posts.length >= PROFILE_PAGE_SIZE;
                                renderPostsToContainer(posts, postsContainer, "Bu sekmede gösterilecek gönderi yok.", 'profileScrollSentinel');
                            }
                            loadUsers();
                            return; // Başarıyla yüklendi!
                        }
                    }
                } catch (err) {
                    console.warn("Otomatik profil tarama kontrolü:", err);
                }
                // 15 denemeye kadar (yaklaşık 18-20 saniye) devam et
                if (activeProfilePollAttempts < 15) {
                    activeProfilePollTimer = setTimeout(poll, 1200);
                } else {
                    const postsContainer = document.getElementById('profilePostsList');
                    const autoLoading = document.getElementById('profileAutoLoading');
                    if (postsContainer && autoLoading) {
                        postsContainer.innerHTML = '<div class="p-12 text-center text-[#71767b]"><div class="text-sm font-semibold text-white mb-1">Henüz gönderi bulunamadı veya hesap korumalı.</div><div class="text-xs text-[#536471]">Kullanıcı tweet attıkça veya tarandıkça burada listelenecektir.</div></div>';
                    }
                }
            }
            activeProfilePollTimer = setTimeout(poll, 600);
        }
        // ================= 11. HESAP EKLEME & TAKİPTEN ÇIKMA =================
        async function addUser() {
            const input = document.getElementById('usernameInput');
            const username = input?.value?.trim().replace(/^@/, '');
            if (!username) return;
            const btn = document.getElementById('btnAddUser');
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Ekleniyor...';
            }
            try {
                input.value = '';
                showToast(`@${username} takibe alındı, profili yükleniyor...`);
                // 1. Sayfayı hemen bu kullanıcının profiline geçir ve yükleniyor ekranını aç
                navigateTo('profile');
                renderProfileView(username);
                // 2. Kullanıcıyı backend'e ekle
                const res = await fetch('/api/users', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username })
                });
                const data = await res.json().catch(() => ({}));
                if (!res.ok) {
                    throw new Error(data.detail || `HTTP ${res.status}`);
                }
                // 3. Kullanıcı listesini sessizce yenile ve kullanıcı verisini anında uygula
                loadUsers();
                if (data && data.user) {
                    applyUserProfileData(data.user);
                }
                // 4. Profilin tamamen yüklenmesini sağla (sayfayı yenilemeye gerek kalmadan otomatik polling)
                autoPollProfileUntilLoaded(username);
            } catch(e) {
                console.error("Hesap eklenirken hata:", e);
                showToast(`@${username} eklenemedi: ${e.message || 'Bir hata oluştu'}`);
            } finally {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = 'Takip Et & Tara';
                }
            }
        }
        async function addUserByHandle(handle) {
            const clean = (handle || '').replace(/^@/, '').trim();
            if (!clean) return;
            showToast(`@${clean} takibe alındı, profili yükleniyor...`);
            try {
                navigateTo('profile');
                renderProfileView(clean);
                const res = await fetch('/api/users', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username: clean })
                });
                const data = await res.json().catch(() => ({}));
                if (!res.ok) {
                    throw new Error(data.detail || `HTTP ${res.status}`);
                }
                loadUsers();
                if (data && data.user) {
                    applyUserProfileData(data.user);
                }
                autoPollProfileUntilLoaded(clean);
            } catch(e) {
                console.error("Takip hatası:", e);
                showToast(`Takip başlatılamadı: ${e.message || 'Bir hata oluştu'}`);
            }
        }
        async function deleteUser(username) {
            if (!confirm(`@${username} hesabını takipten çıkarmak istiyor musunuz?\nBu hesaba ait gönderiler, resimler ve tüm kayıtlar kalıcı olarak silinecektir.`)) return;

            try {
                await fetch(`/api/users/${username}`, { method: 'DELETE' });
                showToast(`@${username} ve ilgili tüm verileri tamamen silindi`);

                // Eğer tanımlı nickim bu kullanıcı ise tanımlamayı temizle
                if (getMyAccountHandle().toLowerCase() === username.toLowerCase()) {
                    localStorage.removeItem('my_user_handle');
                }

                if (selectedUsername === username || activeProfileUsername === username) {
                    selectedUsername = 'all';
                    navigateTo('home');
                }
                refreshAll();
            } catch (e) {
                alert("İşlem gerçekleştirilemedi.");
            }
        }

        async function refreshUser(username) {
            showToast(`@${username} için yeni gönderiler taranıyor...`);
            try {
                await fetch(`/api/refresh/${username}`, { method: 'POST' });
                refreshAll();
            } catch (e) {
                console.error("Yenileme hatası:", e);
            }
        }

        async function triggerDeepSync(username) {
            showToast(`@${username} için tüm geçmiş gönderi ve retweetler taranıyor, belleğe kaydediliyor...`, 'info');
            try {
                const res = await fetch(`/api/user/${encodeURIComponent(username)}/deep-sync`, { method: 'POST' });
                const data = await res.json();
                if (data.status === 'ok') {
                    showToast(`@${username} tüm arşiv taraması başlatıldı! Arka planda kaydediliyor.`, 'success');
                    setTimeout(() => refreshAll(), 3000);
                }
            } catch (e) {
                console.error("Derin tarama hatası:", e);
                showToast('Derin tarama başlatılamadı.', 'error');
            }
        }

        // ================= 12. SAĞ KOLON: SADECE TAKİP EDİLEN HESAPLAR =================
        async function loadUsers() {
            try {
                const res = await fetch('/api/users');
                const users = await res.json();
                allUsersData = users;

                const badge = document.getElementById('userCountBadge');
                if (badge) badge.innerText = `${users.length} takip`;

                updateBottomLeftProfile();

                const list = document.getElementById('usersList');
                if (!list) return;

                if (users.length === 0) {
                    list.innerHTML = '<div class="text-xs text-[#71767b] py-3 text-center">Henüz takip edilen hesap yok.<br><span class="text-[11px] text-[#536471]">Yukarıdan @kullanıcıadı yazarak ekleyin.</span></div>';
                } else {
                    let html = '';
                    users.forEach(u => {
                        const initialLetter = u.username.charAt(0).toUpperCase();
                        const lDisplay = u.profile_likes > 0 ? Number(u.profile_likes).toLocaleString('tr-TR') : (u.total_likes_display || '0');
                        const tDisplay = u.total_tweets > 0 ? Number(u.total_tweets).toLocaleString('tr-TR') : (u.post_count || 0);
                        html += `
                            <div data-ext-click="renderProfileView('${u.username}')" class="flex items-center justify-between gap-2.5 p-2 rounded-xl hover:bg-white/[0.03] cursor-pointer transition group">
                                <div class="flex items-center gap-2.5 min-w-0">
                                    <img src="${u.avatar_url || ''}"
                                         data-remote="${u.avatar_url || ''}"
                                         loading="lazy"
                                         decoding="async"
                                         data-ext-error="handleAvatarError(this, '${initialLetter}')"
                                         class="w-10 h-10 rounded-full object-cover border border-[#2f3336] bg-[#16181c] shrink-0"
                                         alt="@${u.username}">
                                    <div class="min-w-0 text-left">
                                        <div class="font-bold text-sm text-[#e7e9ea] truncate group-hover:underline flex items-center gap-1">
                                            <span>${escapeHtml(u.display_name || u.username)}</span>
                                            <svg viewBox="0 0 24 24" class="w-3.5 h-3.5 fill-[#1d9bf0] shrink-0"><g><path d="M22.25 12c0-1.43-.88-2.67-2.19-3.34.46-1.39.2-2.9-.81-3.91s-2.52-1.27-3.91-.81c-.66-1.31-1.91-2.19-3.34-2.19s-2.67.88-3.33 2.19c-1.4-.46-2.91-.2-3.92.81s-1.26 2.52-.8 3.91c-1.31.67-2.2 1.91-2.2 3.34s.89 2.67 2.2 3.34c-.46 1.39-.21 2.9.8 3.91s2.52 1.26 3.91.81c.67 1.31 1.91 2.19 3.34 2.19s2.68-.88 3.34-2.19c1.39.45 2.9.2 3.91-.81s1.27-2.52.81-3.91c1.31-.67 2.19-1.91 2.19-3.34zm-11.71 4.2L6.8 12.46l1.41-1.42 2.26 2.26 4.8-5.23 1.47 1.36-6.2 6.77z"></path></g></svg>
                                        </div>
                                        <div class="text-xs text-[#71767b] truncate">@${u.username}</div>
                                        <div class="text-[11px] text-[#71767b] flex items-center gap-2 mt-0.5">
                                            <span class="text-[#f91880] flex items-center gap-1 font-medium"><i class="fa-solid fa-heart text-[9px]"></i> ${lDisplay}</span>
                                            <span>•</span>
                                            <span>${tDisplay} gönderi</span>
                                        </div>
                                    </div>
                                </div>
                                <button data-ext-click="event.stopPropagation(); deleteUser('${u.username}')" class="px-3.5 py-1.5 bg-[#eff3f4] hover:bg-[#d7dbdc] text-black font-bold text-xs rounded-full transition shrink-0 group-hover:hover:bg-[#f4212e]/10 group-hover:hover:text-[#f4212e] group-hover:hover:border-[#f4212e] border border-transparent" title="Takipten Çık">
                                    <span>Takip ediliyor</span>
                                </button>
                            </div>
                        `;
                    });
                    list.innerHTML = html;
                }
            } catch (e) {
                console.error("Kullanıcılar yüklenemedi:", e);
            }
        }

        // ================= 13. İSTATİSTİKLER VE AKTİVİTE LOGLARI =================
        async function fetchStats(selectedUser = null) {
            try {
                const res = await fetch(`/api/stats?username=${encodeURIComponent(selectedUser || 'all')}`);
                const data = await res.json();

                const trendDelEl = document.getElementById('trendDeletedCount');
                if (trendDelEl) trendDelEl.innerText = `${data.total_deleted || 0} silinmiş tespit`;

                const uEl = document.getElementById('statModalUsers');
                const pEl = document.getElementById('statModalPosts');
                const dEl = document.getElementById('statModalDeleted');
                const lEl = document.getElementById('statModalLikes');
                if (uEl) uEl.innerText = data.total_users || 0;
                if (pEl) pEl.innerText = Number(data.total_archived || 0).toLocaleString('tr-TR');
                if (dEl) dEl.innerText = data.total_deleted || 0;
                if (lEl) lEl.innerText = Number(data.total_likes || 0).toLocaleString('tr-TR');
            } catch (e) {}
        }

        let seenLogIds = new Set();
        let hasInitializedLogs = false;

        async function loadLogs() {
            try {
                const res = await fetch('/api/logs?limit=40');
                const logs = await res.json();
                allLogsData = logs;

                const modalLogsEl = document.getElementById('statModalRecentLogs');
                if (modalLogsEl) {
                    if (!logs || logs.length === 0) {
                        modalLogsEl.innerHTML = '<div class="text-[#536471]">Henüz sistem kaydı yok.</div>';
                    } else {
                        modalLogsEl.innerHTML = logs.slice(0, 6).map(item => `
                            <div class="flex items-start justify-between gap-2 bg-[#16181c] border border-[#2f3336] rounded-lg px-2.5 py-1.5">
                                <span class="text-[#e7e9ea] truncate">${escapeHtml(item.action || '')}</span>
                                <span class="text-[10px] text-[#71767b] shrink-0 font-mono">${escapeHtml((item.timestamp || '').split(' ')[1] || item.timestamp || '')}</span>
                            </div>
                        `).join('');
                    }
                }

                if (logs.length > 0) {
                    if (hasInitializedLogs) {
                        for (let i = logs.length - 1; i >= 0; i--) {
                            const item = logs[i];
                            if (!seenLogIds.has(item.id)) {
                                showNotificationToast(item);
                                const dot = document.getElementById('navNotifDot');
                                if (dot) dot.classList.remove('hidden');
                            }
                        }
                    }
                    logs.forEach(l => seenLogIds.add(l.id));
                    hasInitializedLogs = true;
                }
            } catch (e) {}
        }

        function showNotificationToast(log) {
            const container = document.getElementById('toastContainer');
            if (!container) return;

            let icon = 'fa-solid fa-bell text-[#1d9bf0]';
            if (log.action.includes('❤️')) icon = 'fa-solid fa-heart text-[#f91880]';
            else if (log.action.includes('SİLİNDİ')) icon = 'fa-solid fa-triangle-exclamation text-[#f4212e] animate-pulse';
            else if (log.action.includes('Yeni gönderi')) icon = 'fa-solid fa-sparkles text-[#00ba7c]';

            const toast = document.createElement('div');
            toast.className = 'toast-item pointer-events-auto bg-[#16181c]/95 backdrop-blur-md border border-[#2f3336] shadow-2xl rounded-2xl p-3 flex items-start gap-3 transition-all duration-300 opacity-0 translate-x-8 text-xs max-w-sm';
            toast.innerHTML = `
                <div class="w-7 h-7 rounded-full bg-white/5 flex items-center justify-center shrink-0 mt-0.5">
                    <i class="${icon}"></i>
                </div>
                <div class="flex-1 min-w-0">
                    <div class="font-bold text-white text-[13px] leading-tight">${escapeHtml(log.action)}</div>
                    <div class="text-[11px] text-[#71767b] mt-0.5">${log.timestamp || 'Az önce'}</div>
                </div>
            `;
            container.appendChild(toast);

            requestAnimationFrame(() => {
                toast.classList.remove('opacity-0', 'translate-x-8');
                toast.classList.add('opacity-100', 'translate-x-0');
            });

            setTimeout(() => {
                toast.classList.remove('opacity-100', 'translate-x-0');
                toast.classList.add('opacity-0', 'translate-x-8');
                setTimeout(() => toast.remove(), 350);
            }, 5500);
        }

        function showToast(msg) {
            const container = document.getElementById('toastContainer');
            if (!container) return;
            const toast = document.createElement('div');
            toast.className = 'pointer-events-auto bg-[#1d9bf0] text-white font-bold text-xs py-2 px-4 rounded-full shadow-lg transition-all duration-300 opacity-0 translate-y-2';
            toast.innerText = msg;
            container.appendChild(toast);
            requestAnimationFrame(() => {
                toast.classList.remove('opacity-0', 'translate-y-2');
                toast.classList.add('opacity-100', 'translate-y-0');
            });
            setTimeout(() => {
                toast.classList.remove('opacity-100', 'translate-y-0');
                toast.classList.add('opacity-0', 'translate-y-2');
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        // ================= VİDEO OYNATMA VE AKIŞ YÖNETİCİSİ =================
        function toggleInlineVideo(event, videoEl) {
            if (event) {
                event.stopPropagation();
            }
            if (!videoEl) return;
            if (videoEl.paused) {
                videoEl.play().catch(err => {
                    console.warn("Otomatik oynatma engellendi, proxy deneniyor:", err);
                    if (videoEl.dataset.proxy && videoEl.src !== videoEl.dataset.proxy) {
                        videoEl.src = videoEl.dataset.proxy;
                        videoEl.load();
                        videoEl.play().catch(e => console.error("Proxy video oynatılamadı:", e));
                    }
                });
            } else {
                videoEl.pause();
            }
        }
        async function playInlineVideo(containerEl, postId, fallbackPoster, event) {
            if (event) {
                event.stopPropagation();
                event.preventDefault();
            }
            if (!containerEl || !postId) return;
            const existingVid = containerEl.querySelector('video');
            if (existingVid) {
                toggleInlineVideo(event, existingVid);
                return;
            }
            const playIcon = containerEl.querySelector('.fa-play');
            if (playIcon) {
                playIcon.className = "fa-solid fa-circle-notch fa-spin text-xl text-white";
            }
            try {
                const resp = await fetch(`/api/tweet/${postId}/video-url`);
                const data = await resp.json();
                if (data.status === 'ok' && data.video_url) {
                    const vidUrl = data.video_url;
                    const proxyUrl = data.proxy_url || toProxyMediaUrl(vidUrl);
                    const poster = data.poster || fallbackPoster || '';
                    const safePoster = toProxyMediaUrl(poster);
                    containerEl.removeAttribute('onclick');
                    containerEl.setAttribute('data-ext-click', 'stopCardEvent(event)');
                    containerEl.onclick = stopCardEvent;
                    containerEl.className = "relative bg-black flex items-center justify-center overflow-hidden rounded-xl border border-[#2f3336] max-h-[480px] w-full";
                    containerEl.innerHTML = '';

                    const vidEl = document.createElement('video');
                    vidEl.src = proxyUrl;
                    vidEl.dataset.direct = vidUrl;
                    if (safePoster) vidEl.poster = safePoster;
                    vidEl.controls = true;
                    vidEl.autoplay = true;
                    vidEl.playsInline = true;
                    vidEl.preload = 'none';
                    vidEl.className = 'w-full max-h-[480px] object-contain rounded-xl';
                    vidEl.addEventListener('error', () => {
                        if (vidEl.dataset.direct && vidEl.src !== vidEl.dataset.direct) {
                            vidEl.src = vidEl.dataset.direct;
                            vidEl.load();
                            vidEl.play().catch(() => {});
                        }
                    });
                    containerEl.appendChild(vidEl);
                    vidEl.play().catch(e => console.warn("Video play note:", e));
                    return;
                }
            } catch (err) {
                console.error("Video URL çözümleme hatası:", err);
            }
            showToast("Video yüklenemedi, tweet detayı açılıyor...", "info");
            openTweetDetail(postId);
        }
        // ================= MEDYA VE VİDEO ÇİFTLEME ENGELLEYİCİ =================
        function getDeduplicatedMedia(mediaList) {
            if (!mediaList || !Array.isArray(mediaList) || mediaList.length === 0) return [];
            const playableVideos = [];
            const videoPosters = new Set();
            const otherMedias = [];
            mediaList.forEach(m => {
                let mSrc = typeof m === 'string' ? m : (m.url || m.local_url || m.remote_url || '');
                if (!mSrc) return;
                let isMp4 = (mSrc.includes('.mp4') || mSrc.includes('/media/videos/') || mSrc.includes('video.twimg.com') || mSrc.includes('.m3u8')) && !mSrc.match(/\.(jpg|jpeg|png|webp|gif)($|\?)/i);
                if (isMp4) {
                    playableVideos.push(m);
                    if (typeof m === 'object') {
                        if (m.poster) videoPosters.add(m.poster.split('?')[0].split('/').pop());
                        if (m.remote_poster) videoPosters.add(m.remote_poster.split('?')[0].split('/').pop());
                    }
                } else {
                    otherMedias.push(m);
                }
            });
            const result = [];
            const seenKeys = new Set();
            if (playableVideos.length > 0) {
                result.push(playableVideos[0]);
            }
            otherMedias.forEach(m => {
                let mSrc = typeof m === 'string' ? m : (m.url || m.local_url || m.remote_url || '');
                let cleanKey = mSrc.split('?')[0].split('/').pop();
                if (cleanKey.includes('_')) {
                    cleanKey = cleanKey.split('_').slice(1).join('_');
                }
                if (playableVideos.length > 0 && (videoPosters.has(cleanKey) || mSrc.includes('video_thumb') || mSrc.includes('_poster.jpg'))) {
                    return;
                }
                if (seenKeys.has(cleanKey)) return;
                seenKeys.add(cleanKey);
                result.push(m);
            });
            return result;
        }

        // ================= X GÖNDERİ FORMATLAYICI (HASHTAG, MENTION, LİNK) =================
        function formatTweetContent(text) {
            if (!text) return '';
            const escaped = escapeHtml(text);
            return escaped.replace(/(https?:\/\/[^\s<]+)|(?:^|(?<=[\s(>]))@([a-zA-Z0-9_]{1,30})|#([a-zA-Z0-9_\u00C0-\u024F]+)/g, (match, url, mention, hashtag) => {
                if (url) {
                    return `<a href="${url}" target="_blank" data-ext-click="event.stopPropagation()" class="text-[#1d9bf0] hover:underline">${url}</a>`;
                }
                if (mention) {
                    return `<span class="text-[#1d9bf0] hover:underline cursor-pointer" data-ext-click="event.stopPropagation(); renderProfileView('${escapeJsArg(mention)}')">@${mention}</span>`;
                }
                if (hashtag) {
                    return `<span class="text-[#1d9bf0] hover:underline cursor-pointer" data-ext-click="event.stopPropagation(); openSearchPage('#${escapeJsArg(hashtag)}')">#${hashtag}</span>`;
                }
                return match;
            });
        }

        // ================= HERO TWEET BÜYÜK STATUS KARTI =================
        function renderTweetHero(p) {
            const isDeleted = p.is_deleted === 1;
            const isRetweet = p.is_retweet === 1;
            const author = isRetweet ? (p.original_author || p.username) : p.username;
            const name = isRetweet ? (p.original_name || author) : (p.original_name || author);
            const initial = (author || 'X').charAt(0).toUpperCase();
            const avatar = p.author_avatar || '';

            // Medya (Tıkla-Yükle / Otomatik modu buildMediaGalleryHtml yönetir)
            const heroMediaCount = getDeduplicatedMedia(p.media_urls).length;
            const mediaHtml = buildMediaGalleryHtml(p.media_urls, p.post_id, {
                wrapperClass: `grid ${heroMediaCount >= 2 ? 'grid-cols-2' : 'grid-cols-1'} gap-2 rounded-2xl overflow-hidden mt-3 max-h-[500px] border border-[#2f3336]`,
                maxHClass: 'max-h-[480px]',
                roundedClass: 'rounded-xl',
                altLabel: 'Medya'
            });

            // Alıntı Tweet
            let quoteHtml = '';
            const hasQuote = p.is_quote === 1 || (p.quoted_content && p.quoted_content.length > 0) || p.quoted_post_id;
            if (hasQuote) {
                const qAuthor = p.quoted_author || '';
                const qName = p.quoted_name || qAuthor || 'Kullanıcı';
                const qAvatar = p.quoted_avatar || '';
                const qInitial = (qAuthor || qName || 'X').charAt(0).toUpperCase();

                const heroQMediaCount = getDeduplicatedMedia(p.quoted_media_urls).length;
                const qMediaHtml = buildMediaGalleryHtml(p.quoted_media_urls, p.quoted_post_id || p.post_id, {
                    wrapperClass: `grid ${heroQMediaCount >= 2 ? 'grid-cols-2' : 'grid-cols-1'} gap-1.5 rounded-xl overflow-hidden mt-2 max-h-[260px] border border-[#2f3336]`,
                    maxHClass: 'max-h-[240px]',
                    roundedClass: 'rounded-lg',
                    altLabel: 'Alıntı Medyası'
                });

                quoteHtml = `
                    <div class="mt-3 border border-[#2f3336] rounded-2xl p-3 bg-black/40 hover:bg-white/[0.02] transition cursor-pointer" data-ext-click="${p.quoted_post_id ? `openTweetDetail('${escapeJsArg(p.quoted_post_id)}', '${escapeJsArg(qAuthor)}')` : (qAuthor ? `renderProfileView('${escapeJsArg(qAuthor)}')` : '')}">
                        <div class="flex items-center gap-2 mb-1.5">
                            <img src="${qAvatar}" loading="lazy" decoding="async" data-ext-error="handleAvatarError(this, '${escapeJsArg(qInitial)}')" class="w-5 h-5 rounded-full object-cover border border-[#2f3336] bg-[#16181c]">
                            <span class="font-bold text-xs text-[#e7e9ea] truncate">${escapeHtml(qName)}</span>
                            <span class="text-xs text-[#71767b] truncate">@${escapeHtml(qAuthor)}</span>
                        </div>
                        <div class="text-[14px] leading-snug text-[#e7e9ea] font-normal whitespace-pre-line">${escapeHtml(p.quoted_content || '')}</div>
                        ${qMediaHtml}
                    </div>
                `;
            }

            const heroBookmarked = isPostBookmarked(p.post_id);

            return `
                <article class="p-4 bg-black">
                    ${isDeleted ? `
                        <div class="mb-3 px-3 py-1.5 bg-[#f4212e]/10 border border-[#f4212e]/30 rounded-lg text-xs text-[#f4212e] font-semibold flex items-center gap-2">
                            <i class="fa-solid fa-trash-can"></i>
                            <span>Bu gönderi silinmiştir ancak arşivde korunmaktadır.</span>
                        </div>
                    ` : ''}
                    ${(p.is_reply || p.reply_to_username) ? `
                        <div class="flex items-center gap-1.5 text-sm text-[#71767b] mb-3 font-normal">
                            <span>Yanıtlanan kişi:</span>
                            <span data-ext-click="event.stopPropagation(); renderProfileView('${escapeJsArg((p.reply_to_username || '').replace('@',''))}')" class="text-[#1d9bf0] hover:underline cursor-pointer font-medium">@${escapeHtml((p.reply_to_username || '').replace('@','')) || 'kullanıcı'}</span>
                        </div>
                    ` : ''}
                    ${isRetweet ? `
                        <div class="flex items-center gap-2 text-xs text-[#71767b] font-bold mb-2">
                            <i class="fa-solid fa-retweet text-[#00ba7c]"></i>
                            <span><a href="#" data-ext-click="event.preventDefault(); renderProfileView('${escapeJsArg(p.username)}')" class="hover:underline text-[#71767b]">@${escapeHtml(p.username)}</a> repost etti</span>
                        </div>
                    ` : ''}
                    <div class="flex items-center justify-between mb-3">
                        <div class="flex items-center gap-3 cursor-pointer" data-ext-click="renderProfileView('${escapeJsArg(author)}')">
                            <img src="${avatar}" loading="lazy" decoding="async" referrerpolicy="no-referrer" data-ext-error="handleAvatarError(this, '${escapeJsArg(initial)}')" class="w-12 h-12 rounded-full object-cover border border-[#2f3336] bg-[#16181c]">
                            <div class="min-w-0">
                                <div class="font-bold text-[15px] text-[#e7e9ea] hover:underline flex items-center gap-1.5">
                                    <span class="truncate">${escapeHtml(name)}</span>
                                    <svg viewBox="0 0 24 24" class="w-4 h-4 fill-[#1d9bf0] shrink-0"><g><path d="M22.25 12c0-1.43-.88-2.67-2.19-3.34.46-1.39.2-2.9-.81-3.91s-2.52-1.27-3.91-.81c-.66-1.31-1.91-2.19-3.34-2.19s-2.67.88-3.33 2.19c-1.4-.46-2.91-.2-3.92.81s-1.26 2.52-.8 3.91c-1.31.67-2.2 1.91-2.2 3.34s.89 2.67 2.2 3.34c-.46 1.39-.21 2.9.8 3.91s2.52 1.26 3.91.81c.67 1.31 1.91 2.19 3.34 2.19s2.68-.88 3.34-2.19c1.39.45 2.9.2 3.91-.81s1.27-2.52.81-3.91c1.31-.67 2.19-1.91 2.19-3.34zm-11.71 4.2L6.8 12.46l1.41-1.42 2.26 2.26 4.8-5.23 1.47 1.36-6.2 6.77z"></path></g></svg>
                                </div>
                                <div class="text-sm text-[#71767b]">@${escapeHtml(author)}</div>
                            </div>
                        </div>
                        <a href="https://x.com/${encodeURIComponent(author)}/status/${encodeURIComponent(p.post_id)}" target="_blank" class="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center text-[#71767b] hover:text-[#1d9bf0] transition" title="X'te Orijinalini Aç">
                            <i class="fa-brands fa-x-twitter text-base"></i>
                        </a>
                    </div>

                    <div class="text-[17px] leading-relaxed text-[#e7e9ea] font-normal whitespace-pre-line break-words my-3">
                        ${formatTweetContent(p.content || '')}
                    </div>

                    ${mediaHtml}
                    ${quoteHtml}

                    <div class="py-3 mt-3 border-b border-[#2f3336] text-[14px] text-[#71767b] flex items-center gap-2 flex-wrap">
                        <span>${formatTweetDate(p.posted_at, true)}</span>
                        <span>·</span>
                        <span class="text-white font-semibold">${Number(p.views || (Number(p.likes || 0) * 8 + 42)).toLocaleString('tr-TR')}</span>
                        <span>Görüntülenme</span>
                    </div>

                    <div class="py-3 border-b border-[#2f3336] flex items-center gap-6 text-sm text-[#71767b]">
                        <div><strong class="text-white font-bold">${Number(p.retweets || 0).toLocaleString('tr-TR')}</strong> Repost</div>
                        <div><strong class="text-white font-bold">${Number(p.likes || 0).toLocaleString('tr-TR')}</strong> Beğeni</div>
                        <div><strong class="text-white font-bold">${Number(p.replies || 0).toLocaleString('tr-TR')}</strong> Yanıt</div>
                    </div>

                    <div class="py-2.5 flex items-center justify-around text-[#71767b] text-lg border-b border-[#2f3336]">
                        <button type="button" data-ext-click="focusDetailNote()" class="hover:text-[#1d9bf0] transition flex items-center gap-1.5 text-sm font-medium" title="Kişisel Arşiv Notu Ekle">
                            <i class="fa-regular fa-note-sticky text-base"></i><span class="hidden sm:inline">Not Ekle</span>
                        </button>
                        <button type="button" data-ext-click="renderProfileView('${escapeJsArg(author)}')" class="hover:text-[#00ba7c] transition flex items-center gap-1.5 text-sm font-medium" title="Yazar Profilini Aç">
                            <i class="fa-regular fa-user text-base"></i><span class="hidden sm:inline">Profil</span>
                        </button>
                        <button type="button" data-ext-click="copyDetailPostText('${escapeJsArg(p.post_id)}')" class="hover:text-[#f91880] transition flex items-center gap-1.5 text-sm font-medium" title="Gönderi Metnini Kopyala">
                            <i class="fa-regular fa-copy text-base"></i><span class="hidden sm:inline">Metni Kopyala</span>
                        </button>
                        <button type="button" id="heroBookmarkBtn" data-ext-click="toggleBookmark('${escapeJsArg(p.post_id)}')" class="${heroBookmarked ? 'text-[#1d9bf0]' : ''} hover:text-[#1d9bf0] transition flex items-center gap-1.5" title="Yer İmlerine Ekle / Çıkar">
                            <i id="heroBookmarkIcon" class="${heroBookmarked ? 'fa-solid fa-bookmark text-[#1d9bf0]' : 'fa-regular fa-bookmark'}"></i>
                        </button>
                        <button type="button" data-ext-click="navigator.clipboard.writeText('https://x.com/${escapeJsArg(author)}/status/${escapeJsArg(p.post_id)}'); showToast('Bağlantı kopyalandı!')" class="hover:text-[#1d9bf0] transition flex items-center gap-1.5" title="Bağlantıyı Kopyala">
                            <i class="fa-solid fa-arrow-up-from-bracket"></i>
                        </button>
                    </div>
                </article>
            `;
        }

        // ================= TWEET YORUM KARTI (X FORMATINDA CANLI YORUMLAR) =================
        function renderCommentCard(c) {
            const initial = (c.username || 'X').charAt(0).toUpperCase();
            const commentMediaHtml = (c.media_urls && c.media_urls.length > 0)
                ? buildMediaGalleryHtml(c.media_urls, c.id || '', {
                    wrapperClass: `grid grid-cols-${c.media_urls.length >= 2 ? '2' : '1'} gap-1.5 rounded-xl overflow-hidden my-2 max-h-[280px] border border-[#2f3336]`,
                    maxHClass: 'max-h-[260px]',
                    roundedClass: 'rounded-lg',
                    altLabel: 'Yorum Medyası',
                    hideOnError: true
                })
                : '';
            return `
                <article class="p-4 hover:bg-white/[0.02] transition flex gap-3">
                    <div class="shrink-0 cursor-pointer" data-ext-click="renderProfileView('${c.username}')">
                        <img src="${c.avatar || ''}" loading="lazy" decoding="async" referrerpolicy="no-referrer" data-ext-error="handleAvatarError(this, '${initial}')" class="w-10 h-10 rounded-full object-cover border border-[#2f3336] bg-[#16181c]">
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between mb-1">
                            <div class="flex items-center gap-1.5 min-w-0">
                                <span class="font-bold text-[14px] text-[#e7e9ea] truncate hover:underline cursor-pointer" data-ext-click="renderProfileView('${c.username}')">${escapeHtml(c.name || c.username)}</span>
                                <span class="text-xs text-[#71767b] truncate">@${escapeHtml(c.username)}</span>
                                <span class="text-xs text-[#71767b]">·</span>
                                <span class="text-xs text-[#71767b]">${c.time || ''}</span>
                            </div>
                            <button class="text-xs text-[#71767b] hover:text-white"><i class="fa-solid fa-ellipsis"></i></button>
                        </div>
                        <div class="text-[14px] leading-relaxed text-[#e7e9ea] whitespace-pre-line break-words mb-2">
                            ${formatTweetContent(c.text || '')}
                        </div>
                        ${commentMediaHtml}
                        <div class="flex items-center gap-8 text-xs text-[#71767b] pt-1">
                            <button class="hover:text-[#1d9bf0] flex items-center gap-1.5 transition">
                                <i class="fa-regular fa-comment"></i>
                                <span>${c.replies || ''}</span>
                            </button>
                            <button class="hover:text-[#00ba7c] flex items-center gap-1.5 transition">
                                <i class="fa-solid fa-retweet"></i>
                                <span>${c.retweets || ''}</span>
                            </button>
                            <button class="hover:text-[#f91880] flex items-center gap-1.5 transition">
                                <i class="fa-regular fa-heart"></i>
                                <span>${c.likes ? Number(c.likes).toLocaleString('tr-TR') : ''}</span>
                            </button>
                            <button data-ext-click="navigator.clipboard.writeText('https://x.com/${c.username}/status/${c.id}'); showToast('Bağlantı kopyalandı!')" class="hover:text-[#1d9bf0] transition">
                                <i class="fa-solid fa-arrow-up-from-bracket"></i>
                            </button>
                        </div>
                    </div>
                </article>
            `;
        }

        // ================= 14. TWEET DETAY VE YORUMLAR (DEDICATED FULL STATUS PAGE) =================
        let tweetCommentsPostId = null;
        let tweetCommentsAuthor = null;
        let tweetCommentsOffset = 0;
        const TWEET_COMMENTS_PAGE_SIZE = 8;
        let tweetCommentsHasMore = true;
        let isLoadingTweetComments = false;
        let tweetCommentsTotal = 0;

        async function openTweetDetail(postId, authorFallback = '') {
            if (currentView !== 'tweet') {
                previousView = currentView;
                if (currentView === 'profile') {
                    previousProfileUser = activeProfileUsername;
                } else if (currentView === 'search') {
                    previousSearchQuery = currentSearchQuery;
                    previousSearchTab = currentSearchTab;
                }
            }

            currentView = 'tweet';
            document.querySelectorAll('.page-view').forEach(el => el.classList.add('hidden'));
            const tweetView = document.getElementById('view-tweet');
            if (tweetView) tweetView.classList.remove('hidden');

            const homeTabs = document.getElementById('homeTabsContainer');
            if (homeTabs) homeTabs.classList.add('hidden');
            const headerSearch = document.getElementById('headerSearchContainer');
            if (headerSearch) headerSearch.classList.add('hidden');
            const backBtn = document.getElementById('mainBackBtn');
            if (backBtn) backBtn.classList.remove('hidden');
            const mainTitle = document.getElementById('mainHeaderTitle');
            if (mainTitle) {
                mainTitle.innerText = 'Gönderi';
                mainTitle.classList.remove('hidden');
            }
            const sub = document.getElementById('mainHeaderSubtitle');
            if (sub) sub.classList.add('hidden');
            activeDetailPostId = postId;
            syncDetailNoteUI(postId);

            // Yanıt kutusu için profil avatarı
            const myAv = document.getElementById('myAvatarImg');
            const replyAv = document.getElementById('detailReplyAvatar');
            if (myAv && replyAv && myAv.src) replyAv.src = myAv.src;

            window.scrollTo({ top: 0, behavior: 'instant' });

            let post = allLoadedPostsMap[postId] || currentLoadedPosts.find(x => x.post_id === postId) || (typeof profileCachedPosts !== 'undefined' ? profileCachedPosts.find(x => x.post_id === postId) : null);

            const detailContent = document.getElementById('tweetDetailPageContent');
            if (post && detailContent) {
                detailContent.innerHTML = renderTweetHero(post);
                recordProfileVisit(post.original_author || post.username);
            } else if (detailContent) {
                detailContent.innerHTML = `
                    <div class="p-8 text-center text-[#71767b]">
                        <i class="fa-solid fa-circle-notch fa-spin text-2xl text-[#1d9bf0] mb-3"></i>
                        <div class="text-sm">Gönderi ve medya yükleniyor...</div>
                    </div>
                `;
                // Sunucudan bu tweet'i doğrudan getir ve başlığı tazele
                fetch(`/api/posts/${encodeURIComponent(postId)}`)
                    .then(r => r.ok ? r.json() : fetch(`/api/posts?search=${encodeURIComponent(postId)}`).then(res => res.json()).then(arr => (Array.isArray(arr) ? arr[0] : null)))
                    .then(singlePost => {
                        if (singlePost) {
                            post = singlePost;
                            allLoadedPostsMap[postId] = post;
                            if (currentView === 'tweet' && detailContent) {
                                detailContent.innerHTML = renderTweetHero(post);
                                recordProfileVisit(post.original_author || post.username);
                            }
                        }
                    }).catch(err => {
                        console.error("Hero tweet detayı yüklenemedi:", err);
                    });
            }

            const targetUser = (post && (post.original_author || post.username)) || authorFallback || 'i';

            tweetCommentsPostId = postId;
            tweetCommentsAuthor = targetUser;
            tweetCommentsOffset = 0;
            tweetCommentsHasMore = true;
            isLoadingTweetComments = false;
            tweetCommentsTotal = 0;

            const commentsList = document.getElementById('tweetCommentsList');
            const countBadge = document.getElementById('tweetCommentsCountBadge');
            const sentinel = document.getElementById('tweetCommentsSentinel');
            if (countBadge) countBadge.innerText = '';
            if (sentinel) sentinel.classList.add('hidden');
            if (commentsList) {
                commentsList.innerHTML = `
                    <div class="py-12 flex flex-col items-center justify-center text-[#71767b]">
                        <i class="fa-solid fa-circle-notch fa-spin text-2xl mb-3 text-[#1d9bf0]"></i>
                        <span class="text-sm font-medium">X'ten yanıtlar ve yorumlar yükleniyor...</span>
                    </div>
                `;
            }

            await loadMoreTweetComments(true);
        }

        async function loadMoreTweetComments(isInitial = false) {
            if (isLoadingTweetComments || (!tweetCommentsHasMore && !isInitial)) return;
            if (!tweetCommentsPostId) return;

            isLoadingTweetComments = true;
            const commentsList = document.getElementById('tweetCommentsList');
            const countBadge = document.getElementById('tweetCommentsCountBadge');
            const sentinel = document.getElementById('tweetCommentsSentinel');

            if (sentinel && !isInitial) {
                sentinel.classList.remove('hidden');
                sentinel.innerHTML = `
                    <i class="fa-solid fa-circle-notch fa-spin text-xl text-[#1d9bf0]"></i>
                    <span class="text-xs ml-2 font-medium">Daha fazla yanıt yükleniyor...</span>
                `;
            }

            try {
                const res = await fetch(`/api/tweet/${encodeURIComponent(tweetCommentsAuthor)}/${tweetCommentsPostId}/comments?limit=${TWEET_COMMENTS_PAGE_SIZE}&offset=${tweetCommentsOffset}`);
                const data = await res.json();
                const comments = data.comments || (Array.isArray(data) ? data : []);

                tweetCommentsTotal = data.total !== undefined ? data.total : comments.length;
                if (countBadge) {
                    countBadge.innerText = tweetCommentsTotal > 0 ? `${tweetCommentsTotal} yanıt` : '';
                }

                if (isInitial) {
                    if (!comments || comments.length === 0) {
                        if (commentsList) {
                            commentsList.innerHTML = `
                                <div class="py-16 text-center text-[#71767b]">
                                    <i class="fa-regular fa-comment text-4xl mb-3 text-[#2f3336]"></i>
                                    <div class="text-sm font-semibold text-[#e7e9ea]">Henüz hiç yanıt yok</div>
                                    <div class="text-xs text-[#71767b] mt-1">Sohbeti başlatan ilk kişi sen ol.</div>
                                </div>
                            `;
                        }
                        tweetCommentsHasMore = false;
                        if (sentinel) sentinel.classList.add('hidden');
                        return;
                    }
                    if (commentsList) {
                        commentsList.innerHTML = comments.map(renderCommentCard).join('');
                    }
                } else {
                    if (comments && comments.length > 0 && commentsList) {
                        const tempDiv = document.createElement('div');
                        tempDiv.innerHTML = comments.map(renderCommentCard).join('');
                        while (tempDiv.firstChild) {
                            commentsList.appendChild(tempDiv.firstChild);
                        }
                    }
                }

                tweetCommentsOffset += comments.length;
                if (data.has_more !== undefined) {
                    tweetCommentsHasMore = !!data.has_more;
                } else {
                    tweetCommentsHasMore = comments.length >= TWEET_COMMENTS_PAGE_SIZE;
                }

                if (sentinel) {
                    if (tweetCommentsHasMore) {
                        sentinel.classList.remove('hidden');
                        sentinel.innerHTML = `
                            <i class="fa-solid fa-circle-notch fa-spin text-xl text-[#1d9bf0]"></i>
                            <span class="text-xs ml-2 font-medium">Daha fazla yanıt yükleniyor...</span>
                        `;
                    } else {
                        if (tweetCommentsTotal > 4) {
                            sentinel.classList.remove('hidden');
                            sentinel.innerHTML = `
                                <div class="text-xs text-[#71767b] py-3 flex items-center justify-center gap-1.5">
                                    <i class="fa-solid fa-check text-[#00ba7c]"></i>
                                    <span>Tüm yanıtlar yüklendi (${tweetCommentsTotal})</span>
                                </div>
                            `;
                        } else {
                            sentinel.classList.add('hidden');
                        }
                    }
                }
            } catch (e) {
                console.error("Yorumlar yüklenemedi:", e);
                if (isInitial && commentsList) {
                    commentsList.innerHTML = '<div class="p-8 text-center text-[#71767b] text-sm">Yorumlar yüklenirken bir sorun oluştu.</div>';
                }
                if (sentinel) sentinel.classList.add('hidden');
            } finally {
                isLoadingTweetComments = false;
            }
        }

        function closeTweetDetail() {
            returnToPostsFeed();
        }

        // ================= 15. YARDIMCI VE MODAL FONKSİYONLARI =================

        // ================= CANLI AKTİVİTE & UYKU TAHMİNİ MODALİ =================
        // Aktif period durumu (modal kapanınca sıfırlanmaz, kullanıcı değiştirince güncellenir)
        let _actPredUsername = '';
        let _actPredPeriod = 'all';
        let _actPredLastData = null;
        // Period filtresi butonlarını güncelle
        function _actPredUpdatePeriodBtns(period) {
            document.querySelectorAll('.act-period-btn').forEach(btn => {
                const isActive = btn.dataset.period === period;
                btn.className = isActive
                    ? 'act-period-btn px-2 py-0.5 rounded-full text-[11px] font-semibold border border-[#1d9bf0] text-[#1d9bf0] transition'
                    : 'act-period-btn px-2 py-0.5 rounded-full text-[11px] font-semibold border border-[#2f3336] text-[#71767b] hover:border-[#1d9bf0] hover:text-[#1d9bf0] transition';
            });
        }
        // Sadece grafik + listeler kısmını güncelle (profil bilgileri korunur)
        async function _actPredLoadPeriodData(username, period) {
            const likeListEl   = document.getElementById('actPredLikeSurgeList');
            const postListEl   = document.getElementById('actPredPostSurgeList');
            const netLikeEl    = document.getElementById('actPredNetLikeList');
            const barContainer = document.getElementById('actPredBarContainer');
            const peakLikeEl   = document.getElementById('actPredPeakLikeHour');
            const peakPostEl   = document.getElementById('actPredPeakPostHour');
            const sleepEl      = document.getElementById('actPredSleepWindow');
            const statusEl     = document.getElementById('actPredStatusBadge');
            const probEl       = document.getElementById('actPredProbText');
            const hourEl       = document.getElementById('actPredCurrentHour');
            const chronoEl     = document.getElementById('actPredChronotype');
            const chronoDescEl = document.getElementById('actPredChronotypeDesc');
            const peakDaysEl   = document.getElementById('actPredPeakDays');
            const dayDistEl    = document.getElementById('actPredDayDistribution');
            const summaryCard  = document.getElementById('actPredSummaryCard');
            const summaryEl    = document.getElementById('actPredSummaryText');
            const promptText   = document.getElementById('actPredPromptText');
            const loadingEl    = document.getElementById('actPredPeriodLoading');
            if (loadingEl) loadingEl.style.display = 'flex';
            if (likeListEl) likeListEl.innerHTML = '<span class="text-xs text-[#71767b] animate-pulse">Hesaplanıyor...</span>';
            if (postListEl) postListEl.innerHTML = '<span class="text-xs text-[#71767b] animate-pulse">Hesaplanıyor...</span>';
            if (netLikeEl) netLikeEl.innerHTML = '<span class="text-xs text-[#71767b] animate-pulse">Hesaplanıyor...</span>';
            if (barContainer) barContainer.innerHTML = '<div class="w-full text-center text-xs text-[#71767b] py-4 animate-pulse">Yükleniyor...</div>';
            _actPredUpdatePeriodBtns(period);
            try {
                const res = await fetch(`/api/user/${encodeURIComponent(username)}/activity-prediction?period=${encodeURIComponent(period)}`);
                const data = await res.json();
                _actPredLastData = data;
                if (loadingEl) loadingEl.style.display = 'none';
                // Durum + Saatler (period'a göre değişir)
                if (hourEl) hourEl.innerText = String(data.current_status?.current_hour ?? new Date().getHours()).padStart(2, '0');
                if (statusEl) {
                    const badge = data.current_status?.status_badge || 'Bilinmiyor';
                    statusEl.innerText = badge;
                    if (badge.includes('Uyuyor')) statusEl.className = 'font-bold text-sm mt-0.5 text-[#f4212e]';
                    else if (data.current_status?.is_online_likely && badge.includes('Zirve')) statusEl.className = 'font-bold text-sm mt-0.5 text-[#00ba7c]';
                    else statusEl.className = 'font-bold text-sm mt-0.5 text-[#ffd400]';
                }
                if (probEl) probEl.innerText = data.current_status?.probability_text || '--';
                if (sleepEl) sleepEl.innerText = data.sleep_window || '--';
                if (chronoEl) chronoEl.innerText = data.chronotype || '--';
                if (chronoDescEl) chronoDescEl.innerText = data.chronotype_desc || '--';
                if (peakDaysEl) peakDaysEl.innerText = data.peak_days || '--';
                if (peakLikeEl) peakLikeEl.innerText = data.peak_like_hour || '--';
                if (peakPostEl) peakPostEl.innerText = data.peak_post_hour || '--';
                if (promptText) promptText.value = data.ai_prompt || '';
                // Summary text
                if (summaryEl && summaryCard && data.summary_text) {
                    summaryEl.innerText = data.summary_text;
                    summaryCard.classList.remove('hidden');
                }
                // Gün İçi Dağılım
                if (dayDistEl) {
                    const dd = {
                        night_pct:     data.night_pct     ?? (data.day_distribution?.night_pct)     ?? 0,
                        morning_pct:   data.morning_pct   ?? (data.day_distribution?.morning_pct)   ?? 0,
                        afternoon_pct: data.afternoon_pct ?? (data.day_distribution?.afternoon_pct) ?? 0,
                        evening_pct:   data.evening_pct   ?? (data.day_distribution?.evening_pct)   ?? 0,
                    };
                    const segments = [
                        { label: '🌙 Gece',  key: 'night_pct',     range: '00-06', color: '#1d9bf0' },
                        { label: '🌅 Sabah', key: 'morning_pct',   range: '06-12', color: '#ffd400' },
                        { label: '☀️ Öğle', key: 'afternoon_pct', range: '12-18', color: '#00ba7c' },
                        { label: '🌆 Akşam', key: 'evening_pct',   range: '18-24', color: '#f91880' },
                    ];
                    let ddHtml = '';
                    segments.forEach(seg => {
                        const pct = Math.round(dd[seg.key] || 0);
                        ddHtml += `<div class="flex items-center gap-2">
                            <span class="text-xs text-[#71767b] w-24 flex-shrink-0">${seg.label} <span class="text-[10px]">(${seg.range})</span></span>
                            <div class="flex-1 bg-[#2f3336] rounded-full h-2 overflow-hidden">
                                <div class="h-2 rounded-full transition-all duration-500" style="width:${pct}%;background:${seg.color};"></div>
                            </div>
                            <span class="text-xs font-bold text-[#e7e9ea] w-9 text-right">%${pct}</span>
                        </div>`;
                    });
                    dayDistEl.innerHTML = ddHtml;
                }
                // Gönderi Saatleri & Beğeni Listesi
                if (likeListEl) {
                    if (data.top_like_hours && data.top_like_hours.length > 0) {
                        let lHtml = '';
                        data.top_like_hours.slice(0, 8).forEach(item => {
                            const incFormatted = Number(item.increase).toLocaleString('tr-TR');
                            const hourLabel = item.hour !== undefined ? `${String(item.hour).padStart(2,'0')}:00` : (item.label || '');
                            lHtml += `<div class="flex items-center justify-between py-0.5 px-2 rounded-lg bg-[#f91880]/10 border border-[#f91880]/20">
                                <span class="text-xs font-mono text-[#f91880] font-bold">${escapeHtml(hourLabel)}</span>
                                <span class="text-xs text-[#e7e9ea] font-semibold">${escapeHtml(incFormatted)} <span class="text-[#71767b] font-normal">beğeni</span></span>
                            </div>`;
                        });
                        likeListEl.innerHTML = lHtml;
                    } else {
                        likeListEl.innerHTML = '<span class="text-xs text-[#71767b]">Bu dönemde gönderi bulunamadı.</span>';
                    }
                }
                // Gönderi Artış Saatleri
                if (postListEl) {
                    if (data.top_post_hours && data.top_post_hours.length > 0) {
                        let pHtml = '';
                        data.top_post_hours.slice(0, 8).forEach(item => {
                            const cntFormatted = Number(item.count).toLocaleString('tr-TR');
                            const hourLabel = item.hour !== undefined ? `${String(item.hour).padStart(2,'0')}:00` : (item.label || '');
                            pHtml += `<div class="flex items-center justify-between py-0.5 px-2 rounded-lg bg-[#1d9bf0]/10 border border-[#1d9bf0]/20">
                                <span class="text-xs font-mono text-[#1d9bf0] font-bold">${escapeHtml(hourLabel)}</span>
                                <span class="text-xs text-[#e7e9ea] font-semibold">${escapeHtml(cntFormatted)} <span class="text-[#71767b] font-normal">gönderi</span></span>
                            </div>`;
                        });
                        postListEl.innerHTML = pHtml;
                    } else {
                        postListEl.innerHTML = '<span class="text-xs text-[#71767b]">Bu dönemde gönderi kaydedilmedi.</span>';
                    }
                }
                // Saatlik Net Beğeni Artışı (like_history delta)
                if (netLikeEl) {
                    if (data.net_like_gains && data.net_like_gains.length > 0) {
                        let nHtml = '';
                        data.net_like_gains.slice(0, 6).forEach(item => {
                            const incFormatted = Number(item.increase).toLocaleString('tr-TR');
                            const hourLabel = item.hour !== undefined ? `${String(item.hour).padStart(2,'0')}:00` : (item.label || '');
                            nHtml += `<div class="flex items-center justify-between py-0.5 px-2 rounded-lg bg-[#00ba7c]/10 border border-[#00ba7c]/20">
                                <span class="text-xs font-mono text-[#00ba7c] font-bold">${escapeHtml(hourLabel)}</span>
                                <span class="text-xs text-[#e7e9ea] font-semibold">+${escapeHtml(incFormatted)} <span class="text-[#71767b] font-normal">net Δ</span></span>
                            </div>`;
                        });
                        netLikeEl.innerHTML = nHtml;
                    } else {
                        netLikeEl.innerHTML = '<span class="text-xs text-[#71767b] col-span-full">Bu dönemde saatlik net beğeni artışı kaydedilmedi.</span>';
                    }
                }
                // 24 Sütunlu Bar Grafiği
                if (barContainer && Array.isArray(data.hourly_distribution)) {
                    let barHtml = '';
                    data.hourly_distribution.forEach(h => {
                        let barHeight = Math.max(4, h.percent);
                        let barColor = "bg-[#71767b]/40";
                        if (h.is_peak) barColor = "bg-[#1d9bf0]";
                        else if (h.is_sleep) barColor = "bg-[#2f3336]";
                        else if (h.is_current) barColor = "bg-white";
                        let borderClass = h.is_current ? "ring-1 ring-white" : "";
                        const likeTxt = h.likes_increase > 0 ? ` • ${Number(h.likes_increase).toLocaleString('tr-TR')} Beğeni` : '';
                        const postTxt = h.posts_increase > 0 ? ` • ${h.posts_increase} Gönderi` : '';
                        const curTxt  = h.is_current ? ' ← Şu an' : '';
                        let tooltip = `${h.label} • %${h.percent} aktif${likeTxt}${postTxt}${curTxt}`;
                        barHtml += `<div class="flex-1 flex flex-col items-center justify-end h-full group relative cursor-pointer" title="${escapeHtml(tooltip)}">
                            <div class="w-full ${barColor} ${borderClass} rounded-t transition duration-300" style="height: ${barHeight}%;"></div>
                        </div>`;
                    });
                    barContainer.innerHTML = barHtml;
                }
            } catch (e) {
                console.error("Aktivite tahmini hatası:", e);
                if (loadingEl) loadingEl.style.display = 'none';
                if (barContainer) barContainer.innerHTML = '<div class="w-full text-center text-xs text-[#f4212e] py-6">Aktivite analizi yüklenemedi.</div>';
            }
        }
        // Period butonu tıklandığında
        function actPredSetPeriod(period) {
            if (!_actPredUsername) return;
            _actPredPeriod = period;
            _actPredLoadPeriodData(_actPredUsername, period);
        }
        async function openActivityPredictionModal(username) {
            const modal = document.getElementById('activityPredictionModal');
            if (!modal) return;
            let targetUser = (username || activeProfileUsername || '').replace(/^@/, '').trim();
            if (!targetUser) return;
            _actPredUsername = targetUser;
            // Period'u sıfırla sadece yeni kullanıcı açılırken
            _actPredPeriod = 'all';
            modal.classList.remove('hidden');
            // Statik element referansları
            const nameEl      = document.getElementById('actPredName');
            const handleEl    = document.getElementById('actPredHandle');
            const avatarEl    = document.getElementById('actPredAvatar');
            const followersEl = document.getElementById('actPredFollowers');
            const followingEl = document.getElementById('actPredFollowing');
            const joinDateEl  = document.getElementById('actPredJoinDate');
            const totalLikesEl  = document.getElementById('actPredTotalLikes');
            const totalTweetsEl = document.getElementById('actPredTotalTweets');
            const summaryCard   = document.getElementById('actPredSummaryCard');
            // Hızlı temizlik (profil alanları)
            if (handleEl)    handleEl.innerText = `@${targetUser}`;
            if (nameEl)      nameEl.innerText = targetUser;
            if (avatarEl)    avatarEl.src = '';
            if (followersEl) followersEl.innerText = '--';
            if (followingEl) followingEl.innerText = '--';
            if (joinDateEl)  joinDateEl.innerText = '--';
            if (totalLikesEl) totalLikesEl.innerText = '...';
            if (totalTweetsEl) totalTweetsEl.innerText = '...';
            if (summaryCard)  summaryCard.classList.add('hidden');
            // Butonları "all" olarak sıfırla
            _actPredUpdatePeriodBtns('all');
            // Önbellek'ten profil bilgisini anında doldur
            const cachedUser = (allUsersData || []).find(x => x.username.toLowerCase() === targetUser.toLowerCase());
            if (cachedUser) {
                if (nameEl && cachedUser.display_name) nameEl.innerText = cachedUser.display_name;
                if (avatarEl && cachedUser.avatar_url)  avatarEl.src = cachedUser.avatar_url;
                if (followersEl && cachedUser.followers_count != null)
                    followersEl.innerText = Number(cachedUser.followers_count).toLocaleString('tr-TR');
                if (followingEl && cachedUser.following_count != null)
                    followingEl.innerText = Number(cachedUser.following_count).toLocaleString('tr-TR');
                if (joinDateEl) {
                    const jd = cachedUser.join_date || cachedUser.added_at || '';
                    if (jd) {
                        try {
                            const dt = new Date(jd);
                            joinDateEl.innerText = dt.toLocaleDateString('tr-TR', { year: 'numeric', month: 'long' });
                        } catch { joinDateEl.innerText = jd.substring(0, 10); }
                    }
                }
            }
            // İlk açılışta API'den profil istatistiklerini de al, ardından period data yükle
            try {
                const res  = await fetch(`/api/user/${encodeURIComponent(targetUser)}/activity-prediction?period=all`);
                const data = await res.json();
                // Profil alanları (sadece ilk yüklemede doldurulur)
                if (nameEl) nameEl.innerText = data.display_name || targetUser;
                if (handleEl) handleEl.innerText = `@${data.username || targetUser}`;
                if (avatarEl) {
                    avatarEl.src = data.avatar_url || (cachedUser ? cachedUser.avatar_url : '');
                    avatarEl.onerror = () => handleAvatarError(avatarEl, (data.username || targetUser).charAt(0).toUpperCase());
                }
                // Takipçi / takip
                if (followersEl && data.followers_count != null)
                    followersEl.innerText = Number(data.followers_count).toLocaleString('tr-TR');
                if (followingEl && data.following_count != null)
                    followingEl.innerText = Number(data.following_count).toLocaleString('tr-TR');
                // Katılma tarihi
                if (joinDateEl) {
                    const jd = data.join_date || (cachedUser ? (cachedUser.join_date || cachedUser.added_at) : '');
                    if (jd) {
                        try {
                            const dt = new Date(jd);
                            joinDateEl.innerText = dt.toLocaleDateString('tr-TR', { year: 'numeric', month: 'long' });
                        } catch { joinDateEl.innerText = String(jd).substring(0, 10); }
                    }
                }
                const finalLikes  = (data.profile_likes > 0 ? data.profile_likes_display : data.total_likes_display) || (data.total_likes > 0 ? Number(data.total_likes).toLocaleString('tr-TR') : '0');
                const finalTweets = data.total_tweets > 0 ? data.total_tweets_display : '0';
                if (totalLikesEl)  totalLikesEl.innerText  = finalLikes;
                if (totalTweetsEl) totalTweetsEl.innerText = finalTweets;
                // Grafik + listeler
                await _actPredLoadPeriodData(targetUser, 'all');
            } catch (e) {
                console.error("Modal açma hatası:", e);
                await _actPredLoadPeriodData(targetUser, 'all');
            }
        }

        function closeActivityPredictionModal() {
            const modal = document.getElementById('activityPredictionModal');
            if (modal) modal.classList.add('hidden');
        }

        function copyActivityPrompt() {
            const textarea = document.getElementById('actPredPromptText');
            if (textarea && textarea.value) {
                navigator.clipboard.writeText(textarea.value).then(() => {
                    showToast("Yapay zeka analiz istemi panoya kopyalandı!");
                }).catch(() => {
                    textarea.select();
                    document.execCommand('copy');
                    showToast("Yapay zeka analiz istemi panoya kopyalandı!");
                });
            }
        }

        function downloadActivityReport() {
            const target = _actPredUsername || 'kullanici';
            const report = {
                exported_at: new Date().toISOString(),
                username: target,
                period: _actPredPeriod || 'all',
                ai_prompt: document.getElementById('actPredPromptText')?.value || '',
                summary_text: document.getElementById('actPredSummaryText')?.innerText || '',
                data: _actPredLastData || {}
            };
            const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `aktivite_rapor_${target}_${report.period}.json`;
            a.click();
            setTimeout(() => URL.revokeObjectURL(url), 5000);
            showToast(`@${target} aktivite raporu indirildi`);
        }

        function openModal(id) {
            const m = document.getElementById(id);
            if (m) m.classList.remove('hidden');
        }

        function closeModal(id) {
            const m = document.getElementById(id);
            if (m) m.classList.add('hidden');
        }

        function openStatsModal() {
            fetchStats();
            syncAutoLoadMediaUI();
            loadMediaCacheStats();
            openModal('statsSummaryModal');
        }

        function closeStatsModal() {
            closeModal('statsSummaryModal');
        }

        function toggleMoreMenu(event) {
            if (event) event.stopPropagation();
            const menu = document.getElementById('moreMenuDropdown');
            const btn = document.getElementById('btnMoreMenu');
            if (!menu || !btn) return;
            const rect = btn.getBoundingClientRect();
            menu.style.left = `${rect.left}px`;
            menu.style.bottom = `${window.innerHeight - rect.top + 8}px`;
            menu.classList.toggle('hidden');
        }

        function handleAvatarError(img, fallbackLetter) {
            img.referrerPolicy = "no-referrer";
            if (img.dataset.remote && img.src !== img.dataset.remote && !img.dataset.failedRemote) {
                img.dataset.failedRemote = "true";
                img.src = img.dataset.remote;
                return;
            }
            const avatarProxy = toProxyMediaUrl(img.dataset.remote);
            if (img.dataset.remote && img.dataset.remote.startsWith('http') && avatarProxy && avatarProxy !== img.src && !img.dataset.failedProxy) {
                img.dataset.failedProxy = "true";
                img.src = avatarProxy;
                return;
            }
            img.onerror = null;
            const letter = (fallbackLetter || 'X').toUpperCase();
            const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40"><circle cx="20" cy="20" r="20" fill="#1d9bf0"/><text x="50%" y="54%" font-family="sans-serif" font-weight="bold" font-size="16" fill="#ffffff" text-anchor="middle" dominant-baseline="middle">${letter}</text></svg>`;
            img.src = 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
        }

        function formatShortTime(dtStr) {
            if (!dtStr || dtStr.includes('Henüz')) return 'Henüz yok';
            try {
                const parts = dtStr.split(' ');
                if (parts.length >= 2) {
                    const dParts = parts[0].split('-');
                    if (dParts.length >= 3) {
                        return `${dParts[2]}/${dParts[1]} ${parts[1].substring(0, 5)}`;
                    }
                    return `${parts[0]} ${parts[1].substring(0, 5)}`;
                }
            } catch(e) {}
            return dtStr;
        }

        function formatTweetDate(dtStr, isDetail = false) {
            if (!dtStr) return '';
            try {
                dtStr = String(dtStr).trim();
                let cleanStr = dtStr.replace(/[\u00b7\ufffd\xb7\u2022]+/g, ' ').replace(/\s+/g, ' ').trim();
                let d = null;
                if (/^\d{4}-\d{2}-\d{2}/.test(cleanStr)) {
                    const parts = cleanStr.split(/[- :]/);
                    if (parts.length >= 5) {
                        d = new Date(parts[0], parts[1] - 1, parts[2], parts[3], parts[4], parts[5] || 0);
                    }
                } else {
                    const withoutUtc = cleanStr.replace(' UTC', '').trim();
                    const parsedMs = Date.parse(withoutUtc);
                    if (!isNaN(parsedMs)) d = new Date(parsedMs);
                }
                if (!d || isNaN(d.getTime())) return cleanStr.replace(/ UTC$/, '');
                const trMonths = ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"];
                const day = d.getDate();
                const month = trMonths[d.getMonth()];
                const year = d.getFullYear();
                const currentYear = new Date().getFullYear();
                const hours = String(d.getHours()).padStart(2, '0');
                const mins = String(d.getMinutes()).padStart(2, '0');
                if (isDetail) return `${hours}:${mins} · ${day} ${month} ${year}`;
                if (year === currentYear) return `${day} ${month}`;
                return `${day} ${month} ${year}`;
            } catch(e) { return String(dtStr).split(' ')[0] || dtStr; }
        }

        function formatJoinDate(dtStr) {
            if (!dtStr) return 'Tarih belirtilmemiş';
            try {
                const trFullMonths = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
                const enMonths = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
                const str = String(dtStr).trim();
                // 1. ISO format: "2026-09-22" veya "2025-02-01 12:00:00"
                const parts = str.split(' ')[0].split('-');
                if (parts.length >= 2) {
                    const year = parts[0];
                    const mIdx = parseInt(parts[1], 10) - 1;
                    const day = parts.length >= 3 ? parseInt(parts[2], 10) : null;
                    if (mIdx >= 0 && mIdx < 12 && year.length === 4) {
                        if (day && !isNaN(day)) {
                            return `${day} ${trFullMonths[mIdx]} ${year}`;
                        }
                        return `${trFullMonths[mIdx]} ${year}`;
                    }
                }
                // 2. Türkçe gün/ay/yıl veya ay/yıl: örn. "22 Eylül 2026" veya "Şubat 2025"
                for (let i = 0; i < trFullMonths.length; i++) {
                    const m = trFullMonths[i];
                    if (str.toLowerCase().includes(m.toLowerCase())) {
                        const yrMatch = str.match(/\b(19\d\d|20\d\d)\b/);
                        const dayMatch = str.match(/\b([1-9]|[12]\d|3[01])\b/);
                        if (yrMatch) {
                            if (dayMatch && dayMatch[1] !== yrMatch[1]) {
                                return `${parseInt(dayMatch[1], 10)} ${m} ${yrMatch[1]}`;
                            }
                            return `${m} ${yrMatch[1]}`;
                        }
                    }
                }
                // 3. İngilizce format: "18 February 2025" veya "Joined February 2025"
                for (let i = 0; i < enMonths.length; i++) {
                    if (str.toLowerCase().includes(enMonths[i])) {
                        const yrMatch = str.match(/\b(19\d\d|20\d\d)\b/);
                        const dayMatch = str.match(/\b([1-9]|[12]\d|3[01])\b/);
                        if (yrMatch) {
                            if (dayMatch && dayMatch[1] !== yrMatch[1]) {
                                return `${parseInt(dayMatch[1], 10)} ${trFullMonths[i]} ${yrMatch[1]}`;
                            }
                            return `${trFullMonths[i]} ${yrMatch[1]}`;
                        }
                    }
                }
                const d = new Date(str);
                if (!isNaN(d.getTime())) {
                    return `${d.getDate()} ${trFullMonths[d.getMonth()]} ${d.getFullYear()}`;
                }
            } catch(e) {}
            return String(dtStr);
        }

        function escapeJsArg(text) {
            if (!text) return "";
            return String(text)
                .replace(/\\/g, "\\\\")
                .replace(/'/g, "\\'")
                .replace(/\r/g, "")
                .replace(/\n/g, " ")
                .replace(/&/g, "&amp;")
                .replace(/"/g, "&quot;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");
        }

        function escapeHtml(text) {
            if (!text) return "";
            return text
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }

        function focusComposer() {
            if (currentView !== 'home') navigateTo('home');
            const input = document.getElementById('usernameInput');
            if (input) {
                input.focus();
                input.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }

        async function refreshAll(silent = false) {
            const icon = document.getElementById('refreshAllIcon');
            if (icon && !silent) icon.classList.add('fa-spin');
            if (typeof resetAutoRefreshCountdown === 'function') resetAutoRefreshCountdown();
            const tasks = [
                fetchStats(selectedUsername),
                loadUsers(),
                loadLogs(),
                loadTrends()
            ];
            // 1. Profil sayfasındaysak o kullanıcının tüm verilerini, sayaçlarını ve gönderilerini yenile
            if (currentView === 'profile' && activeProfileUsername) {
                const cleanU = activeProfileUsername.toLowerCase();
                // Profil verilerini çek ve başlığı güncelle
                tasks.push(
                    fetch(`/api/user/${encodeURIComponent(cleanU)}`)
                        .then(r => r.json())
                        .then(userData => {
                            if (userData && activeProfileUsername.toLowerCase() === cleanU) {
                                applyUserProfileData(userData);
                            }
                        }).catch(() => {})
                );
                // Profil gönderilerini ekranda sıfırlamadan sessizce tazele
                tasks.push(loadProfilePosts(activeProfileUsername, false, true));
                // Eğer Aktivite & Uyku Tahmini modalı açıksa onu da anında en güncel beğeni artışlarıyla tazele
                // NOT: openActivityPredictionModal(activeProfileUsername) DEĞİL — modal hangi kullanıcı için açıldıysa
                // (_actPredUsername) onun verisi yenilenmeli. activeProfileUsername farklı olabilir!
                const actModal = document.getElementById('activityPredictionModal');
                if (actModal && !actModal.classList.contains('hidden') && _actPredUsername) {
                    tasks.push(_actPredLoadPeriodData(_actPredUsername, _actPredPeriod || 'all'));
                }
                // Sunucuya bu profil için hızlı bir arka plan kontrolü gönder
                fetch(`/api/refresh/${encodeURIComponent(cleanU)}`, { method: 'POST' }).catch(() => {});
            } else {
                // Ana akış görünümündeyse ana gönderileri yenile
                tasks.push(loadPosts(false));
                // Tüm takip edilenler için arka plan kontrolü tetikle
                fetch('/api/refresh-all', { method: 'POST' }).catch(() => {});
            }
            await Promise.all(tasks);
            if (icon && !silent) setTimeout(() => icon.classList.remove('fa-spin'), 600);
        }

        // ================= 16. GLOBAL ETKİLEŞİM DİNLEYİCİLERİ =================
        document.addEventListener('click', (e) => {
            const moreMenu = document.getElementById('moreMenuDropdown');
            if (moreMenu && !moreMenu.classList.contains('hidden') && !e.target.closest('#moreMenuDropdown') && !e.target.closest('#btnMoreMenu')) {
                moreMenu.classList.add('hidden');
            }
            const tweetMenu = document.getElementById('tweetActionDropdown');
            if (tweetMenu && !tweetMenu.classList.contains('hidden') && !e.target.closest('#tweetActionDropdown')) {
                tweetMenu.classList.add('hidden');
                activeMenuTweet = null;
            }
            const trendMenu = document.getElementById('trendActionDropdown');
            if (trendMenu && !trendMenu.classList.contains('hidden') && !e.target.closest('#trendActionDropdown')) {
                trendMenu.classList.add('hidden');
            }
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                if (currentView === 'tweet') closeTweetDetail();
                closeStatsModal();
                closeActivityPredictionModal();
                closeModal('trendSettingsModal');
                closeModal('termsModal');
                closeModal('privacyModal');
                closeModal('exportModal');
                closeModal('helpModal');
                closeModal('setMyAccountModal');
                const moreMenu = document.getElementById('moreMenuDropdown');
                if (moreMenu) moreMenu.classList.add('hidden');
                const tweetMenu = document.getElementById('tweetActionDropdown');
                if (tweetMenu) tweetMenu.classList.add('hidden');
                const trendMenu = document.getElementById('trendActionDropdown');
                if (trendMenu) trendMenu.classList.add('hidden');
                return;
            }
            if (e.key === '/' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                const tag = (document.activeElement?.tagName || '').toUpperCase();
                if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || document.activeElement?.isContentEditable) return;
                e.preventDefault();
                if (currentView === 'explore') {
                    document.getElementById('exploreSearchInput')?.focus();
                } else if (currentView === 'search') {
                    document.getElementById('headerSearchInput')?.focus();
                } else if (currentView === 'profile' && document.getElementById('profileFilterBar') && !document.getElementById('profileFilterBar').classList.contains('hidden')) {
                    document.getElementById('profileSearchInput')?.focus();
                } else {
                    document.getElementById('searchInput')?.focus();
                }
            }
        });

        document.addEventListener('DOMContentLoaded', () => {
            syncAutoLoadMediaUI();
            refreshAll();
            startAutoRefreshTimer();
            setInterval(loadTrends, 180000); // 3 dakikada bir canlı gündemleri yenile
        });

        document.getElementById('usernameInput')?.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') addUser();
        });
        document.getElementById('headerSearchInput')?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const val = this.value.trim();
                if (val) openSearchPage(val);
            }
        });
        document.getElementById('searchInput')?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const val = this.value.trim();
                if (val) openSearchPage(val);
            }
        });
        document.getElementById('exploreSearchInput')?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const val = this.value.trim();
                if (val) openSearchPage(val);
            }
        });
        document.getElementById('myAccountNickInput')?.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') saveMyAccountNick();
        });

        // ================= SONSUZ KAYDIRMA (INFINITE SCROLL) GÖZLEMCİLERİ & DİNLEYİCİLERİ =================
        let homeObserver = null;
        let profileObserver = null;
        let commentsObserver = null;
        function setupInfiniteScrollObservers() {
            if ('IntersectionObserver' in window) {
                if (homeObserver) homeObserver.disconnect();
                if (profileObserver) profileObserver.disconnect();
                if (commentsObserver) commentsObserver.disconnect();
                homeObserver = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting && currentView === 'home' && homeHasMore && !isLoadingHome) {
                            loadMoreHomePosts();
                        }
                    });
                }, { rootMargin: '800px' });
                const homeSentinel = document.getElementById('homeScrollSentinel');
                if (homeSentinel) homeObserver.observe(homeSentinel);
                profileObserver = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting && currentView === 'profile' && ['all', 'replies', 'reposts', 'media', 'deleted'].includes(currentProfileFilter)) {
                            const hasLocalFilter = Boolean(document.getElementById('profileSearchInput')?.value?.trim()) || ((document.getElementById('profileSortSelect')?.value || 'newest') !== 'newest');
                            if (hasLocalFilter) return;
                            if (profileHasMore && !isLoadingProfile) {
                                loadMoreProfilePosts();
                            } else if (!isLoadingProfile && !isAutoFetchingOlder && !profileReachedEnd) {
                                autoFetchOlderProfilePosts(activeProfileUsername);
                            }
                        }
                    });
                }, { rootMargin: '800px' });
                const profileSentinel = document.getElementById('profileScrollSentinel');
                if (profileSentinel) profileObserver.observe(profileSentinel);
                commentsObserver = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting && currentView === 'tweet' && tweetCommentsHasMore && !isLoadingTweetComments) {
                            loadMoreTweetComments(false);
                        }
                    });
                }, { rootMargin: '800px' });
                const commentsSentinel = document.getElementById('tweetCommentsSentinel');
                if (commentsSentinel) commentsObserver.observe(commentsSentinel);
            }
        }

        let isScrollThrottled = false;
        function handleScrollCheck() {
            if (isScrollThrottled) return;
            isScrollThrottled = true;
            requestAnimationFrame(() => {
                isScrollThrottled = false;
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
                const scrollHeight = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight, document.documentElement.offsetHeight, document.body.offsetHeight);
                const clientHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
                const distFromBottom = scrollHeight - (scrollTop + clientHeight);

                if (distFromBottom < 1000) {
                    if (currentView === 'home' && homeHasMore && !isLoadingHome) {
                        loadMoreHomePosts();
                    } else if (currentView === 'tweet' && tweetCommentsHasMore && !isLoadingTweetComments) {
                        loadMoreTweetComments(false);
                    } else if (currentView === 'profile' && ['all', 'replies', 'reposts', 'media', 'deleted'].includes(currentProfileFilter)) {
                        const hasLocalFilter = Boolean(document.getElementById('profileSearchInput')?.value?.trim()) || ((document.getElementById('profileSortSelect')?.value || 'newest') !== 'newest');
                        if (hasLocalFilter) return;
                        if (profileHasMore && !isLoadingProfile) {
                            loadMoreProfilePosts();
                        } else if (!isLoadingProfile && !isAutoFetchingOlder && !profileReachedEnd) {
                            autoFetchOlderProfilePosts(activeProfileUsername);
                        }
                    }
                }
            });
        }

        window.addEventListener('scroll', handleScrollCheck, { passive: true });
