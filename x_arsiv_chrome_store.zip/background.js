// Chrome MV3 Service Worker: 2 dakikada bir arka plan senkronizasyonu ve silinen gönderi bildirimi
importScripts('db.js', 'engine.js');

const SYNC_ALARM = 'x_arsiv_sync_alarm';
let _bgSyncRunning = false;

async function setupAlarm() {
  const existing = await chrome.alarms.get(SYNC_ALARM);
  if (!existing) {
    chrome.alarms.create(SYNC_ALARM, { periodInMinutes: 2 });
  }
}

async function runBackgroundSync() {
  if (_bgSyncRunning) return { status: 'busy' };
  _bgSyncRunning = true;
  let synced = 0;
  let deletedCount = 0;

  try {
    const users = await XArsivDB.getAll('tracked_users');
    const active = users.filter(u => !u.status || u.status === 'active');

    for (const u of active) {
      try {
        const res = await XArsivEngine.syncSingleUser(u.username);
        synced++;
        if (res && res.deletedPosts && res.deletedPosts.length > 0) {
          deletedCount += res.deletedPosts.length;
          for (const dp of res.deletedPosts) {
            chrome.notifications.create(`del_${dp.post_id}_${Date.now()}`, {
              type: 'basic',
              iconUrl: 'icons/icon128.png',
              title: `Silinen Gönderi: @${u.username}`,
              message: (dp.content || 'Medya/RT gönderisi').slice(0, 120)
            });
          }
        }
        // Eksik geçmiş gönderi varsa arka planda tamamla
        const posts = await XArsivDB.getByIndex('posts', 'username', u.username);
        if (u.total_tweets > 0 && posts.length < u.total_tweets) {
          XArsivEngine.deepArchiveUser(u.username, 12).catch(() => {});
        }
      } catch (e) {
        console.warn('[BG Sync kullanıcı hatası]', u.username, e);
      }
      await new Promise(r => setTimeout(r, 1500));
    }

    chrome.runtime.sendMessage({ type: 'DATA_UPDATED' }).catch(() => {});
    return { status: 'ok', synced, deletedCount };
  } finally {
    _bgSyncRunning = false;
    await updateActionBadge();
  }
}

async function updateActionBadge() {
  try {
    const allPosts = await XArsivDB.getAll('posts');
    const deletedCount = allPosts.reduce((acc, p) => acc + (Number(p?.is_deleted) === 1 ? 1 : 0), 0);
    if (deletedCount > 0) {
      const text = deletedCount > 99 ? '99+' : String(deletedCount);
      await chrome.action.setBadgeText({ text });
      await chrome.action.setBadgeBackgroundColor({ color: '#f4212e' });
    } else {
      await chrome.action.setBadgeText({ text: '' });
    }
  } catch (e) {
    console.warn('[Badge güncelleme hatası]', e);
  }
}

chrome.runtime.onInstalled.addListener(() => {
  setupAlarm();
  updateActionBadge();
});

chrome.runtime.onStartup.addListener(() => {
  setupAlarm();
  updateActionBadge();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm && alarm.name === SYNC_ALARM) {
    runBackgroundSync().catch(err => console.error('[Alarm Sync Hatası]', err));
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.type) return false;

  if (msg.type === 'SYNC_ALL') {
    runBackgroundSync()
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ status: 'error', message: err.message }));
    return true;
  }

  if (msg.type === 'ADD_AND_OPEN_USER') {
    const uname = String(msg.username || '').trim().replace(/^@/, '').toLowerCase();
    if (!uname) {
      sendResponse({ status: 'error', message: 'Geçersiz kullanıcı adı' });
      return false;
    }
    XArsivEngine.addUser(uname)
      .then(async () => {
        await updateActionBadge();
        chrome.runtime.sendMessage({ type: 'DATA_UPDATED' }).catch(() => {});
        const dashUrl = chrome.runtime.getURL(`dashboard.html#profile=${encodeURIComponent(uname)}`);
        chrome.tabs.create({ url: dashUrl });
        sendResponse({ status: 'ok', username: uname });
      })
      .catch(err => sendResponse({ status: 'error', message: err.message }));
    return true;
  }

  if (msg.type === 'REFRESH_BADGE') {
    updateActionBadge()
      .then(() => sendResponse({ status: 'ok' }))
      .catch(() => sendResponse({ status: 'error' }));
    return true;
  }

  if (msg.type === 'OPEN_DASHBOARD') {
    const hash = msg.hash ? `#${msg.hash}` : '';
    const dashUrl = chrome.runtime.getURL(`dashboard.html${hash}`);
    chrome.tabs.create({ url: dashUrl });
    sendResponse({ status: 'ok' });
    return false;
  }

  if (msg.type === 'IS_USER_TRACKED') {
    const uname = String(msg.username || '').trim().replace(/^@/, '').toLowerCase();
    XArsivDB.getOne('tracked_users', uname)
      .then(u => sendResponse({ tracked: !!u }))
      .catch(() => sendResponse({ tracked: false }));
    return true;
  }

  return false;
});
