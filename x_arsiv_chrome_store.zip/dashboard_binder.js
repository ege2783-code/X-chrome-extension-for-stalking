// Chrome MV3 CSP uyumlu olay bağlayıcı (data-ext-click, data-ext-input, data-ext-error -> sıfır eval)
(() => {
  function splitArgs(argsStr) {
    const args = [];
    let cur = '';
    let inQuote = null;
    let hasToken = false;
    for (let i = 0; i < argsStr.length; i++) {
      const ch = argsStr[i];
      if (inQuote) {
        if (ch === '\\' && i + 1 < argsStr.length) {
          cur += argsStr[++i];
        } else if (ch === inQuote) {
          inQuote = null;
        } else {
          cur += ch;
        }
      } else if (ch === '\'' || ch === '"') {
        inQuote = ch;
        hasToken = true;
      } else if (ch === ',') {
        args.push(cur.trim());
        cur = '';
        hasToken = false;
      } else {
        if (!/\s/.test(ch)) hasToken = true;
        cur += ch;
      }
    }
    if (hasToken) args.push(cur.trim());
    return args;
  }

  function resolveArg(raw, el, event) {
    if (raw === 'this') return el;
    if (raw === 'event') return event;
    if (raw === 'true') return true;
    if (raw === 'false') return false;
    if (raw === 'null') return null;
    if (raw === 'currentSearchTab') return typeof window.currentSearchTab !== 'undefined' ? window.currentSearchTab : 'top';
    return raw;
  }

  function runCommandList(expr, el, event) {
    if (!expr) return;
    // Noktalı virgülleri tırnak dışında böl
    const cmds = [];
    let cur = '';
    let q = null;
    for (let i = 0; i < expr.length; i++) {
      const ch = expr[i];
      if (q) {
        if (ch === '\\' && i + 1 < expr.length) { cur += ch + expr[++i]; }
        else { if (ch === q) q = null; cur += ch; }
      } else if (ch === '\'' || ch === '"') {
        q = ch; cur += ch;
      } else if (ch === ';') {
        if (cur.trim()) cmds.push(cur.trim());
        cur = '';
      } else {
        cur += ch;
      }
    }
    if (cur.trim()) cmds.push(cur.trim());

    for (const cmd of cmds) {
      if (cmd === 'event.preventDefault()' || cmd === 'event.preventDefault') {
        event?.preventDefault();
        continue;
      }
      if (cmd === 'event.stopPropagation()' || cmd === 'event.stopPropagation') {
        event?.stopPropagation();
        continue;
      }
      if (cmd === "document.getElementById('searchInput').value=''") {
        const si = document.getElementById('searchInput');
        if (si) si.value = '';
        continue;
      }
      const m = cmd.match(/^([A-Za-z0-9_.]+)\s*\((.*)\)$/);
      if (!m) continue;
      const fnPath = m[1];
      const rawArgs = splitArgs(m[2]).map(a => resolveArg(a, el, event));

      if (fnPath === 'window.open') {
        window.open(rawArgs[0], rawArgs[1] || '_blank');
        continue;
      }
      if (fnPath === 'navigator.clipboard.writeText') {
        navigator.clipboard?.writeText(String(rawArgs[0] || '')).catch(() => {});
        continue;
      }
      const fn = window[fnPath];
      if (typeof fn === 'function') {
        fn(...rawArgs);
      }
    }
  }

  document.addEventListener('click', (event) => {
    const el = event.target.closest('[data-ext-click]');
    if (!el) return;
    const expr = el.getAttribute('data-ext-click');
    runCommandList(expr, el, event);
  });

  document.addEventListener('input', (event) => {
    const el = event.target.closest('[data-ext-input]');
    if (!el) return;
    const expr = el.getAttribute('data-ext-input');
    runCommandList(expr, el, event);
  });

  document.addEventListener('change', (event) => {
    const el = event.target.closest('[data-ext-change]');
    if (!el) return;
    const expr = el.getAttribute('data-ext-change');
    runCommandList(expr, el, event);
  });

  document.addEventListener('error', (event) => {
    const el = event.target;
    if (!el || el.nodeType !== 1) return;
    const expr = el.getAttribute('data-ext-error');
    if (!expr) return;

    if (expr.includes('handleAvatarError')) {
      const m = expr.match(/handleAvatarError\s*\(\s*this\s*,\s*['"]([^'"]*)['"]\s*\)/);
      if (typeof window.handleAvatarError === 'function') {
        window.handleAvatarError(el, m ? m[1] : 'X');
      }
      return;
    }

    if (expr.includes('handleMediaImgError')) {
      if (typeof window.handleMediaImgError === 'function') {
        window.handleMediaImgError(el);
      }
      return;
    }

    if (expr.includes('handleMediaVideoError')) {
      if (typeof window.handleMediaVideoError === 'function') {
        window.handleMediaVideoError(el);
      }
      return;
    }

    if (expr.includes('dataset.direct')) {
      if (el.dataset.direct && el.src !== el.dataset.direct && !el.dataset.extTriedDirect) {
        el.dataset.extTriedDirect = '1';
        el.src = el.dataset.direct;
        if (typeof el.load === 'function') {
          el.load();
          el.play?.().catch(() => {});
        }
      }
      return;
    }

    if (expr.includes('dataset.proxy')) {
      if (el.dataset.proxy && el.src !== el.dataset.proxy && !el.dataset.extTriedProxy) {
        el.dataset.extTriedProxy = '1';
        el.src = el.dataset.proxy;
        if (typeof el.load === 'function') el.load();
      } else if (expr.includes("style.display='none'")) {
        el.style.display = 'none';
      }
    }
  }, true);
})();
