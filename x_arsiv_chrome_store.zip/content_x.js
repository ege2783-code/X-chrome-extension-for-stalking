// X.com / Twitter profil sayfalarına hızlı "X Arşive Ekle" butonu ekler
(() => {
  const RESERVED = new Set([
    'home', 'explore', 'notifications', 'messages', 'i', 'search',
    'settings', 'compose', 'bookmarks', 'lists', 'communities', 'tos', 'privacy',
    'hashtag', 'intent', 'login', 'logout', 'signup', 'oauth', 'account', 'jobs', 'download', 'share'
  ]);
  const PROFILE_SUBPATHS = new Set(['status', 'with_replies', 'media', 'likes', 'highlights']);
  let lastPath = '';
  let btnEl = null;
  let currentUsername = null;
  let currentIsTracked = false;

  function getProfileUsername() {
    const parts = window.location.pathname.split('/').filter(Boolean);
    if (parts.length === 0) return null;
    if (parts.length > 1 && !PROFILE_SUBPATHS.has(parts[1].toLowerCase())) return null;
    const candidate = parts[0].replace(/^@/, '').trim();
    if (!candidate || RESERVED.has(candidate.toLowerCase())) return null;
    if (!/^[A-Za-z0-9_]{1,30}$/.test(candidate)) return null;
    return candidate.toLowerCase();
  }

  function removeButton() {
    if (btnEl && btnEl.parentNode) {
      btnEl.parentNode.removeChild(btnEl);
    }
    btnEl = null;
  }

  function ensureButton() {
    const path = window.location.pathname;
    if (path === lastPath && btnEl) return;
    lastPath = path;

    const username = getProfileUsername();
    if (!username) {
      removeButton();
      return;
    }

    if (!btnEl) {
      btnEl = document.createElement('button');
      btnEl.id = 'x-arsiv-ext-pill';
      Object.assign(btnEl.style, {
        position: 'fixed',
        right: '20px',
        bottom: '20px',
        zIndex: '99999',
        background: '#1d9bf0',
        color: '#ffffff',
        border: '1px solid rgba(255,255,255,0.2)',
        borderRadius: '9999px',
        padding: '10px 16px',
        fontSize: '13px',
        fontWeight: '700',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        boxShadow: '0 8px 24px rgba(0,0,0,0.45)',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        transition: 'transform 0.15s ease, background-color 0.15s ease'
      });
      btnEl.addEventListener('mouseenter', () => { btnEl.style.transform = 'scale(1.04)'; });
      btnEl.addEventListener('mouseleave', () => { btnEl.style.transform = 'scale(1)'; });
      btnEl.addEventListener('click', () => {
        if (!currentUsername) return;
        const targetUser = currentUsername;
        if (currentIsTracked) {
          chrome.runtime.sendMessage({
            type: 'OPEN_DASHBOARD',
            hash: `profile=${encodeURIComponent(targetUser)}`
          });
          return;
        }
        btnEl.disabled = true;
        btnEl.textContent = `@${targetUser} arşivleniyor...`;
        chrome.runtime.sendMessage({ type: 'ADD_AND_OPEN_USER', username: targetUser }, (resp) => {
          if (btnEl && currentUsername === targetUser) {
            btnEl.disabled = false;
            if (!chrome.runtime.lastError && resp?.status !== 'error') {
              currentIsTracked = true;
              btnEl.textContent = `@${targetUser} · Arşivde Aç`;
              btnEl.style.background = '#00ba7c';
            } else {
              btnEl.textContent = `@${targetUser} · X Arşive Ekle`;
              btnEl.style.background = '#1d9bf0';
            }
          }
        });
      });
      document.body.appendChild(btnEl);
    }

    currentUsername = username;
    currentIsTracked = false;
    btnEl.disabled = false;
    btnEl.textContent = `@${username} · X Arşive Ekle`;
    btnEl.style.background = '#1d9bf0';

    chrome.runtime.sendMessage({ type: 'IS_USER_TRACKED', username }, (res) => {
      if (chrome.runtime.lastError) return;
      if (btnEl && currentUsername === username && res?.tracked) {
        currentIsTracked = true;
        btnEl.textContent = `@${username} · Arşivde Aç`;
        btnEl.style.background = '#00ba7c';
      }
    });
  }

  ensureButton();
  let timer = null;
  const obs = new MutationObserver(() => {
    if (window.location.pathname !== lastPath) {
      clearTimeout(timer);
      timer = setTimeout(ensureButton, 250);
    }
  });
  obs.observe(document.body, { childList: true, subtree: true });
})();
