// Offscreen DOM_PARSER: Service Worker arka planda Nitter / X.com / Trends HTML sayfalarını ayrıştırır
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen' || msg.action !== 'parseHtml') return false;
  try {
    const doc = new DOMParser().parseFromString(msg.html || '', 'text/html');
    const kind = msg.kind;
    if (kind === 'nitter_timeline') {
      sendResponse({ ok: true, result: extractNitterFromDoc(doc, msg.username || '') });
    } else if (kind === 'x_ssr') {
      sendResponse({ ok: true, result: extractXScriptsFromDoc(doc) });
    } else if (kind === 'trends24') {
      sendResponse({ ok: true, result: extractTrends24FromDoc(doc) });
    } else if (kind === 'status_mirrors') {
      sendResponse({ ok: true, result: extractMirrorsFromDoc(doc) });
    } else if (kind === 'nitter_comments') {
      sendResponse({ ok: true, result: extractNitterCommentsFromDoc(doc, msg.postId || '') });
    } else if (kind === 'nitter_relationships') {
      sendResponse({ ok: true, result: extractNitterRelationshipsFromDoc(doc) });
    } else if (kind === 'nitter_search_users') {
      sendResponse({ ok: true, result: extractNitterSearchUsersFromDoc(doc) });
    } else {
      sendResponse({ ok: false, error: 'Unknown parse kind' });
    }
  } catch (err) {
    sendResponse({ ok: false, error: String(err) });
  }
  return true;
});

function getNodeText(root) {
  if (!root) return '';
  const parts = [];
  function walk(node) {
    if (node.nodeType === 3) {
      parts.push(node.nodeValue || '');
      return;
    }
    if (node.nodeType !== 1) return;
    const tag = node.tagName;
    if (tag === 'BR') {
      parts.push('\n');
      return;
    }
    const isBlock = tag === 'P' || tag === 'DIV' || tag === 'LI' || tag === 'BLOCKQUOTE';
    if (isBlock && parts.length > 0 && !parts[parts.length - 1].endsWith('\n')) {
      parts.push('\n');
    }
    for (const child of node.childNodes) walk(child);
    if (isBlock && parts.length > 0 && !parts[parts.length - 1].endsWith('\n')) {
      parts.push('\n');
    }
  }
  walk(root);
  return parts.join('').replace(/\n{3,}/g, '\n\n').trim();
}

function extractNitterFromDoc(doc, username) {
  const stats = {};
  doc.querySelectorAll('.profile-statlist li').forEach(li => {
    const h = li.querySelector('.profile-stat-header');
    const n = li.querySelector('.profile-stat-num');
    if (h && n) stats[h.textContent.trim().toLowerCase()] = n.textContent.trim();
  });

  const nameEl = doc.querySelector('.profile-card-fullname');
  const avatarEl = doc.querySelector('.profile-card-avatar');
  const avatarImg = avatarEl ? avatarEl.querySelector('img') : null;
  const rawAvatar = avatarEl ? (avatarEl.getAttribute('src') || (avatarImg ? avatarImg.getAttribute('src') : '')) : '';

  const jdEl = doc.querySelector('.profile-joindate span, .profile-joindate');
  const rawJoinDate = jdEl ? (jdEl.getAttribute('title') || jdEl.textContent.trim()) : '';

  const items = [];
  doc.querySelectorAll('.timeline-item').forEach(item => {
    if (item.classList.contains('show-more')) return;
    const linkEl = item.querySelector('.tweet-link');
    if (!linkEl) return;
    const href = linkEl.getAttribute('href') || '';
    const postId = href.split('/').pop().split('#')[0];
    if (!postId) return;

    const contentEl = item.querySelector('.tweet-content');
    const content = contentEl ? getNodeText(contentEl) : '';

    const dateEl = item.querySelector('.tweet-date a');
    const postedAt = dateEl ? (dateEl.getAttribute('title') || dateEl.textContent.trim()) : '';

    const rtHeader = item.querySelector('.retweet-header');
    const isRetweet = rtHeader ? 1 : 0;
    const origUserEl = item.querySelector('.fullname-and-username .username');
    const origNameEl = item.querySelector('.fullname-and-username .fullname');
    const origAvatarEl = item.querySelector('.tweet-header .avatar');

    const statNums = {};
    item.querySelectorAll('.tweet-stat').forEach(st => {
      const icon = st.querySelector('.icon-heart, .icon-retweet, .icon-comment, .icon-quote');
      if (!icon) return;
      const cls = icon.className;
      const val = st.textContent.trim();
      if (cls.includes('icon-heart')) statNums.likes = val;
      else if (cls.includes('icon-retweet')) statNums.retweets = val;
      else if (cls.includes('icon-comment')) statNums.replies = val;
    });

    const media = [];
    item.querySelectorAll('.attachments .attachment img').forEach(img => {
      const src = img.getAttribute('src') || '';
      if (src) media.push({ type: 'image', raw: src });
    });
    item.querySelectorAll('.attachments video, .attachments .gallery-video').forEach(v => {
      const sTag = v.querySelector('source');
      const vSrc = (sTag && sTag.getAttribute('src')) || v.getAttribute('src') || v.getAttribute('data-url') || '';
      const poster = v.getAttribute('poster') || '';
      if (vSrc || poster) media.push({ type: 'video', raw: vSrc || poster, poster });
    });

    // Quote card
    const quoteEl = item.querySelector('.quote');
    let quote = null;
    if (quoteEl) {
      const qLink = quoteEl.querySelector('.quote-link');
      const qHref = qLink ? (qLink.getAttribute('href') || '') : '';
      const qPid = qHref.split('/').pop().split('#')[0] || '';
      const qUser = quoteEl.querySelector('.username')?.textContent.trim().replace(/^@/, '') || '';
      const qName = quoteEl.querySelector('.fullname')?.textContent.trim() || '';
      const qAv = quoteEl.querySelector('img.avatar')?.getAttribute('src') || '';
      const qText = getNodeText(quoteEl.querySelector('.quote-text'));
      const qMedia = [];
      quoteEl.querySelectorAll('.attachment img').forEach(img => {
        const s = img.getAttribute('src') || '';
        if (s) qMedia.push({ type: 'image', raw: s });
      });
      quoteEl.querySelectorAll('video').forEach(v => {
        const sTag = v.querySelector('source');
        const vs = (sTag && sTag.getAttribute('src')) || v.getAttribute('src') || '';
        const vp = v.getAttribute('poster') || '';
        if (vs || vp) qMedia.push({ type: 'video', raw: vs || vp, poster: vp });
      });
      quote = { qPid, qUser, qName, qAv, qText, qMedia };
    }

    // Reply indicator
    const replyingTo = item.querySelector('.replying-to a');
    const replyUser = replyingTo ? replyingTo.textContent.trim().replace(/^@/, '') : '';

    items.push({
      postId,
      content,
      postedAt,
      isRetweet,
      origAuthor: isRetweet && origUserEl ? origUserEl.textContent.trim().replace(/^@/, '').toLowerCase() : username.toLowerCase(),
      origName: origNameEl ? origNameEl.textContent.trim() : '',
      origAvatar: origAvatarEl ? (origAvatarEl.getAttribute('src') || '') : '',
      statNums,
      media,
      quote,
      replyUser
    });
  });

  let nextCursor = '';
  doc.querySelectorAll('.show-more a').forEach(a => {
    const h = a.getAttribute('href') || '';
    if (!nextCursor && h.includes('cursor=')) {
      nextCursor = h.split('cursor=').pop();
    }
  });

  return {
    stats,
    displayName: nameEl ? nameEl.textContent.trim() : '',
    rawAvatar,
    rawJoinDate,
    items,
    nextCursor
  };
}

function extractXScriptsFromDoc(doc) {
  const ogImg = doc.querySelector('meta[property="og:image"]')?.getAttribute('content') || '';
  const titleText = doc.querySelector('title')?.textContent || '';
  const scripts = [];
  doc.querySelectorAll('script').forEach(s => {
    const t = s.textContent || '';
    if (t.includes('value:"') || t.includes('notFound') || t.includes('User not found')) {
      scripts.push(t);
    }
  });
  return { ogImg, titleText, scripts };
}

function extractTrends24FromDoc(doc) {
  const names = [];
  const ol = doc.querySelector('ol');
  if (ol) {
    ol.querySelectorAll('li .trend-name a').forEach(a => {
      const t = a.textContent.trim();
      if (t && names.length < 20) names.push(t);
    });
  }
  return names;
}

function extractMirrorsFromDoc(doc) {
  const urls = [];
  doc.querySelectorAll('a[href^="http"]').forEach(a => {
    const h = (a.getAttribute('href') || '').replace(/\/+$/, '');
    if (h && !h.includes('github') && !h.includes('status.d420')) {
      if (h.includes('nitter') || h.includes('xcancel')) {
        if (!urls.includes(h)) urls.push(h);
      }
    }
  });
  return urls;
}

function extractNitterCommentsFromDoc(doc, postId) {
  const comments = [];
  doc.querySelectorAll('.reply.thread .timeline-item, .replies .timeline-item').forEach(item => {
    const linkEl = item.querySelector('.tweet-link');
    const href = linkEl ? (linkEl.getAttribute('href') || '') : '';
    const pid = href.split('/').pop().split('#')[0] || '';
    if (!pid || pid === String(postId)) return;
    const uname = item.querySelector('.fullname-and-username .username')?.textContent.trim().replace(/^@/, '') || '';
    const fname = item.querySelector('.fullname-and-username .fullname')?.textContent.trim() || uname;
    const avatar = item.querySelector('.avatar')?.getAttribute('src') || '';
    const content = getNodeText(item.querySelector('.tweet-content'));
    const dateEl = item.querySelector('.tweet-date a');
    const postedAt = dateEl ? (dateEl.getAttribute('title') || dateEl.textContent.trim()) : '';
    let likes = '0', retweets = '0', replies = '0';
    item.querySelectorAll('.tweet-stat').forEach(st => {
      const val = st.textContent.trim();
      if (st.querySelector('.icon-heart')) likes = val;
      else if (st.querySelector('.icon-retweet')) retweets = val;
      else if (st.querySelector('.icon-comment')) replies = val;
    });
    comments.push({ pid, uname, fname, avatar, content, postedAt, likes, retweets, replies });
  });
  return comments;
}

function extractNitterRelationshipsFromDoc(doc) {
  const users = [];
  doc.querySelectorAll('.timeline-item, .profile-result, .user-card').forEach(card => {
    const uname = card.querySelector('.username')?.textContent.trim().replace(/^@/, '') || '';
    if (!uname) return;
    const fname = card.querySelector('.fullname')?.textContent.trim() || uname;
    const avatar = card.querySelector('img.avatar')?.getAttribute('src') || '';
    const bio = card.querySelector('.tweet-content, .profile-bio')?.textContent.trim() || '';
    users.push({ username: uname, display_name: fname, avatar_url: avatar, bio });
  });
  return users;
}

function extractNitterSearchUsersFromDoc(doc) {
  const users = [];
  doc.querySelectorAll('.timeline-item, .profile-result').forEach(card => {
    const uname = card.querySelector('.username')?.textContent.trim().replace(/^@/, '') || '';
    if (!uname) return;
    const fname = card.querySelector('.fullname')?.textContent.trim() || uname;
    const avatar = card.querySelector('img.avatar')?.getAttribute('src') || '';
    users.push({ username: uname, display_name: fname, avatar_url: avatar });
  });
  return users;
}
