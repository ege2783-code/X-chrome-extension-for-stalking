// X Arşiv Tracker Core Engine (Chrome MV3 - Service Worker & Dashboard uyumlu)
const XArsivEngine = (() => {
  const MIRRORS = [
    'https://nitter.mie.foundation',
    'https://nitter.jaydenha.uk',
    'https://nitter.tiekoetter.com',
    'https://nitter.click',
    'https://nitter.netbub.com',
    'https://nitter.poast.org',
    'https://xcancel.com',
    'https://nitter.privacydev.net'
  ];

  const RANDOM_X_ACCOUNTS = [
    'elonmusk', 'SpaceX', 'NASA', 'OpenAI', 'GoogleDeepMind',
    'natgeo', 'BBCBreaking', 'Reuters', 'TechCrunch', 'TheVerge',
    'verge', 'github', 'typescriptlang', 'Netflix', 'PlayStation',
    'PushSquare', 'IGN', 'webtekno', 'shiftdeletenet', 'bpthaber',
    'pusholder', 'solcugazete', 'haskologlu', 'Haber', 'darkwebhaber'
  ];

  const FEED_REASONS = [
    ['Senin İçin Seçildi', 'fa-sparkles'],
    ['Gündemde Popüler', 'fa-fire-flame-curved'],
    ['Teknoloji & Bilim', 'fa-microchip'],
    ['Son Dakika Akışı', 'fa-bolt'],
    ['Canlı X Akışı', 'fa-satellite-dish']
  ];

  const MIRROR_HEALTH = {};
  const MISSING_POST_COUNTS = {};
  const DEEP_ARCHIVE_ACTIVE = new Set();
  const LIVE_X_FEED_CACHE = { lastFetched: 0, posts: [], fetchedIndices: 0 };
  const TRENDS_CACHE = { lastFetched: 0, data: [] };

  let _offscreenCreating = null;

  async function ensureOffscreen() {
    if (typeof chrome === 'undefined' || !chrome.offscreen) return false;
    if (await chrome.offscreen.hasDocument()) return true;
    if (_offscreenCreating) {
      await _offscreenCreating;
      return true;
    }
    _offscreenCreating = chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['DOM_PARSER'],
      justification: 'Nitter ve X.com HTML sayfalarını arka planda ayrıştırmak için.'
    });
    await _offscreenCreating;
    _offscreenCreating = null;
    return true;
  }

  async function parseHtml(html, kind, extra = {}) {
    if (typeof DOMParser !== 'undefined') {
      const doc = new DOMParser().parseFromString(html || '', 'text/html');
      if (kind === 'nitter_timeline') return localExtractNitter(doc, extra.username || '');
      if (kind === 'x_ssr') return localExtractXScripts(doc);
      if (kind === 'trends24') return localExtractTrends24(doc);
      if (kind === 'status_mirrors') return localExtractMirrors(doc);
      if (kind === 'nitter_comments') return localExtractNitterComments(doc, extra.postId || '');
      if (kind === 'nitter_relationships') return localExtractNitterRelationships(doc);
      if (kind === 'nitter_search_users') return localExtractNitterSearchUsers(doc);
    }
    await ensureOffscreen();
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ target: 'offscreen', action: 'parseHtml', html, kind, ...extra }, (res) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else if (!res || !res.ok) {
          reject(new Error(res?.error || 'HTML parse failed'));
        } else {
          resolve(res.result);
        }
      });
    });
  }

  // Tarayıcı bağlamında (Dashboard / Popup) doğrudan çalışan DOM çıkarıcılar
  function localExtractNitter(doc, username) {
    const stats = {};
    doc.querySelectorAll('.profile-statlist li').forEach(li => {
      const h = li.querySelector('.profile-stat-header');
      const n = li.querySelector('.profile-stat-num');
      if (h && n) stats[h.textContent.trim().toLowerCase()] = n.textContent.trim();
    });
    const nameEl = doc.querySelector('.profile-card-fullname');
    const avatarEl = doc.querySelector('.profile-card-avatar');
    const avatarImg = avatarEl ? avatarEl.querySelector('img') : null;
    const rawAvatar = avatarEl ? (avatarEl.getAttribute('src') || (avatarImg ? avatarImg.getAttribute('src') : '')) : '';
    const jdEl = doc.querySelector('.profile-joindate span, .profile-joindate');
    const rawJoinDate = jdEl ? (jdEl.getAttribute('title') || jdEl.textContent.trim()) : '';

    const items = [];
    doc.querySelectorAll('.timeline-item').forEach(item => {
      if (item.classList.contains('show-more')) return;
      const linkEl = item.querySelector('.tweet-link');
      if (!linkEl) return;
      const href = linkEl.getAttribute('href') || '';
      const postId = href.split('/').pop().split('#')[0];
      if (!postId) return;

      const contentEl = item.querySelector('.tweet-content');
      const content = contentEl ? (contentEl.innerText || contentEl.textContent || '').trim() : '';
      const dateEl = item.querySelector('.tweet-date a');
      const postedAt = dateEl ? (dateEl.getAttribute('title') || dateEl.textContent.trim()) : '';
      const rtHeader = item.querySelector('.retweet-header');
      const isRetweet = rtHeader ? 1 : 0;
      const origUserEl = item.querySelector('.fullname-and-username .username');
      const origNameEl = item.querySelector('.fullname-and-username .fullname');
      const origAvatarEl = item.querySelector('.tweet-header .avatar');

      const statNums = {};
      item.querySelectorAll('.tweet-stat').forEach(st => {
        const icon = st.querySelector('.icon-heart, .icon-retweet, .icon-comment, .icon-quote');
        if (!icon) return;
        const cls = icon.className;
        const val = st.textContent.trim();
        if (cls.includes('icon-heart')) statNums.likes = val;
        else if (cls.includes('icon-retweet')) statNums.retweets = val;
        else if (cls.includes('icon-comment')) statNums.replies = val;
      });

      const media = [];
      item.querySelectorAll('.attachments .attachment img').forEach(img => {
        const src = img.getAttribute('src') || '';
        if (src) media.push({ type: 'image', raw: src });
      });
      item.querySelectorAll('.attachments video, .attachments .gallery-video').forEach(v => {
        const sTag = v.querySelector('source');
        const vSrc = (sTag && sTag.getAttribute('src')) || v.getAttribute('src') || v.getAttribute('data-url') || '';
        const poster = v.getAttribute('poster') || '';
        if (vSrc || poster) media.push({ type: 'video', raw: vSrc || poster, poster });
      });

      const quoteEl = item.querySelector('.quote');
      let quote = null;
      if (quoteEl) {
        const qLink = quoteEl.querySelector('.quote-link');
        const qHref = qLink ? (qLink.getAttribute('href') || '') : '';
        const qPid = qHref.split('/').pop().split('#')[0] || '';
        const qUser = quoteEl.querySelector('.username')?.textContent.trim().replace(/^@/, '') || '';
        const qName = quoteEl.querySelector('.fullname')?.textContent.trim() || '';
        const qAv = quoteEl.querySelector('img.avatar')?.getAttribute('src') || '';
        const qTextEl = quoteEl.querySelector('.quote-text');
        const qText = qTextEl ? (qTextEl.innerText || qTextEl.textContent || '').trim() : '';
        const qMedia = [];
        quoteEl.querySelectorAll('.attachment img').forEach(img => {
          const s = img.getAttribute('src') || '';
          if (s) qMedia.push({ type: 'image', raw: s });
        });
        quoteEl.querySelectorAll('video').forEach(v => {
          const sTag = v.querySelector('source');
          const vs = (sTag && sTag.getAttribute('src')) || v.getAttribute('src') || '';
          const vp = v.getAttribute('poster') || '';
          if (vs || vp) qMedia.push({ type: 'video', raw: vs || vp, poster: vp });
        });
        quote = { qPid, qUser, qName, qAv, qText, qMedia };
      }

      const replyingTo = item.querySelector('.replying-to a');
      const replyUser = replyingTo ? replyingTo.textContent.trim().replace(/^@/, '') : '';

      items.push({
        postId, content, postedAt, isRetweet,
        origAuthor: isRetweet && origUserEl ? origUserEl.textContent.trim().replace(/^@/, '').toLowerCase() : username.toLowerCase(),
        origName: origNameEl ? origNameEl.textContent.trim() : '',
        origAvatar: origAvatarEl ? (origAvatarEl.getAttribute('src') || '') : '',
        statNums, media, quote, replyUser
      });
    });

    let nextCursor = '';
    doc.querySelectorAll('.show-more a').forEach(a => {
      const h = a.getAttribute('href') || '';
      if (!nextCursor && h.includes('cursor=')) nextCursor = h.split('cursor=').pop();
    });

    return {
      stats,
      displayName: nameEl ? nameEl.textContent.trim() : '',
      rawAvatar,
      rawJoinDate,
      items,
      nextCursor
    };
  }

  function localExtractXScripts(doc) {
    const ogImg = doc.querySelector('meta[property="og:image"]')?.getAttribute('content') || '';
    const titleText = doc.querySelector('title')?.textContent || '';
    const scripts = [];
    doc.querySelectorAll('script').forEach(s => {
      const t = s.textContent || '';
      if (t.includes('value:"') || t.includes('notFound') || t.includes('User not found')) scripts.push(t);
    });
    return { ogImg, titleText, scripts };
  }

  function localExtractTrends24(doc) {
    const names = [];
    const ol = doc.querySelector('ol');
    if (ol) {
      ol.querySelectorAll('li .trend-name a').forEach(a => {
        const t = a.textContent.trim();
        if (t && names.length < 20) names.push(t);
      });
    }
    return names;
  }

  function localExtractMirrors(doc) {
    const urls = [];
    doc.querySelectorAll('a[href^="http"]').forEach(a => {
      const h = (a.getAttribute('href') || '').replace(/\/+$/, '');
      if (h && !h.includes('github') && !h.includes('status.d420') && (h.includes('nitter') || h.includes('xcancel'))) {
        if (!urls.includes(h)) urls.push(h);
      }
    });
    return urls;
  }

  function localExtractNitterComments(doc, postId) {
    const comments = [];
    doc.querySelectorAll('.reply.thread .timeline-item, .replies .timeline-item').forEach(item => {
      const linkEl = item.querySelector('.tweet-link');
      const href = linkEl ? (linkEl.getAttribute('href') || '') : '';
      const pid = href.split('/').pop().split('#')[0] || '';
      if (!pid || pid === String(postId)) return;
      const uname = item.querySelector('.fullname-and-username .username')?.textContent.trim().replace(/^@/, '') || '';
      const fname = item.querySelector('.fullname-and-username .fullname')?.textContent.trim() || uname;
      const avatar = item.querySelector('.avatar')?.getAttribute('src') || '';
      const contentEl = item.querySelector('.tweet-content');
      const content = contentEl ? (contentEl.innerText || contentEl.textContent || '').trim() : '';
      const dateEl = item.querySelector('.tweet-date a');
      const postedAt = dateEl ? (dateEl.getAttribute('title') || dateEl.textContent.trim()) : '';
      let likes = '0', retweets = '0', replies = '0';
      item.querySelectorAll('.tweet-stat').forEach(st => {
        const val = st.textContent.trim();
        if (st.querySelector('.icon-heart')) likes = val;
        else if (st.querySelector('.icon-retweet')) retweets = val;
        else if (st.querySelector('.icon-comment')) replies = val;
      });
      comments.push({ pid, uname, fname, avatar, content, postedAt, likes, retweets, replies });
    });
    return comments;
  }

  function localExtractNitterRelationships(doc) {
    const users = [];
    doc.querySelectorAll('.timeline-item, .profile-result, .user-card').forEach(card => {
      const uname = card.querySelector('.username')?.textContent.trim().replace(/^@/, '') || '';
      if (!uname) return;
      const fname = card.querySelector('.fullname')?.textContent.trim() || uname;
      const avatar = card.querySelector('img.avatar')?.getAttribute('src') || '';
      const bio = card.querySelector('.tweet-content, .profile-bio')?.textContent.trim() || '';
      users.push({ username: uname, display_name: fname, avatar_url: avatar, bio });
    });
    return users;
  }

  function localExtractNitterSearchUsers(doc) {
    const users = [];
    doc.querySelectorAll('.timeline-item, .profile-result').forEach(card => {
      const uname = card.querySelector('.username')?.textContent.trim().replace(/^@/, '') || '';
      if (!uname) return;
      const fname = card.querySelector('.fullname')?.textContent.trim() || uname;
      const avatar = card.querySelector('img.avatar')?.getAttribute('src') || '';
      users.push({ username: uname, display_name: fname, avatar_url: avatar });
    });
    return users;
  }

  // Yardımcılar
  function recordMirrorSuccess(url) {
    MIRROR_HEALTH[url] = { fails: 0, lastFail: 0 };
  }

  function recordMirrorFailure(url) {
    const prev = MIRROR_HEALTH[url] || { fails: 0, lastFail: 0 };
    MIRROR_HEALTH[url] = { fails: prev.fails + 1, lastFail: Date.now() / 1000 };
  }

  function getHealthyMirrors(candidates = null) {
    const now = Date.now() / 1000;
    const pool = [...(candidates || MIRRORS)];
    const healthy = [];
    const penalized = [];
    for (const m of pool) {
      const info = MIRROR_HEALTH[m];
      if (!info || info.fails === 0 || (now - info.lastFail) > 90) {
        healthy.push(m);
      } else {
        penalized.push([info.fails, m]);
      }
    }
    penalized.sort((a, b) => a[0] - b[0]);
    return [...healthy, ...penalized.map(x => x[1])];
  }

  async function fetchWithTimeout(url, opts = {}, timeoutMs = 8000) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      return await fetch(url, {
        ...opts,
        credentials: 'omit',
        signal: ctrl.signal
      });
    } finally {
      clearTimeout(timer);
    }
  }

  function parseStat(val) {
    if (val === null || val === undefined) return 0;
    let s = String(val).trim().toUpperCase();
    if (!s) return 0;
    let mult = 1;
    if (s.endsWith('K')) { mult = 1000; s = s.slice(0, -1); }
    else if (s.endsWith('M')) { mult = 1000000; s = s.slice(0, -1); }
    else if (s.endsWith('B') && !s.includes('BİN')) { mult = 1000000000; s = s.slice(0, -1); }
    s = s.replace(/\s+/g, '');
    if (s.includes(',') && s.includes('.')) {
      s = s.replace(/[.,]/g, '');
    } else if (s.includes(',')) {
      const parts = s.split(',');
      if (mult > 1 || (parts.length === 2 && parts[1].length <= 2)) {
        s = s.replace(',', '.');
      } else {
        s = s.replace(/,/g, '');
      }
    } else if (s.includes('.')) {
      const parts = s.split('.');
      if (mult === 1 && parts.length >= 2 && parts[parts.length - 1].length === 3) {
        s = s.replace(/\./g, '');
      }
    }
    const num = parseFloat(s.replace(/[^0-9.]/g, ''));
    return Number.isFinite(num) ? Math.round(num * mult) : 0;
  }

  function cleanMediaUrl(raw) {
    if (!raw) return '';
    let u = String(raw).trim();
    if (u.startsWith('/pic/')) {
      let decoded = decodeURIComponent(u.slice(5)).replace(/&amp;/g, '&');
      if (decoded.startsWith('http')) return decoded;
      return `https://pbs.twimg.com/${decoded.replace(/^\/+/, '')}`;
    }
    if (u.startsWith('/video/')) {
      let decoded = decodeURIComponent(u.slice(7));
      if (decoded.startsWith('http')) return decoded;
      return `https://video.twimg.com/${decoded.replace(/^\/+/, '')}`;
    }
    if (u.startsWith('//')) return 'https:' + u;
    if (u.startsWith('http')) return u;
    return '';
  }

  function parseAnyDate(dtStr) {
    if (!dtStr) return null;
    const s = String(dtStr).trim();
    const isUtc = s.endsWith('Z') || s.includes(' UTC') || s.includes('+00:00');
    // ISO YYYY-MM-DD HH:MM:SS
    const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?/);
    if (iso) {
      const [, y, m, d, hh, mm, ss = '00'] = iso;
      if (isUtc) {
        return new Date(Date.UTC(+y, +m - 1, +d, +hh, +mm, +ss));
      }
      return new Date(+y, +m - 1, +d, +hh, +mm, +ss);
    }
    // Nitter format: "Nov 9, 2026 · 6:44 PM UTC"
    const clean = s.replace(/[\u00b7\ufffd\u2022]+/g, ' ').replace(/\s*UTC\s*/g, '').replace(/\s+/g, ' ').trim();
    const parsedMs = Date.parse(s.includes('UTC') ? `${clean} UTC` : clean);
    if (!Number.isNaN(parsedMs)) return new Date(parsedMs);
    return null;
  }

  function parseTwitterJoinDate(raw) {
    if (!raw) return '';
    const d = parseAnyDate(raw);
    const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
    if (d && !Number.isNaN(d.getTime())) {
      return `${months[d.getMonth()]} ${d.getFullYear()}`;
    }
    return String(raw).trim();
  }

  function formatPostRow(r) {
    if (!r) return null;
    return {
      ...r,
      media_urls: Array.isArray(r.media_urls) ? r.media_urls : XArsivDB.safeJsonArray(r.media_urls),
      quoted_media_urls: Array.isArray(r.quoted_media_urls) ? r.quoted_media_urls : XArsivDB.safeJsonArray(r.quoted_media_urls),
      is_quote: Number(r.is_quote || 0),
      is_reply: Number(r.is_reply || 0),
      is_retweet: Number(r.is_retweet || 0),
      is_deleted: Number(r.is_deleted || 0),
      likes: Number(r.likes || 0),
      retweets: Number(r.retweets || 0),
      replies: Number(r.replies || 0),
      views: Number(r.views || 0)
    };
  }

  function extractMediaFromGraphqlNode(node) {
    if (!node || typeof node !== 'object') return [];
    let n = node;
    if (n.__typename === 'TweetWithVisibilityResults') n = n.tweet || {};
    const legacy = n.legacy || {};
    const ext = legacy.extended_entities || n.extended_entities || {};
    const ent = legacy.entities || n.entities || {};
    const mediaList = n.media_entities2 || ext.media || ent.media || [];
    const items = [];
    const seen = new Set();

    for (const m of mediaList) {
      if (!m || typeof m !== 'object') continue;
      const mType = m.type || 'photo';
      const isVideo = mType === 'video' || mType === 'animated_gif' || ('video_info' in m);
      const thumbUrl = m.media_url_https || m.url || '';
      if (isVideo) {
        const variants = Array.isArray(m.video_info?.variants) ? m.video_info.variants : [];
        const mp4s = variants.filter(v => v && v.content_type === 'video/mp4').sort((a, b) => (Number(b.bitrate || 0) - Number(a.bitrate || 0)));
        let bestVid = mp4s[0]?.url || '';
        if (!bestVid) {
          const hit = variants.find(v => v && String(v.url || '').includes('.mp4'));
          bestVid = hit?.url || thumbUrl;
        }
        if (!bestVid) continue;
        const isThumbOnly = !(bestVid.toLowerCase().includes('.mp4') || bestVid.includes('video.twimg.com'));
        items.push({
          type: 'video',
          url: bestVid,
          remote_url: bestVid,
          poster: thumbUrl,
          remote_poster: thumbUrl,
          is_video_thumb: isThumbOnly
        });
      } else if (thumbUrl && !seen.has(thumbUrl)) {
        seen.add(thumbUrl);
        items.push({
          type: 'image',
          url: thumbUrl,
          remote_url: thumbUrl,
          poster: ''
        });
      }
    }
    return items;
  }

  function parseXComGraphqlData(data, username, metaInfo = {}) {
    const userRes = data?.data?.user_result_by_screen_name?.result;
    if (!userRes) return null;

    let metaName = username;
    let metaAvatar = metaInfo.ogImg || '';
    if (metaInfo.titleText && metaInfo.titleText.includes('(')) {
      metaName = metaInfo.titleText.split('(')[0].trim() || username;
    }

    const instructions = userRes?.profile_user_originals_timeline?.timeline?.instructions || [];
    const posts = [];
    const seenIds = new Set();
    let firstUserInfo = null;

    for (const inst of instructions) {
      for (const entry of (inst.entries || [])) {
        const content = entry.content || {};
        const itemContent = content.content || content;
        let tr = itemContent?.tweet_results?.result;
        if (!tr) continue;
        if (tr.__typename === 'TweetWithVisibilityResults') tr = tr.tweet || {};

        const pid = tr.rest_id;
        if (!pid || seenIds.has(pid)) continue;
        seenIds.add(pid);

        const userObj = tr.core?.user_results?.result;
        if (userObj && !firstUserInfo) firstUserInfo = userObj;

        const details = tr.details || {};
        const legacy = tr.legacy || {};
        const fullText = details.full_text || legacy.full_text || '';
        const createdMs = details.created_at_ms;
        const postedAt = createdMs
          ? XArsivDB.formatLocalDateTime(new Date(createdMs))
          : (legacy.created_at || '');

        const counts = tr.counts || {};
        const likes = counts.favorite_count ?? legacy.favorite_count ?? 0;
        const retweets = counts.retweet_count ?? legacy.retweet_count ?? 0;
        const replies = counts.reply_count ?? legacy.reply_count ?? 0;
        const views = parseInt(tr.views?.count || '0', 10) || 0;

        const authorCore = userObj?.core || {};
        const origAuthor = (authorCore.screen_name || username).toLowerCase();
        const origName = authorCore.name || metaName;
        let authorAvatar = userObj?.avatar?.image_url || metaAvatar || '';
        if (authorAvatar) authorAvatar = authorAvatar.replace('_normal.', '_400x400.');

        const isRetweet = origAuthor !== username.toLowerCase() ? 1 : 0;
        const mediaItems = extractMediaFromGraphqlNode(tr);

        let isQuote = 0, quotedPostId = '', quotedAuthor = '', quotedName = '', quotedAvatar = '', quotedContent = '', quotedMediaItems = [];
        let quotedTr = tr.quoted_tweet_results?.result || tr.quoted_status_result?.result || tr.quoted_status || null;
        if (quotedTr && quotedTr.__typename === 'TweetWithVisibilityResults') quotedTr = quotedTr.tweet || {};
        if (quotedTr && (quotedTr.rest_id || quotedTr.legacy?.full_text || quotedTr.details?.full_text)) {
          isQuote = 1;
          quotedPostId = String(quotedTr.rest_id || '');
          const qUserObj = quotedTr.core?.user_results?.result || {};
          const qCore = qUserObj.core || quotedTr.user?.core || {};
          quotedAuthor = (qCore.screen_name || '').replace(/^@/, '');
          quotedName = qCore.name || quotedAuthor;
          quotedAvatar = (qUserObj.avatar?.image_url || '').replace('_normal.', '_400x400.');
          quotedContent = quotedTr.details?.full_text || quotedTr.legacy?.full_text || '';
          quotedMediaItems = extractMediaFromGraphqlNode(quotedTr);
        }

        const replyToUsername = legacy.in_reply_to_screen_name || details.in_reply_to_screen_name || '';
        const replyToPostId = String(legacy.in_reply_to_status_id_str || details.in_reply_to_status_id_str || '');
        const isReply = replyToUsername || replyToPostId ? 1 : 0;

        posts.push({
          post_id: String(pid),
          content: fullText,
          posted_at: postedAt,
          likes: Number(likes || 0),
          retweets: Number(retweets || 0),
          replies: Number(replies || 0),
          views,
          is_retweet: isRetweet,
          original_author: origAuthor,
          original_name: origName,
          author_avatar: authorAvatar,
          media_urls: mediaItems,
          is_quote: isQuote,
          quoted_post_id: quotedPostId,
          quoted_author: quotedAuthor,
          quoted_name: quotedName,
          quoted_avatar: quotedAvatar,
          quoted_content: quotedContent,
          quoted_media_urls: quotedMediaItems,
          is_reply: isReply,
          reply_to_post_id: replyToPostId,
          reply_to_username: replyToUsername
        });
      }
    }

    const uInfo = firstUserInfo || userRes;
    const uLegacy = uInfo.legacy || {};
    const uCore = uInfo.core || {};
    let profAvatar = uInfo.avatar?.image_url || metaAvatar || '';
    if (profAvatar) profAvatar = profAvatar.replace('_normal.', '_400x400.');

    const profile = {
      display_name: uCore.name || metaName || username,
      avatar_url: profAvatar,
      total_tweets: Number(uLegacy.statuses_count || posts.length || 0),
      profile_likes: Number(uLegacy.favourites_count || 0),
      following: Number(uLegacy.friends_count || uInfo.relationship_counts?.following || 0),
      followers: Number(uLegacy.followers_count || uInfo.relationship_counts?.followers || 0),
      join_date: parseTwitterJoinDate(uCore.created_at || uLegacy.created_at || '')
    };

    return { profile, posts };
  }

  function convertNitterParsed(raw, username) {
    const s = raw.stats || {};
    const likesVal = s.likes || s['beğeniler'] || s.favoriler || '0';
    const tweetsVal = s.tweets || s['gönderiler'] || s.posts || '0';
    const followingVal = s.following || s['takip edilen'] || '0';
    const followersVal = s.followers || s['takipçiler'] || '0';

    const avatarUrl = cleanMediaUrl(raw.rawAvatar || '');
    const profile = {
      display_name: raw.displayName || username,
      avatar_url: avatarUrl,
      total_tweets: parseStat(tweetsVal),
      profile_likes: parseStat(likesVal),
      following: parseStat(followingVal),
      followers: parseStat(followersVal),
      join_date: parseTwitterJoinDate(raw.rawJoinDate || '')
    };

    const seen = new Set();
    const posts = [];
    for (const it of (raw.items || [])) {
      if (!it.postId || seen.has(it.postId)) continue;
      seen.add(it.postId);

      const media = [];
      for (const m of (it.media || [])) {
        const u = cleanMediaUrl(m.raw);
        if (!u) continue;
        if (m.type === 'video') {
          const poster = cleanMediaUrl(m.poster || '');
          media.push({
            type: 'video',
            url: u,
            remote_url: u,
            poster,
            remote_poster: poster,
            is_video_thumb: !u.toLowerCase().includes('.mp4')
          });
        } else {
          media.push({ type: 'image', url: u, remote_url: u, poster: '' });
        }
      }

      let isQuote = 0, quotedPostId = '', quotedAuthor = '', quotedName = '', quotedAvatar = '', quotedContent = '', quotedMedia = [];
      if (it.quote) {
        isQuote = 1;
        quotedPostId = it.quote.qPid || '';
        quotedAuthor = it.quote.qUser || '';
        quotedName = it.quote.qName || quotedAuthor;
        quotedAvatar = cleanMediaUrl(it.quote.qAv || '');
        quotedContent = it.quote.qText || '';
        quotedMedia = (it.quote.qMedia || []).map(qm => {
          const qu = cleanMediaUrl(qm.raw);
          return qm.type === 'video'
            ? { type: 'video', url: qu, remote_url: qu, poster: cleanMediaUrl(qm.poster || '') }
            : { type: 'image', url: qu, remote_url: qu, poster: '' };
        }).filter(x => x.url);
      }

      const replyUser = it.replyUser || '';
      const isReply = replyUser ? 1 : 0;

      posts.push({
        post_id: String(it.postId),
        content: it.content || '',
        posted_at: it.postedAt || '',
        likes: parseStat(it.statNums?.likes || '0'),
        retweets: parseStat(it.statNums?.retweets || '0'),
        replies: parseStat(it.statNums?.replies || '0'),
        views: 0,
        is_retweet: it.isRetweet ? 1 : 0,
        original_author: it.origAuthor || username.toLowerCase(),
        original_name: it.origName || profile.display_name || username,
        author_avatar: cleanMediaUrl(it.origAvatar || '') || avatarUrl,
        media_urls: media,
        is_quote: isQuote,
        quoted_post_id: quotedPostId,
        quoted_author: quotedAuthor,
        quoted_name: quotedName,
        quoted_avatar: quotedAvatar,
        quoted_content: quotedContent,
        quoted_media_urls: quotedMedia,
        is_reply: isReply,
        reply_to_post_id: '',
        reply_to_username: replyUser
      });
    }

    return { profile, posts, next_cursor: raw.nextCursor || '' };
  }

  async function fetchFromXCom(username) {
    const clean = String(username || '').trim().replace(/^@/, '');
    if (!clean) return null;
    try {
      const resp = await fetchWithTimeout(`https://x.com/${encodeURIComponent(clean)}`, {}, 8000);
      if (resp.status === 404) return { error: 'not_found', posts: [], profile: {} };
      if (!resp.ok) return null;
      const html = await resp.text();
      const ssr = await parseHtml(html, 'x_ssr');
      for (const txt of (ssr.scripts || [])) {
        if (txt.includes('"notFound"') || txt.includes('User not found') || txt.includes('s:"notFound"')) {
          return { error: 'not_found', posts: [], profile: {} };
        }
        if (txt.includes('value:"') && (txt.includes('user_result_by_screen_name') || txt.includes('profile_user_originals_timeline') || txt.includes('GraphQLRequestStream'))) {
          const valIdx = txt.indexOf('value:"');
          const start = valIdx + 7;
          let end = txt.lastIndexOf('"}}))($R[');
          if (end === -1) end = txt.lastIndexOf('"}}))');
          if (end === -1) continue;
          const rawInner = txt.slice(start, end);
          const unescaped = rawInner.replace(/\\"/g, '"').replace(/\\\\/g, '\\');
          try {
            const data = JSON.parse(unescaped);
            const parsed = parseXComGraphqlData(data, clean, { ogImg: ssr.ogImg, titleText: ssr.titleText });
            if (parsed && (parsed.posts.length || Object.keys(parsed.profile || {}).length)) {
              return parsed;
            }
          } catch {
            // Sonraki script'e geç
          }
        }
      }
    } catch {
      return null;
    }
    return null;
  }

  async function fetchNitterProfileStats(username) {
    const clean = String(username || '').trim().replace(/^@/, '').toLowerCase();
    const mirrors = getHealthyMirrors(MIRRORS).slice(0, 4);
    for (const m of mirrors) {
      try {
        const resp = await fetchWithTimeout(`${m}/${encodeURIComponent(clean)}`, {}, 4500);
        if (resp.status === 200) {
          const txt = await resp.text();
          if (txt.includes('profile-statlist')) {
            recordMirrorSuccess(m);
            const raw = await parseHtml(txt, 'nitter_timeline', { username: clean });
            return convertNitterParsed(raw, clean).profile;
          }
        }
        if (resp.status === 429 || resp.status >= 500) recordMirrorFailure(m);
      } catch {
        recordMirrorFailure(m);
      }
    }
    return null;
  }

  async function fetchUserPosts(username) {
    const clean = String(username || '').trim().replace(/^@/, '');
    const [xData, nitterStats] = await Promise.all([
      fetchFromXCom(clean),
      fetchNitterProfileStats(clean)
    ]);

    if (xData && xData.error === 'not_found') return xData;

    if (xData) {
      if (nitterStats) {
        if (nitterStats.profile_likes > 0) xData.profile.profile_likes = nitterStats.profile_likes;
        if (nitterStats.total_tweets > 0) xData.profile.total_tweets = nitterStats.total_tweets;
        if (nitterStats.following > 0 && !xData.profile.following) xData.profile.following = nitterStats.following;
        if (nitterStats.followers > 0 && !xData.profile.followers) xData.profile.followers = nitterStats.followers;
        if (nitterStats.join_date && !xData.profile.join_date) xData.profile.join_date = nitterStats.join_date;
      }
      if (xData.posts && xData.posts.length > 0) return xData;
    }

    const healthy = getHealthyMirrors(MIRRORS).slice(0, 5);
    for (const m of healthy) {
      try {
        const resp = await fetchWithTimeout(`${m}/${encodeURIComponent(clean.toLowerCase())}`, {}, 5000);
        if (resp.status === 200) {
          const txt = await resp.text();
          if (txt.includes('timeline-item')) {
            recordMirrorSuccess(m);
            const raw = await parseHtml(txt, 'nitter_timeline', { username: clean.toLowerCase() });
            const parsed = convertNitterParsed(raw, clean.toLowerCase());
            if (parsed.posts.length > 0) {
              if (nitterStats) {
                for (const k of Object.keys(nitterStats)) {
                  if (nitterStats[k] && !parsed.profile[k]) parsed.profile[k] = nitterStats[k];
                }
              }
              if (xData?.profile) {
                for (const k of Object.keys(xData.profile)) {
                  if (xData.profile[k] && !parsed.profile[k]) parsed.profile[k] = xData.profile[k];
                }
              }
              return parsed;
            }
          }
        } else {
          recordMirrorFailure(m);
        }
      } catch {
        recordMirrorFailure(m);
      }
    }

    if (xData && (xData.posts.length || Object.keys(xData.profile || {}).length)) return xData;
    return null;
  }

  async function saveToDb(username, data, options = {}) {
    const clean = String(username || '').trim().replace(/^@/, '').toLowerCase();
    const nowDate = new Date();
    const nowStr = XArsivDB.formatLocalDateTime(nowDate);
    const curHour = nowDate.getHours();
    const curDow = (nowDate.getDay() + 6) % 7; // 0=Pzt ... 6=Paz (Python weekday ile aynı)

    const existingUser = await XArsivDB.getOne('tracked_users', clean);
    const prof = data?.profile || {};
    const incomingPosts = data?.posts || [];

    const prevProfileLikes = Number(existingUser?.profile_likes || 0);
    const prevTweetsCount = Number(existingUser?.total_tweets || 0);

    const newUserObj = {
      username: clean,
      display_name: prof.display_name || existingUser?.display_name || clean,
      total_tweets: prof.total_tweets || existingUser?.total_tweets || incomingPosts.length || 0,
      profile_likes: prof.profile_likes || existingUser?.profile_likes || 0,
      following_count: prof.following || existingUser?.following_count || 0,
      followers_count: prof.followers || existingUser?.followers_count || 0,
      avatar_url: prof.avatar_url || existingUser?.avatar_url || '',
      remote_avatar_url: prof.avatar_url || existingUser?.remote_avatar_url || '',
      join_date: prof.join_date || existingUser?.join_date || '',
      added_at: existingUser?.added_at || nowStr,
      last_checked: nowStr,
      status: existingUser?.status || 'active'
    };
    await XArsivDB.putOne('tracked_users', newUserObj);

    if (prevProfileLikes > 0 && newUserObj.profile_likes > prevProfileLikes) {
      const pDiff = newUserObj.profile_likes - prevProfileLikes;
      if (pDiff <= 10000) {
        await XArsivDB.addOne('like_history', {
          username: clean, post_id: 'profile_total',
          old_likes: prevProfileLikes, new_likes: newUserObj.profile_likes, delta: pDiff,
          event_type: 'profile_like', timestamp: nowStr, hour: curHour, day_of_week: curDow
        });
        await XArsivDB.addLog(clean, `❤️ @${clean} profil beğeni sayısı arttı: ${prevProfileLikes.toLocaleString('tr-TR')} → ${newUserObj.profile_likes.toLocaleString('tr-TR')} (+${pDiff})`, nowStr);
      }
    }

    if (prevTweetsCount > 0 && newUserObj.total_tweets > prevTweetsCount) {
      const twDiff = newUserObj.total_tweets - prevTweetsCount;
      if (twDiff <= 100) {
        await XArsivDB.addOne('like_history', {
          username: clean, post_id: 'post_count_total',
          old_likes: prevTweetsCount, new_likes: newUserObj.total_tweets, delta: twDiff,
          event_type: 'post_count', timestamp: nowStr, hour: curHour, day_of_week: curDow
        });
      }
    }

    const existingPosts = await XArsivDB.getByIndex('posts', 'username', clean);
    const existingMap = new Map(existingPosts.map(p => [String(p.post_id), p]));

    let newCount = 0;
    const toSave = [];
    const fetchedIds = new Set();

    for (const p of incomingPosts) {
      const pid = String(p.post_id);
      fetchedIds.add(pid);
      delete MISSING_POST_COUNTS[pid];
      const prev = existingMap.get(pid);
      if (prev) {
        const oldLikes = Number(prev.likes || 0);
        const newLikes = Math.max(oldLikes, Number(p.likes || 0));
        if (newLikes > oldLikes && Number(p.is_retweet || 0) === 0) {
          const lDiff = newLikes - oldLikes;
          if (lDiff <= 10000) {
            await XArsivDB.addOne('like_history', {
              username: clean, post_id: pid,
              old_likes: oldLikes, new_likes: newLikes, delta: lDiff,
              event_type: 'post_like', timestamp: nowStr, hour: curHour, day_of_week: curDow
            });
          }
        }
        toSave.push({
          ...prev,
          content: p.content || prev.content,
          posted_at: p.posted_at || prev.posted_at,
          likes: newLikes,
          retweets: Math.max(Number(prev.retweets || 0), Number(p.retweets || 0)),
          replies: Math.max(Number(prev.replies || 0), Number(p.replies || 0)),
          views: Math.max(Number(prev.views || 0), Number(p.views || 0)),
          is_deleted: 0,
          is_retweet: Number(p.is_retweet ?? prev.is_retweet ?? 0),
          original_author: p.original_author || prev.original_author || clean,
          original_name: p.original_name || prev.original_name || '',
          author_avatar: p.author_avatar || prev.author_avatar || '',
          media_urls: (p.media_urls && p.media_urls.length) ? p.media_urls : (prev.media_urls || []),
          is_quote: p.is_quote ?? prev.is_quote ?? 0,
          quoted_post_id: p.quoted_post_id || prev.quoted_post_id || '',
          quoted_author: p.quoted_author || prev.quoted_author || '',
          quoted_name: p.quoted_name || prev.quoted_name || '',
          quoted_avatar: p.quoted_avatar || prev.quoted_avatar || '',
          quoted_content: p.quoted_content || prev.quoted_content || '',
          quoted_media_urls: (p.quoted_media_urls && p.quoted_media_urls.length) ? p.quoted_media_urls : (prev.quoted_media_urls || []),
          is_reply: p.is_reply ?? prev.is_reply ?? 0,
          reply_to_post_id: p.reply_to_post_id || prev.reply_to_post_id || '',
          reply_to_username: p.reply_to_username || prev.reply_to_username || '',
          is_historical: options.isHistorical ? Number(prev.is_historical ?? 1) : 0,
          updated_at: nowStr
        });
      } else {
        newCount++;
        toSave.push({
          post_id: pid,
          username: clean,
          content: p.content || '',
          posted_at: p.posted_at || '',
          likes: Number(p.likes || 0),
          retweets: Number(p.retweets || 0),
          replies: Number(p.replies || 0),
          views: Number(p.views || 0),
          is_deleted: 0,
          is_retweet: Number(p.is_retweet || 0),
          original_author: p.original_author || clean,
          original_name: p.original_name || '',
          author_avatar: p.author_avatar || '',
          media_urls: p.media_urls || [],
          is_quote: Number(p.is_quote || 0),
          quoted_post_id: p.quoted_post_id || '',
          quoted_author: p.quoted_author || '',
          quoted_name: p.quoted_name || '',
          quoted_avatar: p.quoted_avatar || '',
          quoted_content: p.quoted_content || '',
          quoted_media_urls: p.quoted_media_urls || [],
          updated_at: nowStr,
          is_historical: options.isHistorical ? 1 : 0,
          is_reply: Number(p.is_reply || 0),
          reply_to_post_id: p.reply_to_post_id || '',
          reply_to_username: p.reply_to_username || ''
        });
      }
    }

    // Silinmiş gönderi tespiti (sadece ana zaman akışı kontrolünde ve >=3 post geldiyse)
    const deletedPosts = [];
    if (!options.isHistorical && fetchedIds.size >= 3) {
      const numericFetched = incomingPosts.map(p => {
        try { return BigInt(p.post_id); } catch { return null; }
      }).filter(v => v !== null);
      if (numericFetched.length > 0) {
        const sortedFetched = [...numericFetched].sort((a, b) => (a < b ? -1 : (a > b ? 1 : 0)));
        // Sabitlenmiş eski tweetlerin alt eşiği düşürmesini önlemek için küçük veri seti dışında ilk %25'i atla
        const minFetchedId = sortedFetched.length < 8
          ? sortedFetched[0]
          : sortedFetched[Math.floor(sortedFetched.length / 4)];
        for (const prev of existingPosts) {
          if (prev.is_deleted === 1 || prev.is_historical === 1 || Number(prev.is_reply || 0) === 1) continue;
          if (fetchedIds.has(String(prev.post_id))) continue;
          let pNum = 0n;
          try { pNum = BigInt(prev.post_id); } catch { pNum = 0n; }
          if (pNum >= minFetchedId) {
            MISSING_POST_COUNTS[prev.post_id] = (MISSING_POST_COUNTS[prev.post_id] || 0) + 1;
            if (MISSING_POST_COUNTS[prev.post_id] >= 3) {
              delete MISSING_POST_COUNTS[prev.post_id];
              toSave.push({ ...prev, is_deleted: 1, updated_at: nowStr });
              deletedPosts.push(prev);
              const snippet = String(prev.content || '').slice(0, 60);
              await XArsivDB.addLog(clean, `🗑️ SİLİNEN GÖNDERİ YAKALANDI (@${clean}): "${snippet}..."`, nowStr);
            }
          }
        }
      }
    }

    if (toSave.length > 0) await XArsivDB.putMany('posts', toSave);
    if (!options.isHistorical && newCount > 0) {
      await XArsivDB.addLog(clean, `📌 @${clean} hesabından ${newCount} yeni gönderi/retweet arşivlendi.`, nowStr);
    }

    return { newCount, deletedPosts, totalSaved: toSave.length };
  }

  async function syncSingleUser(username) {
    const clean = String(username || '').trim().replace(/^@/, '').toLowerCase();
    const fetched = await fetchUserPosts(clean);
    if (!fetched || fetched.error === 'not_found') return null;
    return saveToDb(clean, fetched);
  }

  async function deepArchiveUser(username, maxPages = 20) {
    const clean = String(username || '').trim().replace(/^@/, '').toLowerCase();
    if (!clean || DEEP_ARCHIVE_ACTIVE.has(clean)) return 0;
    DEEP_ARCHIVE_ACTIVE.add(clean);
    try {
      await syncSingleUser(clean);
      const existing = await XArsivDB.getByIndex('posts', 'username', clean);
      const existingIds = new Set(existing.map(p => p.post_id));
      const userObj = await XArsivDB.getOne('tracked_users', clean);
      const targetTotal = Number(userObj?.total_tweets || 0);

      let cursor = '';
      let totalAdded = 0;

      for (let page = 1; page <= maxPages; page++) {
        if (targetTotal > 0 && existingIds.size >= targetTotal) break;
        const mirrors = getHealthyMirrors(MIRRORS).slice(0, 6);
        let pageOk = false;

        for (const m of mirrors) {
          const url = cursor
            ? `${m}/${encodeURIComponent(clean)}?cursor=${encodeURIComponent(cursor)}`
            : `${m}/${encodeURIComponent(clean)}`;
          try {
            const resp = await fetchWithTimeout(url, {}, 7500);
            if (resp.status === 200) {
              const txt = await resp.text();
              if (txt.includes('timeline-item')) {
                recordMirrorSuccess(m);
                const raw = await parseHtml(txt, 'nitter_timeline', { username: clean });
                const parsed = convertNitterParsed(raw, clean);
                if (parsed.posts.length) {
                  const res = await saveToDb(clean, parsed, { isHistorical: true });
                  totalAdded += res.newCount;
                  parsed.posts.forEach(p => existingIds.add(p.post_id));
                }
                const nextCur = parsed.next_cursor || '';
                if (!nextCur || nextCur === cursor) {
                  cursor = '';
                  pageOk = true;
                  break;
                }
                cursor = nextCur;
                pageOk = true;
                await new Promise(r => setTimeout(r, 700));
                break;
              }
            }
            recordMirrorFailure(m);
          } catch {
            recordMirrorFailure(m);
          }
        }
        if (!pageOk || !cursor) break;
      }

      // Yanıtlar (/{username}/with_replies)
      let repCursor = '';
      for (let rp = 1; rp <= 6; rp++) {
        const res = await fetchUserReplies(clean, repCursor || null);
        if (!res || res.status !== 'ok') break;
        totalAdded += res.added || 0;
        if (!res.next_cursor || res.next_cursor === repCursor) break;
        repCursor = res.next_cursor;
        await new Promise(r => setTimeout(r, 700));
      }

      const finalPosts = await XArsivDB.getByIndex('posts', 'username', clean);
      await XArsivDB.addLog(clean, `📚 @${clean} tüm gönderi ve retweet arşivi tarandı. Toplam: ${finalPosts.length} (+${totalAdded} yeni).`);
      return finalPosts.length;
    } finally {
      DEEP_ARCHIVE_ACTIVE.delete(clean);
    }
  }

  async function fetchUserReplies(username, cursor = null) {
    const clean = String(username || '').trim().replace(/^@/, '').toLowerCase();
    const mirrors = getHealthyMirrors(MIRRORS).slice(0, 5);
    for (const m of mirrors) {
      const url = cursor
        ? `${m}/${encodeURIComponent(clean)}/with_replies?cursor=${encodeURIComponent(cursor)}`
        : `${m}/${encodeURIComponent(clean)}/with_replies`;
      try {
        const resp = await fetchWithTimeout(url, {}, 6500);
        if (resp.status === 200) {
          const txt = await resp.text();
          if (txt.includes('timeline-item')) {
            recordMirrorSuccess(m);
            const raw = await parseHtml(txt, 'nitter_timeline', { username: clean });
            const parsed = convertNitterParsed(raw, clean);
            const saved = await saveToDb(clean, parsed, { isHistorical: true });
            return {
              status: 'ok',
              posts: parsed.posts,
              added: saved.newCount,
              next_cursor: parsed.next_cursor || ''
            };
          }
        }
        recordMirrorFailure(m);
      } catch {
        recordMirrorFailure(m);
      }
    }
    return { status: 'error', posts: [], added: 0, next_cursor: '' };
  }

  async function getStats(username = null) {
    const users = await XArsivDB.getAll('tracked_users');
    const activeUsers = users.filter(u => !u.status || u.status === 'active');
    const logs = await XArsivDB.getAll('activity_logs');

    if (username && username !== 'all') {
      const clean = String(username).trim().replace(/^@/, '').toLowerCase();
      const userPosts = await XArsivDB.getByIndex('posts', 'username', clean);
      const uRow = await XArsivDB.getOne('tracked_users', clean);
      const sumPostLikes = userPosts.filter(p => !p.is_retweet).reduce((a, b) => a + Number(b.likes || 0), 0);
      const totalDeleted = userPosts.filter(p => p.is_deleted === 1).length;
      const profileLikes = Number(uRow?.profile_likes || 0);
      return {
        total_users: activeUsers.length,
        total_posts: userPosts.length,
        total_archived: userPosts.length,
        total_likes: profileLikes > 0 ? profileLikes : sumPostLikes,
        sum_post_likes: sumPostLikes,
        total_deleted: totalDeleted,
        total_logs: logs.length,
        user_specific: clean
      };
    }

    const allPosts = await XArsivDB.getAll('posts');
    const trackedPosts = allPosts.filter(p => p.username !== 'live_search');
    const sumPostLikes = trackedPosts.filter(p => !p.is_retweet).reduce((a, b) => a + Number(b.likes || 0), 0);
    const totalDeleted = trackedPosts.filter(p => p.is_deleted === 1).length;
    const sumProfileLikes = activeUsers.reduce((a, u) => a + Number(u.profile_likes || 0), 0);
    return {
      total_users: activeUsers.length,
      total_posts: trackedPosts.length,
      total_archived: trackedPosts.length,
      total_likes: sumProfileLikes > 0 ? sumProfileLikes : sumPostLikes,
      sum_post_likes: sumPostLikes,
      total_deleted: totalDeleted,
      total_logs: logs.length,
      user_specific: null
    };
  }

  async function listUsers() {
    const users = await XArsivDB.getAll('tracked_users');
    const active = users.filter(u => !u.status || u.status === 'active');
    const allPosts = await XArsivDB.getAll('posts');
    const out = active.map(u => {
      const up = allPosts.filter(p => p.username === u.username);
      const del = up.filter(p => p.is_deleted === 1).length;
      const ownLikesSum = up.filter(p => !p.is_retweet).reduce((s, p) => s + Number(p.likes || 0), 0);
      const pLikes = Number(u.profile_likes || 0);
      const totLikes = pLikes > 0 ? pLikes : ownLikesSum;
      const totTweets = Number(u.total_tweets || 0) > 0 ? Number(u.total_tweets) : up.length;
      return {
        ...u,
        total_tweets: totTweets,
        total_likes: totLikes,
        own_likes_sum: ownLikesSum,
        total_likes_display: totLikes.toLocaleString('tr-TR'),
        profile_likes_display: pLikes.toLocaleString('tr-TR'),
        total_tweets_display: totTweets.toLocaleString('tr-TR'),
        post_count: up.length,
        deleted_count: del,
        archived_posts: up.length,
        deleted_posts: del
      };
    });
    out.sort((a, b) => String(b.added_at || b.last_checked || '').localeCompare(String(a.added_at || a.last_checked || '')));
    return out;
  }

  async function getUserProfile(username) {
    const clean = String(username || '').trim().replace(/^@/, '').toLowerCase();
    const user = await XArsivDB.getOne('tracked_users', clean);
    if (!user) {
      const fetched = await fetchUserPosts(clean);
      if (!fetched || fetched.error === 'not_found') {
        return { error: 'not_found' };
      }
      const p = fetched.profile || {};
      const postsList = fetched.posts || [];
      const ownLikes = postsList.filter(x => !x.is_retweet).reduce((s, x) => s + Number(x.likes || 0), 0);
      const pLikes = Number(p.profile_likes || 0);
      const totLikes = pLikes > 0 ? pLikes : ownLikes;
      const totTweets = Number(p.total_tweets || 0) || postsList.length;
      return {
        username: clean,
        display_name: p.display_name || clean,
        total_tweets: totTweets,
        profile_likes: pLikes,
        total_likes: totLikes,
        total_likes_display: totLikes.toLocaleString('tr-TR'),
        profile_likes_display: pLikes.toLocaleString('tr-TR'),
        total_tweets_display: totTweets.toLocaleString('tr-TR'),
        following_count: p.following || 0,
        followers_count: p.followers || 0,
        avatar_url: p.avatar_url || '',
        remote_avatar_url: p.avatar_url || '',
        join_date: p.join_date || '',
        is_tracked: false,
        post_count: postsList.length,
        deleted_count: 0,
        archived_posts: postsList.length,
        deleted_posts: 0,
        live_posts: postsList.map(x => formatPostRow({ ...x, username: clean }))
      };
    }
    const posts = await XArsivDB.getByIndex('posts', 'username', clean);
    const delCount = posts.filter(p => p.is_deleted === 1).length;
    const ownLikesSum = posts.filter(p => !p.is_retweet).reduce((s, p) => s + Number(p.likes || 0), 0);
    const pLikes = Number(user.profile_likes || 0);
    const totLikes = pLikes > 0 ? pLikes : ownLikesSum;
    const totTweets = Number(user.total_tweets || 0) > 0 ? Number(user.total_tweets) : posts.length;
    return {
      ...user,
      is_tracked: true,
      total_tweets: totTweets,
      total_likes: totLikes,
      own_likes_sum: ownLikesSum,
      total_likes_display: totLikes.toLocaleString('tr-TR'),
      profile_likes_display: pLikes.toLocaleString('tr-TR'),
      total_tweets_display: totTweets.toLocaleString('tr-TR'),
      post_count: posts.length,
      deleted_count: delCount,
      archived_posts: posts.length,
      deleted_posts: delCount
    };
  }

  async function addUser(username) {
    const clean = String(username || '').trim().replace(/^@/, '').toLowerCase();
    if (!clean) throw new Error('Geçerli bir kullanıcı adı girin.');
    const fetched = await fetchUserPosts(clean);
    if (fetched && fetched.error === 'not_found') {
      throw new Error(`@${clean} adında bir hesap bulunamadı.`);
    }
    if (fetched) {
      await saveToDb(clean, fetched);
    } else {
      const now = XArsivDB.formatLocalDateTime(new Date());
      await XArsivDB.putOne('tracked_users', {
        username: clean, display_name: clean,
        total_tweets: 0, profile_likes: 0, following_count: 0, followers_count: 0,
        avatar_url: '', remote_avatar_url: '', join_date: '',
        added_at: now, last_checked: now, status: 'active'
      });
    }
    // Arka planda derin arşivleme başlat (beklemeden)
    deepArchiveUser(clean, 20).catch(() => {});
    return { status: 'ok', username: clean };
  }

  function sortPostsByIdDesc(posts) {
    if (!Array.isArray(posts) || posts.length <= 1) return posts;
    const keyCache = new Map();
    for (const p of posts) {
      const raw = String(p?.post_id || '').trim();
      let bigKey = null;
      if (raw && /^\d+$/.test(raw)) {
        try { bigKey = BigInt(raw); } catch {}
      }
      keyCache.set(p, { big: bigKey, str: raw });
    }
    return posts.sort((a, b) => {
      const ka = keyCache.get(a);
      const kb = keyCache.get(b);
      if (ka.big !== null && kb.big !== null) {
        return kb.big > ka.big ? 1 : (kb.big < ka.big ? -1 : 0);
      }
      return kb.str.localeCompare(ka.str);
    });
  }

  async function getPosts({ username = null, filter_type = 'all', search = '', limit = 20, offset = 0 } = {}) {
    if ((!username || username === 'all') && filter_type === 'all' && !search) {
      return getLiveXHomeFeed(limit, offset);
    }

    let posts = [];
    if (username && username !== 'all') {
      const clean = String(username).trim().replace(/^@/, '').toLowerCase();
      posts = await XArsivDB.getByIndex('posts', 'username', clean);
      if (posts.length === 0 && offset === 0 && !search) {
        const fetched = await fetchUserPosts(clean);
        if (fetched && fetched.posts?.length) {
          if (await XArsivDB.getOne('tracked_users', clean)) {
            await saveToDb(clean, fetched);
            posts = await XArsivDB.getByIndex('posts', 'username', clean);
          } else {
            posts = fetched.posts.map(p => ({ ...p, username: clean }));
          }
        }
      }
      if ((filter_type === 'replies' || filter_type === 'reposts') && posts.length < 4 && offset === 0 && !search) {
        await fetchUserReplies(clean);
        posts = await XArsivDB.getByIndex('posts', 'username', clean);
      }
    } else {
      const users = await XArsivDB.getAll('tracked_users');
      const activeNames = new Set(users.filter(u => !u.status || u.status === 'active').map(u => u.username));
      const allPosts = await XArsivDB.getAll('posts');
      posts = allPosts.filter(p => activeNames.has(p.username));
    }

    if (filter_type === 'active') posts = posts.filter(p => Number(p.is_deleted || 0) === 0);
    else if (filter_type === 'deleted') posts = posts.filter(p => Number(p.is_deleted || 0) === 1);
    else if (filter_type === 'media') posts = posts.filter(p => Array.isArray(p.media_urls) && p.media_urls.length > 0);
    else if (filter_type === 'reposts') posts = posts.filter(p => Number(p.is_retweet || 0) === 1);
    else if (filter_type === 'replies') {
      posts = posts.filter(p => Number(p.is_reply || 0) === 1 || !!p.reply_to_username || (String(p.content || '').startsWith('@') && !p.is_retweet));
    }

    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      posts = posts.filter(p =>
        String(p.post_id) === q ||
        String(p.content || '').toLowerCase().includes(q) ||
        String(p.quoted_content || '').toLowerCase().includes(q)
      );
    }

    sortPostsByIdDesc(posts);

    const sliced = limit > 0 ? posts.slice(offset, offset + limit) : posts;
    return sliced.map(formatPostRow);
  }

  async function getLiveXHomeFeed(limit = 20, offset = 0) {
    const now = Date.now() / 1000;
    if (!LIVE_X_FEED_CACHE.posts.length || (now - LIVE_X_FEED_CACHE.lastFetched > 300)) {
      const targets = RANDOM_X_ACCOUNTS.slice(0, 6);
      const results = await Promise.allSettled(targets.map(acc => fetchFromXCom(acc)));
      const pool = [];
      for (let i = 0; i < targets.length; i++) {
        const res = results[i];
        if (res.status === 'fulfilled' && res.value?.posts?.length) {
          for (const p of res.value.posts) {
            const [reason, icon] = FEED_REASONS[Math.floor(Math.random() * FEED_REASONS.length)];
            pool.push(formatPostRow({
              ...p,
              username: targets[i].toLowerCase(),
              recommend_reason: reason,
              recommend_icon: icon
            }));
          }
        }
      }

      // Takip edilen hesapların taze gönderileri (tüm arşivden en güncel olanlar dahil)
      const users = await XArsivDB.getAll('tracked_users');
      const activeNames = new Set(users.filter(u => !u.status || u.status === 'active').map(u => u.username));
      const allPosts = await XArsivDB.getAll('posts');
      const trackedRecent = allPosts
        .filter(p => activeNames.has(p.username) && Number(p.is_deleted || 0) === 0)
        .sort((a, b) => String(b.posted_at || '').localeCompare(String(a.posted_at || '')))
        .slice(0, 40);
      for (const p of trackedRecent) {
        pool.push({
          ...formatPostRow(p),
          recommend_reason: 'Takip Ettiğin Hesap',
          recommend_icon: 'fa-user-check'
        });
      }

      pool.sort((a, b) => String(b.posted_at || '').localeCompare(String(a.posted_at || '')));
      LIVE_X_FEED_CACHE.posts = pool;
      LIVE_X_FEED_CACHE.lastFetched = now;
      LIVE_X_FEED_CACHE.fetchedIndices = targets.length;
    }

    const pool = LIVE_X_FEED_CACHE.posts;
    if (!pool.length) return [];
    const start = offset >= pool.length ? (offset % pool.length) : offset;
    const out = pool.slice(start, start + limit);
    if (out.length < limit && pool.length >= limit) {
      out.push(...pool.slice(0, limit - out.length));
    }
    return out;
  }

  async function fetchLiveTrends() {
    const now = Date.now() / 1000;
    if (TRENDS_CACHE.data.length && (now - TRENDS_CACHE.lastFetched < 600)) {
      return TRENDS_CACHE.data;
    }
    const trends = [];
    try {
      const resp = await fetchWithTimeout('https://trends24.in/turkey/', {}, 7500);
      if (resp.ok) {
        const html = await resp.text();
        const names = await parseHtml(html, 'trends24');
        names.forEach((name, idx) => {
          const low = name.toLowerCase();
          let category = 'Türkiye tarihinde gündemde';
          if (['spor', 'gs', 'fb', 'bjk', 'mac', 'derbi', 'lig'].some(w => low.includes(w))) category = 'Spor · Gündemde';
          else if (['dolar', 'borsa', 'faiz', 'hisse', 'bank', 'ekonomi'].some(w => low.includes(w))) category = 'Ekonomi · Gündemde';
          else if (['secim', 'chp', 'akp', 'meclis', 'baskan'].some(w => low.includes(w))) category = 'Siyaset · Gündemde';
          else if (['ai', 'yapay', 'tech', 'yazilim'].some(w => low.includes(w))) category = 'Teknoloji · Gündemde';
          const h = Math.abs([...name].reduce((a, c) => ((a << 5) - a + c.charCodeAt(0)) | 0, 0));
          const baseCnt = Math.max(5, Math.floor(135 - idx * 5.5 + (h % 15)));
          trends.push({
            rank: idx + 1,
            category,
            name,
            tweet_count: `${baseCnt},${h % 9} B Gönderi`,
            keyword: name
          });
        });
      }
    } catch {
      // Yedek gündemlere geç
    }

    if (!trends.length) {
      const defaults = [
        ['Türkiye tarihinde gündemde', '#Gündem', '54,2 B Gönderi'],
        ['Teknoloji · Gündemde', '#YapayZeka', '41,7 B Gönderi'],
        ['Haber · Gündemde', 'Son Dakika', '88,4 B Gönderi'],
        ['Ekonomi · Gündemde', 'Borsa', '32,1 B Gönderi'],
        ['Spor · Gündemde', 'Süper Lig', '69,0 B Gönderi']
      ];
      defaults.forEach(([category, name, tweet_count], idx) => {
        trends.push({ rank: idx + 1, category, name, tweet_count, keyword: name });
      });
    }

    TRENDS_CACHE.data = trends;
    TRENDS_CACHE.lastFetched = now;
    return trends;
  }

  async function searchX(query, tab = 'top') {
    const q = String(query || '').trim();
    if (!q) return { status: 'ok', tab, query: '', results: [], posts: [], users: [] };

    const ql = q.toLowerCase();
    const isPeopleTab = tab === 'people' || tab === 'users';

    if (isPeopleTab) {
      const trackedUsers = await XArsivDB.getAll('tracked_users');
      const seenU = new Set();
      const mergedUsers = [];
      for (const u of trackedUsers) {
        if (String(u.username || '').toLowerCase().includes(ql) || String(u.display_name || '').toLowerCase().includes(ql)) {
          const low = String(u.username).toLowerCase();
          if (!seenU.has(low)) {
            seenU.add(low);
            mergedUsers.push({
              username: u.username,
              display_name: u.display_name || u.username,
              avatar_url: (u.avatar_url && !u.avatar_url.startsWith('/media/')) ? u.avatar_url : (u.remote_avatar_url || ''),
              followers_count: u.followers_count || 0,
              total_tweets: u.total_tweets || 0,
              status: u.status || 'active'
            });
          }
        }
      }

      const mirrors = getHealthyMirrors(MIRRORS).slice(0, 4);
      for (const m of mirrors) {
        try {
          const url = `${m}/search?f=users&q=${encodeURIComponent(q)}`;
          const resp = await fetchWithTimeout(url, {}, 6000);
          if (resp.status === 200) {
            const txt = await resp.text();
            recordMirrorSuccess(m);
            const remoteUsers = (await parseHtml(txt, 'nitter_search_users'))
              .map(u => ({ ...u, avatar_url: cleanMediaUrl(u.avatar_url) }));
            for (const u of remoteUsers) {
              const low = String(u.username || '').toLowerCase();
              if (low && !seenU.has(low)) {
                seenU.add(low);
                mergedUsers.push(u);
              }
            }
            if (remoteUsers.length) break;
          } else {
            recordMirrorFailure(m);
          }
        } catch {
          recordMirrorFailure(m);
        }
      }

      return {
        status: 'ok',
        tab: 'people',
        query: q,
        results: mergedUsers.slice(0, 30),
        posts: [],
        users: mergedUsers.slice(0, 30)
      };
    }

    const allPosts = await XArsivDB.getAll('posts');
    const localMatches = allPosts
      .filter(p =>
        String(p.content || '').toLowerCase().includes(ql) ||
        String(p.username || '').toLowerCase().includes(ql) ||
        String(p.original_name || '').toLowerCase().includes(ql)
      )
      .slice(0, 25)
      .map(formatPostRow);

    const mirrors = getHealthyMirrors(MIRRORS).slice(0, 4);
    let remotePosts = [];

    for (const m of mirrors) {
      try {
        const url = `${m}/search?f=tweets&q=${encodeURIComponent(q)}`;
        const resp = await fetchWithTimeout(url, {}, 6000);
        if (resp.status === 200) {
          const txt = await resp.text();
          recordMirrorSuccess(m);
          const raw = await parseHtml(txt, 'nitter_timeline', { username: 'live_search' });
          const converted = convertNitterParsed(raw, 'live_search');
          remotePosts = converted.posts.map(p => formatPostRow({ ...p, username: p.original_author || 'live_search' }));
          if (remotePosts.length) break;
        } else {
          recordMirrorFailure(m);
        }
      } catch {
        recordMirrorFailure(m);
      }
    }

    const seen = new Set();
    let mergedPosts = [];
    for (const p of [...remotePosts, ...localMatches]) {
      if (!p || seen.has(p.post_id)) continue;
      seen.add(p.post_id);
      mergedPosts.push(p);
    }

    if (tab === 'media') {
      mergedPosts = mergedPosts.filter(p => Array.isArray(p.media_urls) && p.media_urls.length > 0);
    } else if (tab === 'latest') {
      sortPostsByIdDesc(mergedPosts);
    } else {
      mergedPosts.sort((a, b) =>
        (Number(b.likes || 0) + Number(b.retweets || 0) * 2 + Number(b.replies || 0)) -
        (Number(a.likes || 0) + Number(a.retweets || 0) * 2 + Number(a.replies || 0))
      );
    }

    const finalResults = mergedPosts.slice(0, 40);
    return {
      status: 'ok',
      tab,
      query: q,
      results: finalResults,
      posts: finalResults,
      users: []
    };
  }

  async function getTweetComments(username, postId) {
    const cleanU = String(username || '').trim().replace(/^@/, '').toLowerCase();
    const cleanPid = String(postId || '').trim();
    const mirrors = getHealthyMirrors(MIRRORS).slice(0, 4);
    for (const m of mirrors) {
      try {
        const url = `${m}/${encodeURIComponent(cleanU || 'i')}/status/${encodeURIComponent(cleanPid)}`;
        const resp = await fetchWithTimeout(url, {}, 6500);
        if (resp.status === 200) {
          const txt = await resp.text();
          recordMirrorSuccess(m);
          const rawComments = await parseHtml(txt, 'nitter_comments', { postId: cleanPid });
          if (rawComments.length) {
            return {
              status: 'ok',
              comments: rawComments.map(c => ({
                post_id: c.pid,
                username: c.uname,
                display_name: c.fname,
                avatar_url: cleanMediaUrl(c.avatar),
                content: c.content,
                posted_at: c.postedAt,
                likes: parseStat(c.likes),
                retweets: parseStat(c.retweets),
                replies: parseStat(c.replies)
              }))
            };
          }
        }
      } catch {
        recordMirrorFailure(m);
      }
    }
    // DB içi yanıtları da kontrol et
    const dbReplies = await XArsivDB.getByIndex('posts', 'reply_to_post_id', cleanPid);
    return { status: 'ok', comments: dbReplies.map(formatPostRow) };
  }

  async function getTweetVideoUrl(postId) {
    const cleanPid = String(postId || '').trim();
    const post = await XArsivDB.getOne('posts', cleanPid);
    if (post) {
      for (const list of [post.media_urls, post.quoted_media_urls]) {
        for (const m of (Array.isArray(list) ? list : [])) {
          if (m && m.type === 'video') {
            const rem = m.remote_url || m.url || '';
            if (rem && (rem.toLowerCase().includes('.mp4') || rem.includes('video.twimg.com'))) {
              return { status: 'ok', video_url: rem, proxy_url: rem, poster: m.poster || '', is_local: false };
            }
          }
        }
      }
    }

    try {
      const resp = await fetchWithTimeout(`https://x.com/i/status/${encodeURIComponent(cleanPid)}`, {}, 8000);
      if (resp.status === 200) {
        const html = await resp.text();
        const ssr = await parseHtml(html, 'x_ssr');
        for (const txt of (ssr.scripts || [])) {
          if (!txt.includes('value:"') || (!txt.includes('threaded_conversation') && !txt.includes('tweet_result'))) continue;
          const idx = txt.indexOf('value:"');
          const start = idx + 7;
          let end = txt.lastIndexOf('"}}))($R[');
          if (end === -1) end = txt.lastIndexOf('"}}))');
          if (end === -1) continue;
          try {
            const data = JSON.parse(txt.slice(start, end).replace(/\\"/g, '"').replace(/\\\\/g, '\\'));
            let bestVid = '';
            const walk = (obj) => {
              if (!obj || typeof obj !== 'object' || bestVid) return;
              if (obj.video_info?.variants) {
                const mp4s = obj.video_info.variants
                  .filter(v => v && v.content_type === 'video/mp4')
                  .sort((a, b) => Number(b.bitrate || 0) - Number(a.bitrate || 0));
                if (mp4s[0]?.url) { bestVid = mp4s[0].url; return; }
              }
              for (const k of Object.keys(obj)) walk(obj[k]);
            };
            walk(data);
            if (bestVid) {
              return { status: 'ok', video_url: bestVid, proxy_url: bestVid, is_local: false };
            }
          } catch {}
        }
      }
    } catch {}
    return { status: 'error', message: 'Video akışı bulunamadı.' };
  }

  async function getUserRelationships(username, type = 'followers') {
    const clean = String(username || '').trim().replace(/^@/, '').toLowerCase();
    const path = type === 'following' ? 'following' : 'followers';
    const mirrors = getHealthyMirrors(MIRRORS).slice(0, 4);
    for (const m of mirrors) {
      try {
        const resp = await fetchWithTimeout(`${m}/${encodeURIComponent(clean)}/${path}`, {}, 6000);
        if (resp.status === 200) {
          const txt = await resp.text();
          recordMirrorSuccess(m);
          const users = await parseHtml(txt, 'nitter_relationships');
          return {
            status: 'ok',
            users: users.map(u => ({ ...u, avatar_url: cleanMediaUrl(u.avatar_url) }))
          };
        }
      } catch {
        recordMirrorFailure(m);
      }
    }
    return { status: 'error', users: [] };
  }

  async function predictUserActivity(username, period = 'all') {
    const clean = String(username || '').trim().replace(/^@/, '').toLowerCase();
    const uRow = await XArsivDB.getOne('tracked_users', clean);
    const posts = await XArsivDB.getByIndex('posts', 'username', clean);
    const likesHist = await XArsivDB.getByIndex('like_history', 'username', clean);
    const logs = await XArsivDB.getByIndex('activity_logs', 'username', clean);

    const nowDt = new Date();
    const daysMap = { '1d': 1, '7d': 7, '1m': 30, '3m': 90, '6m': 180, '1y': 365, 'all': null };
    const days = daysMap[period] ?? null;
    const cutoffDt = days ? new Date(nowDt.getTime() - days * 86400 * 1000) : null;

    let displayName = uRow?.display_name || clean;
    let avatarUrl = uRow?.avatar_url || '';
    const profileLikes = Number(uRow?.profile_likes || 0);
    const totalTweets = Number(uRow?.total_tweets || 0);
    const followersCount = Number(uRow?.followers_count || 0);
    const followingCount = Number(uRow?.following_count || 0);
    const joinDate = uRow?.join_date || '';

    if ((!uRow || displayName === clean || !avatarUrl) && posts.length) {
      const sample = posts.find(p => p.original_name || p.author_avatar);
      if (sample) {
        if (displayName === clean && sample.original_name) displayName = sample.original_name;
        if (!avatarUrl && sample.author_avatar) avatarUrl = sample.author_avatar;
      }
    }

    const totalPostLikes = posts.filter(p => !p.is_retweet).reduce((s, p) => s + Number(p.likes || 0), 0);
    const totalLikes = profileLikes > 0 ? profileLikes : totalPostLikes;
    const displayTweets = totalTweets > 0 ? totalTweets : posts.length;

    const hourlyActivity = new Array(24).fill(0);
    const hourlyPostCounts = new Array(24).fill(0);
    const hourlyLikeGains = new Array(24).fill(0);
    const netLikeGains = new Array(24).fill(0);
    const dayCounts = new Array(7).fill(0);
    let totalEvents = 0;

    for (const r of posts) {
      const dt = parseAnyDate(r.posted_at);
      if (!dt) continue;
      if (cutoffDt && dt < cutoffDt) continue;
      const h = dt.getHours();
      const d = (dt.getDay() + 6) % 7;
      const likes = Number(r.likes || 0);
      const retweets = Number(r.retweets || 0);
      const replies = Number(r.replies || 0);
      const isRt = Number(r.is_retweet || 0);

      hourlyPostCounts[h] += 1;
      if (isRt === 0) hourlyLikeGains[h] += likes;
      dayCounts[d] += 2.0;

      const engScore = isRt === 0
        ? Math.log1p(likes + retweets * 2 + replies * 3) * 2.5
        : Math.log1p(retweets + replies) * 1.5;
      hourlyActivity[h] += 10.0 + engScore;
      totalEvents += 1;
    }

    // like_history post_id başına net artış (RT'ler hariç)
    const postsMap = new Map(posts.map(p => [String(p.post_id), p]));
    const groupedPostLikes = new Map();
    for (const lh of likesHist) {
      const dt = parseAnyDate(lh.timestamp);
      if (cutoffDt && dt && dt < cutoffDt) continue;
      const h = Number(lh.hour);
      const d = Number(lh.day_of_week);
      const delta = Number(lh.delta || 0);
      const ev = lh.event_type || 'profile_like';
      if (!(h >= 0 && h < 24 && delta > 0 && delta <= 10000)) continue;

      if (ev === 'post_like') {
        const pRow = postsMap.get(String(lh.post_id));
        if (pRow && Number(pRow.is_retweet || 0) !== 0) continue;
        const key = `${lh.post_id}_${h}_${d}`;
        const prev = groupedPostLikes.get(key) || { h, d, minOld: Number(lh.old_likes || 0), maxNew: Number(lh.new_likes || 0) };
        prev.minOld = Math.min(prev.minOld, Number(lh.old_likes || 0));
        prev.maxNew = Math.max(prev.maxNew, Number(lh.new_likes || 0));
        groupedPostLikes.set(key, prev);
      } else if (ev === 'post_count' && delta <= 100) {
        hourlyPostCounts[h] += delta;
        hourlyActivity[h] += delta * 8.0;
        totalEvents += delta;
        if (d >= 0 && d < 7) dayCounts[d] += 1.0;
      } else if (ev === 'profile_like') {
        netLikeGains[h] += delta;
        hourlyActivity[h] += Math.min(delta, 50) * 3.0;
        totalEvents += 1;
        if (d >= 0 && d < 7) dayCounts[d] += 1.0;
      }
    }

    for (const g of groupedPostLikes.values()) {
      const net = g.maxNew - g.minOld;
      if (net > 0 && net <= 10000) {
        netLikeGains[g.h] += net;
        hourlyActivity[g.h] += Math.log1p(net) * 2.0;
        totalEvents += 1;
        if (g.d >= 0 && g.d < 7) dayCounts[g.d] += 1.0;
      }
    }

    for (const lg of logs) {
      const dt = parseAnyDate(lg.timestamp);
      if (!dt) continue;
      if (cutoffDt && dt < cutoffDt) continue;
      hourlyActivity[dt.getHours()] += 0.5;
      dayCounts[(dt.getDay() + 6) % 7] += 0.5;
    }

    let maxHVal = Math.max(...hourlyActivity);
    if (maxHVal === 0) {
      const sim = [1, 0, 0, 0, 0, 1, 2, 4, 7, 8, 9, 8, 10, 11, 10, 9, 8, 12, 14, 15, 14, 11, 6, 3];
      for (let h = 0; h < 24; h++) hourlyActivity[h] = sim[h];
      maxHVal = Math.max(...hourlyActivity);
      totalEvents = 24;
    }
    const totalWeight = hourlyActivity.reduce((a, b) => a + b, 0) || 1.0;

    const pad = n => `${String(n).padStart(2, '0')}:00`;
    const topLikeHours = [];
    const topNetLikeGains = [];
    const topPostHours = [];
    for (let h = 0; h < 24; h++) {
      if (hourlyLikeGains[h] > 0) {
        topLikeHours.push({
          hour: h,
          label: `${pad(h)} - ${pad((h + 1) % 24)}`,
          increase: hourlyLikeGains[h],
          badge: `${pad(h)} (${hourlyLikeGains[h].toLocaleString('tr-TR')} Beğeni)`
        });
      }
      if (netLikeGains[h] > 0) {
        topNetLikeGains.push({
          hour: h,
          label: `${pad(h)} - ${pad((h + 1) % 24)}`,
          increase: netLikeGains[h],
          badge: `${pad(h)} (+${netLikeGains[h].toLocaleString('tr-TR')} Net)`
        });
      }
      if (hourlyPostCounts[h] > 0) {
        topPostHours.push({
          hour: h,
          label: `${pad(h)} - ${pad((h + 1) % 24)}`,
          count: hourlyPostCounts[h],
          badge: `${pad(h)} (${hourlyPostCounts[h]} Gönderi)`
        });
      }
    }
    topLikeHours.sort((a, b) => b.increase - a.increase);
    topNetLikeGains.sort((a, b) => b.increase - a.increase);
    topPostHours.sort((a, b) => b.count - a.count);

    const bestLikeH = topLikeHours[0]?.hour ?? 20;
    const peakLikeHour = `${pad(bestLikeH)} - ${pad((bestLikeH + 1) % 24)}`;
    const bestPostH = topPostHours[0]?.hour ?? 18;
    const peakPostHour = `${pad(bestPostH)} - ${pad((bestPostH + 1) % 24)}`;

    let best3Start = 0, best3Sum = -1;
    let sleepStart = 0, sleepSum = Infinity;
    for (let h = 0; h < 24; h++) {
      const s3 = hourlyActivity[h] + hourlyActivity[(h + 1) % 24] + hourlyActivity[(h + 2) % 24];
      if (s3 > best3Sum) { best3Sum = s3; best3Start = h; }
      let s6 = 0;
      for (let i = 0; i < 6; i++) s6 += hourlyActivity[(h + i) % 24];
      if (s6 < sleepSum) { sleepSum = s6; sleepStart = h; }
    }
    const peakEnd = (best3Start + 3) % 24;
    const sleepEnd = (sleepStart + 6) % 24;
    const peakHoursStr = `${pad(best3Start)} - ${pad(peakEnd)}`;
    const sleepWindowStr = `${pad(sleepStart)} - ${pad(sleepEnd)}`;

    const sumRange = arr => arr.reduce((a, h) => a + hourlyActivity[h], 0);
    const nightPct = Math.round((sumRange([0, 1, 2, 3, 4, 5]) / totalWeight) * 100);
    const morningPct = Math.round((sumRange([6, 7, 8, 9, 10, 11]) / totalWeight) * 100);
    const afternoonPct = Math.round((sumRange([12, 13, 14, 15, 16, 17]) / totalWeight) * 100);
    const eveningPct = Math.round((sumRange([18, 19, 20, 21, 22, 23]) / totalWeight) * 100);

    let chronotype = 'Dengeli / Gün İçi Aktif';
    let chronotypeDesc = 'Kullanıcı gün içine yayılan düzenli bir kullanım ve paylaşım rutinine sahiptir.';
    if (nightPct >= 35 || (sleepStart >= 3 && sleepStart <= 6)) {
      chronotype = 'Gece Kuşu (Baykuş Tipi)';
      chronotypeDesc = 'Kullanıcı gece geç saatlerde ve sabaha karşı etkileşime girmekte, uyku penceresi geç saatlere kaymaktadır.';
    } else if (morningPct >= 30 && sleepStart <= 23) {
      chronotype = 'Erkenci (Tarla Kuşu Tipi)';
      chronotypeDesc = 'Kullanıcı sabah erken saatlerde en yüksek aktiviteyi göstermekte ve erken saatlerde pasifleşmektedir.';
    } else if (eveningPct >= 35) {
      chronotype = 'Akşamüstü / İş Çıkışı Yoğun';
      chronotypeDesc = 'Kullanıcı akşam saatlerinde (18:00-00:00) yoğun bir beğeni ve paylaşım trafiği sergilemektedir.';
    }

    const dayNames = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];
    const peakDaysStr = [...dayCounts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 2)
      .map(([idx]) => dayNames[idx])
      .join(', ');

    const nowH = nowDt.getHours();
    const curRatio = hourlyActivity[nowH] / (maxHVal || 1);
    const sleepHoursSet = new Set(Array.from({ length: 6 }, (_, i) => (sleepStart + i) % 24));
    const peakHoursSet = new Set(Array.from({ length: 3 }, (_, i) => (best3Start + i) % 24));

    let statusBadge = 'Düşük Aktivite / Pasif';
    let isOnlineLikely = false;
    let probabilityText = `%${Math.max(15, Math.min(50, Math.round(curRatio * 100)))} Olasılık`;
    if (sleepHoursSet.has(nowH)) {
      statusBadge = 'Muhtemelen Uyuyor (Pasif)';
      probabilityText = `%${Math.max(5, Math.round(curRatio * 100))} Olasılık`;
    } else if (peakHoursSet.has(nowH) || curRatio >= 0.7) {
      statusBadge = 'Çevrimiçi / Zirve Saatinde';
      isOnlineLikely = true;
      probabilityText = `%${Math.max(75, Math.min(98, Math.round(curRatio * 100)))} Olasılık`;
    } else if (curRatio >= 0.35) {
      statusBadge = 'Orta Düzey Aktif';
      isOnlineLikely = true;
      probabilityText = `%${Math.max(45, Math.min(74, Math.round(curRatio * 100)))} Olasılık`;
    }

    const hourlyDistribution = Array.from({ length: 24 }, (_, h) => ({
      hour: h,
      label: pad(h),
      score: Math.round(hourlyActivity[h] * 10) / 10,
      percent: Math.round((hourlyActivity[h] / (maxHVal || 1)) * 100),
      likes_increase: hourlyLikeGains[h],
      posts_increase: hourlyPostCounts[h],
      is_sleep: sleepHoursSet.has(h),
      is_peak: peakHoursSet.has(h),
      is_current: h === nowH
    }));

    const totalLikesDisplay = totalLikes.toLocaleString('tr-TR');
    const totalTweetsDisplay = displayTweets.toLocaleString('tr-TR');
    const profileLikesDisplay = profileLikes.toLocaleString('tr-TR');

    const summaryText = `@${clean} profil verilerine göre toplam ${totalLikesDisplay} beğeniye ve ${totalTweetsDisplay} gönderiye sahiptir. Gönderileri en çok ${peakLikeHour} aralığında beğeni almış, gönderi paylaşımları ${peakPostHour} saatlerinde yoğunlaşmaktadır. Tahmini uyku penceresi ${sleepWindowStr} aralığıdır.`;
    const aiPrompt = `Kullanıcı: @${clean} (${displayName})\nToplam Beğeni: ${totalLikesDisplay} | Toplam Tweet: ${totalTweetsDisplay}\nEn Yoğun Beğeni Saati: ${peakLikeHour}\nEn Yoğun Gönderi Saati: ${peakPostHour}\nUyku Penceresi: ${sleepWindowStr}\nKronotip: ${chronotype}\nEn Aktif Günler: ${peakDaysStr}`;

    return {
      username: clean,
      display_name: displayName,
      avatar_url: avatarUrl,
      followers_count: followersCount,
      following_count: followingCount,
      join_date: joinDate,
      total_likes: totalLikes,
      total_likes_display: totalLikesDisplay,
      profile_likes: profileLikes,
      profile_likes_display: profileLikesDisplay,
      total_tweets: displayTweets,
      total_tweets_display: totalTweetsDisplay,
      total_post_likes: totalPostLikes,
      total_events: totalEvents,
      peak_hours: peakHoursStr,
      sleep_window: sleepWindowStr,
      chronotype,
      chronotype_desc: chronotypeDesc,
      peak_days: peakDaysStr,
      peak_like_hour: peakLikeHour,
      peak_post_hour: peakPostHour,
      top_like_hours: topLikeHours,
      net_like_gains: topNetLikeGains,
      top_post_hours: topPostHours,
      night_pct: nightPct,
      morning_pct: morningPct,
      afternoon_pct: afternoonPct,
      evening_pct: eveningPct,
      current_status: {
        status_badge: statusBadge,
        is_online_likely: isOnlineLikely,
        probability_text: probabilityText,
        current_hour: nowH
      },
      hourly_distribution: hourlyDistribution,
      ai_prompt: aiPrompt,
      summary_text: summaryText,
      period,
      period_cutoff: cutoffDt ? XArsivDB.formatLocalDateTime(cutoffDt) : null
    };
  }

  async function buildExportJson() {
    const users = await XArsivDB.getAll('tracked_users');
    const posts = (await XArsivDB.getAll('posts')).filter(p => p.username !== 'live_search');
    const likeHistory = await XArsivDB.getAll('like_history');
    const activityLogs = await XArsivDB.getAll('activity_logs');
    return {
      exported_at: XArsivDB.formatLocalDateTime(new Date()),
      total_posts: posts.length,
      tracked_users: users,
      users,
      posts,
      like_history: likeHistory,
      activity_logs: activityLogs
    };
  }

  async function buildExportCsv() {
    const posts = (await XArsivDB.getAll('posts')).filter(p => p.username !== 'live_search');
    const esc = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const headers = ['post_id', 'username', 'content', 'posted_at', 'likes', 'retweets', 'replies', 'is_deleted', 'is_retweet', 'updated_at'];
    const lines = [headers.join(',')];
    for (const p of posts) {
      lines.push(headers.map(h => esc(p[h])).join(','));
    }
    return '\ufeff' + lines.join('\r\n');
  }

  return {
    MIRRORS,
    parseAnyDate,
    cleanMediaUrl,
    syncSingleUser,
    deepArchiveUser,
    getStats,
    listUsers,
    getUserProfile,
    addUser,
    getPosts,
    fetchLiveTrends,
    searchX,
    getTweetComments,
    getTweetVideoUrl,
    getUserRelationships,
    predictUserActivity,
    buildExportJson,
    buildExportCsv
  };
})();

if (typeof self !== 'undefined') self.XArsivEngine = XArsivEngine;
if (typeof window !== 'undefined') window.XArsivEngine = XArsivEngine;
