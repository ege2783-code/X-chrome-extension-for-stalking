// IndexedDB veri katmanı: SQLite (tracked_users, posts, like_history, activity_logs) karşılığı
const XArsivDB = (() => {
  const DB_NAME = 'x_arsiv_ext_db';
  const DB_VERSION = 1;
  let _dbPromise = null;

  function open() {
    if (_dbPromise) return _dbPromise;
    _dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;

        if (!db.objectStoreNames.contains('tracked_users')) {
          db.createObjectStore('tracked_users', { keyPath: 'username' });
        }
        if (!db.objectStoreNames.contains('posts')) {
          const ps = db.createObjectStore('posts', { keyPath: 'post_id' });
          ps.createIndex('username', 'username', { unique: false });
          ps.createIndex('is_deleted', 'is_deleted', { unique: false });
          ps.createIndex('is_retweet', 'is_retweet', { unique: false });
          ps.createIndex('is_historical', 'is_historical', { unique: false });
          ps.createIndex('reply_to_post_id', 'reply_to_post_id', { unique: false });
        }
        if (!db.objectStoreNames.contains('like_history')) {
          const lh = db.createObjectStore('like_history', { keyPath: 'id', autoIncrement: true });
          lh.createIndex('username', 'username', { unique: false });
          lh.createIndex('post_id', 'post_id', { unique: false });
          lh.createIndex('hour', 'hour', { unique: false });
        }
        if (!db.objectStoreNames.contains('activity_logs')) {
          const al = db.createObjectStore('activity_logs', { keyPath: 'id', autoIncrement: true });
          al.createIndex('username', 'username', { unique: false });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => {
        _dbPromise = null;
        reject(req.error);
      };
    });
    return _dbPromise;
  }

  function txDone(tx) {
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error('Transaction aborted'));
    });
  }

  function reqPromise(req) {
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function getAll(storeName) {
    const db = await open();
    const tx = db.transaction(storeName, 'readonly');
    return reqPromise(tx.objectStore(storeName).getAll());
  }

  async function getByIndex(storeName, indexName, key) {
    const db = await open();
    const tx = db.transaction(storeName, 'readonly');
    return reqPromise(tx.objectStore(storeName).index(indexName).getAll(key));
  }

  async function getOne(storeName, key) {
    const db = await open();
    const tx = db.transaction(storeName, 'readonly');
    return reqPromise(tx.objectStore(storeName).get(key));
  }

  async function putOne(storeName, obj) {
    const db = await open();
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).put(obj);
    await txDone(tx);
    return obj;
  }

  async function putMany(storeName, items) {
    if (!items || !items.length) return;
    const db = await open();
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    for (const item of items) {
      store.put(item);
    }
    await txDone(tx);
  }

  async function addOne(storeName, obj) {
    const db = await open();
    const tx = db.transaction(storeName, 'readwrite');
    const req = tx.objectStore(storeName).add(obj);
    const id = await reqPromise(req);
    await txDone(tx);
    return id;
  }

  async function deleteOne(storeName, key) {
    const db = await open();
    const tx = db.transaction(storeName, 'readwrite');
    tx.objectStore(storeName).delete(key);
    await txDone(tx);
  }

  async function clearAll() {
    const db = await open();
    const names = ['tracked_users', 'posts', 'like_history', 'activity_logs'];
    const tx = db.transaction(names, 'readwrite');
    for (const n of names) tx.objectStore(n).clear();
    await txDone(tx);
  }

  async function deleteUserAndData(username) {
    const clean = String(username || '').trim().replace(/^@/, '').toLowerCase();
    const db = await open();
    const posts = await getByIndex('posts', 'username', clean);
    const likes = await getByIndex('like_history', 'username', clean);
    const logs = await getByIndex('activity_logs', 'username', clean);
    const tx = db.transaction(['tracked_users', 'posts', 'like_history', 'activity_logs'], 'readwrite');
    tx.objectStore('tracked_users').delete(clean);
    const ps = tx.objectStore('posts');
    for (const p of posts) ps.delete(p.post_id);
    const ls = tx.objectStore('like_history');
    for (const l of likes) ls.delete(l.id);
    const als = tx.objectStore('activity_logs');
    for (const a of logs) als.delete(a.id);
    await txDone(tx);
  }

  async function addLog(username, action, timestamp) {
    return addOne('activity_logs', {
      username: String(username || '').toLowerCase(),
      action: String(action || ''),
      timestamp: timestamp || formatLocalDateTime(new Date())
    });
  }

  function formatLocalDateTime(d = new Date()) {
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  async function importBackupJson(jsonObj) {
    // Mevcut Python /export/json (tracked_users) veya uzantı (users) yedeğini içe aktarır
    const db = await open();
    const rawUsers = Array.isArray(jsonObj?.tracked_users)
      ? jsonObj.tracked_users
      : (Array.isArray(jsonObj?.users) ? jsonObj.users : []);
    const users = rawUsers;
    const posts = Array.isArray(jsonObj?.posts) ? jsonObj.posts : (Array.isArray(jsonObj) ? jsonObj : []);
    const likeHistory = Array.isArray(jsonObj?.like_history) ? jsonObj.like_history : [];
    const logs = Array.isArray(jsonObj?.activity_logs) ? jsonObj.activity_logs : [];

    const tx = db.transaction(['tracked_users', 'posts', 'like_history', 'activity_logs'], 'readwrite');
    const uStore = tx.objectStore('tracked_users');
    const pStore = tx.objectStore('posts');
    const lStore = tx.objectStore('like_history');
    const aStore = tx.objectStore('activity_logs');

    const now = formatLocalDateTime(new Date());
    const userSet = new Set();

    for (const u of users) {
      if (!u || !u.username) continue;
      const uname = String(u.username).trim().replace(/^@/, '').toLowerCase();
      userSet.add(uname);
      uStore.put({
        username: uname,
        display_name: u.display_name || uname,
        total_tweets: Number(u.total_tweets || 0),
        profile_likes: Number(u.profile_likes || 0),
        following_count: Number(u.following_count || 0),
        followers_count: Number(u.followers_count || 0),
        avatar_url: u.avatar_url || '',
        remote_avatar_url: u.remote_avatar_url || u.avatar_url || '',
        join_date: u.join_date || '',
        added_at: u.added_at || now,
        last_checked: u.last_checked || now,
        status: u.status || 'active'
      });
    }

    let importedPosts = 0;
    for (const p of posts) {
      if (!p || !p.post_id) continue;
      const uname = String(p.username || '').trim().replace(/^@/, '').toLowerCase();
      if (uname && uname !== 'live_search' && !userSet.has(uname) && users.length === 0) {
        userSet.add(uname);
        uStore.put({
          username: uname,
          display_name: p.original_name || uname,
          total_tweets: 0,
          profile_likes: 0,
          following_count: 0,
          followers_count: 0,
          avatar_url: p.author_avatar || '',
          remote_avatar_url: p.author_avatar || '',
          join_date: '',
          added_at: now,
          last_checked: now,
          status: 'active'
        });
      }
      pStore.put({
        post_id: String(p.post_id),
        username: uname,
        content: p.content || '',
        posted_at: p.posted_at || '',
        likes: Number(p.likes || 0),
        retweets: Number(p.retweets || 0),
        replies: Number(p.replies || 0),
        views: Number(p.views || 0),
        is_deleted: Number(p.is_deleted || 0),
        is_retweet: Number(p.is_retweet || 0),
        original_author: (p.original_author || uname).toLowerCase(),
        original_name: p.original_name || '',
        author_avatar: p.author_avatar || '',
        media_urls: Array.isArray(p.media_urls) ? p.media_urls : safeJsonArray(p.media_urls),
        is_quote: Number(p.is_quote || 0),
        quoted_post_id: String(p.quoted_post_id || ''),
        quoted_author: p.quoted_author || '',
        quoted_name: p.quoted_name || '',
        quoted_avatar: p.quoted_avatar || '',
        quoted_content: p.quoted_content || '',
        quoted_media_urls: Array.isArray(p.quoted_media_urls) ? p.quoted_media_urls : safeJsonArray(p.quoted_media_urls),
        updated_at: p.updated_at || now,
        is_historical: Number(p.is_historical || 0),
        is_reply: Number(p.is_reply || 0),
        reply_to_post_id: String(p.reply_to_post_id || ''),
        reply_to_username: p.reply_to_username || ''
      });
      importedPosts++;
    }

    for (const lh of likeHistory) {
      if (!lh || !lh.username) continue;
      const copy = { ...lh };
      delete copy.id;
      lStore.add(copy);
    }

    for (const lg of logs) {
      if (!lg || !lg.action) continue;
      const copy = { ...lg };
      delete copy.id;
      aStore.add(copy);
    }

    aStore.add({
      username: 'system',
      action: `📥 Yedek içe aktarıldı: ${importedPosts} gönderi, ${userSet.size} hesap.`,
      timestamp: now
    });

    await txDone(tx);
    return { users: userSet.size, posts: importedPosts, like_history: likeHistory.length };
  }

  function safeJsonArray(val) {
    if (Array.isArray(val)) return val;
    if (!val || typeof val !== 'string') return [];
    try {
      const parsed = JSON.parse(val);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  return {
    open,
    getAll,
    getByIndex,
    getOne,
    putOne,
    putMany,
    addOne,
    deleteOne,
    clearAll,
    deleteUserAndData,
    addLog,
    formatLocalDateTime,
    importBackupJson,
    safeJsonArray
  };
})();

if (typeof self !== 'undefined') self.XArsivDB = XArsivDB;
if (typeof window !== 'undefined') window.XArsivDB = XArsivDB;
