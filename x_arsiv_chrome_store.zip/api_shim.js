// Extension API Shim: Dashboard'daki fetch('/api/...') ve export çağrılarını IndexedDB + XArsivEngine'e yönlendirir
(() => {
  const origFetch = window.fetch.bind(window);

  function jsonResp(data, status = 200) {
    return new Response(JSON.stringify(data), {
      status,
      headers: { 'Content-Type': 'application/json; charset=utf-8' }
    });
  }

  function normalizeMediaArr(arr) {
    if (!Array.isArray(arr)) return [];
    return arr.map(m => {
      if (!m || typeof m !== 'object') return m;
      const copy = { ...m };
      if (copy.url && String(copy.url).startsWith('/media/') && copy.remote_url) {
        copy.url = copy.remote_url;
      }
      if (copy.poster && String(copy.poster).startsWith('/media/') && copy.remote_poster) {
        copy.poster = copy.remote_poster;
      }
      return copy;
    });
  }

  function normalizePostForExt(p) {
    if (!p) return p;
    const copy = { ...p };
    if (copy.author_avatar && String(copy.author_avatar).startsWith('/media/')) {
      copy.author_avatar = copy.remote_avatar_url || '';
    }
    if (copy.quoted_avatar && String(copy.quoted_avatar).startsWith('/media/')) {
      copy.quoted_avatar = '';
    }
    copy.media_urls = normalizeMediaArr(copy.media_urls);
    copy.quoted_media_urls = normalizeMediaArr(copy.quoted_media_urls);
    return copy;
  }

  async function handleApiRequest(urlObj, method, bodyText) {
    const path = urlObj.pathname;
    const sp = urlObj.searchParams;

    // 1. /api/stats
    if (path === '/api/stats' && method === 'GET') {
      const username = sp.get('username');
      return jsonResp(await XArsivEngine.getStats(username));
    }

    // 2. /api/users
    if (path === '/api/users' && method === 'GET') {
      const users = await XArsivEngine.listUsers();
      return jsonResp(users.map(u => ({
        ...u,
        avatar_url: (u.avatar_url && u.avatar_url.startsWith('/media/')) ? (u.remote_avatar_url || '') : u.avatar_url
      })));
    }

    if (path === '/api/users' && method === 'POST') {
      const payload = JSON.parse(bodyText || '{}');
      try {
        const res = await XArsivEngine.addUser(payload.username);
        return jsonResp(res);
      } catch (e) {
        return jsonResp({ detail: e.message }, 400);
      }
    }

    // 3. DELETE /api/users/{username}
    let m = path.match(/^\/api\/users\/([^/]+)$/);
    if (m && method === 'DELETE') {
      const uname = decodeURIComponent(m[1]);
      await XArsivDB.deleteUserAndData(uname);
      chrome.runtime?.sendMessage?.({ type: 'REFRESH_BADGE' }).catch?.(() => {});
      return jsonResp({ status: 'ok' });
    }

    // 4. GET /api/user/{username}
    m = path.match(/^\/api\/user\/([^/]+)$/);
    if (m && method === 'GET') {
      const uname = decodeURIComponent(m[1]);
      const prof = await XArsivEngine.getUserProfile(uname);
      if (prof.error === 'not_found') return jsonResp({ detail: 'Kullanıcı bulunamadı' }, 404);
      if (prof.avatar_url && prof.avatar_url.startsWith('/media/')) {
        prof.avatar_url = prof.remote_avatar_url || '';
      }
      if (Array.isArray(prof.live_posts)) {
        prof.live_posts = prof.live_posts.map(normalizePostForExt);
      }
      return jsonResp(prof);
    }

    // 5. POST /api/user/{username}/deep-sync veya /fetch-older
    m = path.match(/^\/api\/user\/([^/]+)\/(deep-sync|fetch-older)$/);
    if (m && method === 'POST') {
      const uname = decodeURIComponent(m[1]);
      const cnt = await XArsivEngine.deepArchiveUser(uname, 20);
      return jsonResp({ status: 'ok', total: cnt });
    }

    // 6. GET /api/user/{username}/activity-prediction
    m = path.match(/^\/api\/user\/([^/]+)\/activity-prediction$/);
    if (m && method === 'GET') {
      const uname = decodeURIComponent(m[1]);
      const period = sp.get('period') || 'all';
      return jsonResp(await XArsivEngine.predictUserActivity(uname, period));
    }

    // 7. GET /api/user/{username}/relationships
    m = path.match(/^\/api\/user\/([^/]+)\/relationships$/);
    if (m && method === 'GET') {
      const uname = decodeURIComponent(m[1]);
      const type = sp.get('type') || 'followers';
      return jsonResp(await XArsivEngine.getUserRelationships(uname, type));
    }

    // 8. GET /api/posts
    if (path === '/api/posts' && method === 'GET') {
      const posts = await XArsivEngine.getPosts({
        username: sp.get('username'),
        filter_type: sp.get('filter_type') || 'all',
        search: sp.get('search') || '',
        limit: parseInt(sp.get('limit') || '20', 10),
        offset: parseInt(sp.get('offset') || '0', 10)
      });
      return jsonResp(posts.map(normalizePostForExt));
    }

    // 9. GET / DELETE /api/posts/{post_id}
    m = path.match(/^\/api\/posts\/([^/]+)$/);
    if (m && method === 'GET') {
      const p = await XArsivDB.getOne('posts', decodeURIComponent(m[1]));
      if (!p) return jsonResp({ detail: 'Bulunamadı' }, 404);
      return jsonResp(normalizePostForExt(p));
    }
    if (m && method === 'DELETE') {
      await XArsivDB.deleteOne('posts', decodeURIComponent(m[1]));
      chrome.runtime?.sendMessage?.({ type: 'REFRESH_BADGE' }).catch?.(() => {});
      return jsonResp({ status: 'ok' });
    }

    // 10. POST /api/refresh/{username}
    m = path.match(/^\/api\/refresh\/([^/]+)$/);
    if (m && method === 'POST') {
      const uname = decodeURIComponent(m[1]);
      await XArsivEngine.syncSingleUser(uname);
      chrome.runtime?.sendMessage?.({ type: 'REFRESH_BADGE' }).catch?.(() => {});
      return jsonResp({ status: 'ok' });
    }

    // 11. POST /api/refresh-all
    if (path === '/api/refresh-all' && method === 'POST') {
      const users = await XArsivEngine.listUsers();
      for (const u of users) {
        await XArsivEngine.syncSingleUser(u.username).catch(() => {});
      }
      chrome.runtime?.sendMessage?.({ type: 'REFRESH_BADGE' }).catch?.(() => {});
      return jsonResp({ status: 'ok' });
    }

    // 12. GET /api/trends
    if (path === '/api/trends' && method === 'GET') {
      return jsonResp(await XArsivEngine.fetchLiveTrends());
    }

    // 13. GET /api/search
    if (path === '/api/search' && method === 'GET') {
      const res = await XArsivEngine.searchX(sp.get('q') || '', sp.get('tab') || 'top');
      if (Array.isArray(res.posts)) res.posts = res.posts.map(normalizePostForExt);
      if (Array.isArray(res.results) && res.tab !== 'people') {
        res.results = res.results.map(item => (item && item.post_id ? normalizePostForExt(item) : item));
      }
      return jsonResp(res);
    }

    // 14. GET /api/tweet/{username}/{post_id}/comments
    m = path.match(/^\/api\/tweet\/([^/]+)\/([^/]+)\/comments$/);
    if (m && method === 'GET') {
      return jsonResp(await XArsivEngine.getTweetComments(decodeURIComponent(m[1]), decodeURIComponent(m[2])));
    }

    // 15. GET /api/tweet/{post_id}/video-url
    m = path.match(/^\/api\/tweet\/([^/]+)\/video-url$/);
    if (m && method === 'GET') {
      return jsonResp(await XArsivEngine.getTweetVideoUrl(decodeURIComponent(m[1])));
    }

    // 16. GET /api/logs
    if (path === '/api/logs' && method === 'GET') {
      const limit = parseInt(sp.get('limit') || '40', 10);
      const logs = await XArsivDB.getAll('activity_logs');
      logs.sort((a, b) => (b.id || 0) - (a.id || 0));
      return jsonResp(logs.slice(0, limit));
    }

    // 17. POST /api/clear-all-data
    if (path === '/api/clear-all-data' && method === 'POST') {
      await XArsivDB.clearAll();
      chrome.runtime?.sendMessage?.({ type: 'REFRESH_BADGE' }).catch?.(() => {});
      return jsonResp({ status: 'ok' });
    }

    // 18. POST /api/import-json
    if (path === '/api/import-json' && method === 'POST') {
      const parsed = JSON.parse(bodyText || '{}');
      const res = await XArsivDB.importBackupJson(parsed);
      chrome.runtime?.sendMessage?.({ type: 'REFRESH_BADGE' }).catch?.(() => {});
      return jsonResp({ status: 'ok', imported: res });
    }

    // 18. /export/json ve /export/csv
    if (path === '/export/json') {
      const payload = await XArsivEngine.buildExportJson();
      return jsonResp(payload);
    }
    if (path === '/export/csv') {
      const csv = await XArsivEngine.buildExportCsv();
      return new Response(csv, { status: 200, headers: { 'Content-Type': 'text/csv; charset=utf-8' } });
    }

    // 19. Medya optimizasyon ayarları (eklentide yerel disk indirme kapalıdır; tarayıcı tıkla-yükle ayarı kullanılır)
    if (path === '/api/media-settings') {
      return jsonResp({
        auto_download_media: false,
        is_extension: true,
        cache: {
          total_mb: 0,
          images_count: 0,
          videos_count: 0,
          avatars_count: 0
        }
      });
    }
    if (path === '/api/media-cache/clear' && method === 'POST') {
      return jsonResp({ status: 'ok', removed_files: 0, freed_mb: 0 });
    }

    return jsonResp({ status: 'error', detail: `Bilinmeyen rota: ${path}` }, 404);
  }

  window.fetch = async (input, init = {}) => {
    const rawUrl = typeof input === 'string' ? input : (input?.url || '');
    if (rawUrl.startsWith('/api/') || rawUrl.startsWith('/export/')) {
      const urlObj = new URL(rawUrl, 'https://ext.local');
      const method = (init.method || 'GET').toUpperCase();
      const bodyText = typeof init.body === 'string' ? init.body : '';
      return handleApiRequest(urlObj, method, bodyText);
    }
    return origFetch(input, init);
  };

  // Export ve JSON İçe Aktar bağlantıları
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('a[href="/export/csv"], a[href="/export/json"]').forEach(a => {
      a.addEventListener('click', async (e) => {
        e.preventDefault();
        const isJson = a.getAttribute('href') === '/export/json';
        if (isJson) {
          const data = await XArsivEngine.buildExportJson();
          const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const dl = document.createElement('a');
          dl.href = url;
          dl.download = 'x_arsiv_yedek.json';
          dl.click();
          setTimeout(() => URL.revokeObjectURL(url), 5000);
        } else {
          const csv = await XArsivEngine.buildExportCsv();
          const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
          const url = URL.createObjectURL(blob);
          const dl = document.createElement('a');
          dl.href = url;
          dl.download = 'x_arsiv_yedek.csv';
          dl.click();
          setTimeout(() => URL.revokeObjectURL(url), 5000);
        }
      });
    });

    // Dışa Aktar modalına 1-tık JSON Yedek İçe Aktarma butonu ekle (yerleşik yoksa)
    const exportLinksBox = document.querySelector('#exportModal .space-y-3');
    if (exportLinksBox && !document.getElementById('importJsonBtn') && !document.getElementById('extImportJsonBtn')) {
      const importBtn = document.createElement('button');
      importBtn.id = 'extImportJsonBtn';
      importBtn.type = 'button';
      importBtn.className = 'w-full py-3 px-4 rounded-xl border border-[#1d9bf0]/50 bg-[#1d9bf0]/10 hover:bg-[#1d9bf0]/20 flex items-center justify-between transition text-left';
      importBtn.innerHTML = '<div><div class="font-bold text-sm text-[#1d9bf0]">JSON Yedek İçe Aktar (.json)</div><div class="text-xs text-[#71767b]">Önceki SQLite/Python dışa aktarımını tarayıcıya yükle</div></div><i class="fa-solid fa-file-import text-[#1d9bf0]"></i>';
      const fileInp = document.createElement('input');
      fileInp.type = 'file';
      fileInp.accept = '.json,application/json';
      fileInp.className = 'hidden';
      importBtn.addEventListener('click', () => fileInp.click());
      fileInp.addEventListener('change', async () => {
        const f = fileInp.files?.[0];
        if (!f) return;
        try {
          const txt = await f.text();
          const parsed = JSON.parse(txt);
          const res = await XArsivDB.importBackupJson(parsed);
          if (typeof showToast === 'function') {
            showToast(`İçe aktarıldı: ${res.posts} gönderi, ${res.users} hesap`);
          }
          if (typeof loadAllData === 'function') await loadAllData();
          if (typeof closeExportModal === 'function') closeExportModal();
        } catch (err) {
          if (typeof showToast === 'function') showToast(`İçe aktarma hatası: ${err.message}`, true);
        }
        fileInp.value = '';
      });
      exportLinksBox.appendChild(importBtn);
      exportLinksBox.appendChild(fileInp);
    }

    // URL hash üzerinden belirli profile doğrudan açılış (#profile=kullanici)
    setTimeout(() => {
      const hash = window.location.hash || '';
      if (hash.startsWith('#profile=')) {
        const u = decodeURIComponent(hash.slice(9)).trim();
        if (u && typeof selectUserProfile === 'function') {
          selectUserProfile(u);
        }
      }
    }, 350);
  });

  if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.type === 'DATA_UPDATED' && typeof loadAllData === 'function') {
        loadAllData();
      }
    });
  }
})();
