// Popup & Side Panel kontrolcüsü (CSP uyumlu, sıfır inline handler)
document.addEventListener('DOMContentLoaded', () => {
  const statUsersEl = document.getElementById('statUsers');
  const statPostsEl = document.getElementById('statPosts');
  const statDeletedEl = document.getElementById('statDeleted');
  const usersListEl = document.getElementById('usersList');
  const statusEl = document.getElementById('popupStatus');
  const quickForm = document.getElementById('quickAddForm');
  const quickInput = document.getElementById('quickUserInput');
  const quickBtn = document.getElementById('quickAddBtn');
  const openDashBtn = document.getElementById('openDashboardBtn');
  const syncNowBtn = document.getElementById('syncNowBtn');
  const importBtn = document.getElementById('importJsonBtn');
  const importInput = document.getElementById('importJsonInput');
  const exportBtn = document.getElementById('exportJsonBtn');

  function setStatus(text, isError = false) {
    if (!statusEl) return;
    statusEl.textContent = text;
    statusEl.className = `text-[11px] text-center min-h-[16px] ${isError ? 'text-[#f4212e]' : 'text-[#00ba7c]'}`;
  }

  function esc(str) {
    return String(str ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  async function refreshView() {
    try {
      const [stats, users] = await Promise.all([
        XArsivEngine.getStats(),
        XArsivEngine.listUsers()
      ]);
      statUsersEl.textContent = Number(stats.total_users || 0).toLocaleString('tr-TR');
      statPostsEl.textContent = Number(stats.total_archived || 0).toLocaleString('tr-TR');
      statDeletedEl.textContent = Number(stats.total_deleted || 0).toLocaleString('tr-TR');

      if (!users.length) {
        usersListEl.innerHTML = '<div class="text-xs text-[#71767b] text-center py-6">Henüz takip edilen hesap yok. Yukarıdan ekleyin veya JSON yedek yükleyin.</div>';
        return;
      }

      usersListEl.innerHTML = '';
      for (const u of users) {
        const row = document.createElement('button');
        row.type = 'button';
        row.className = 'w-full flex items-center justify-between p-2 rounded-xl bg-[#16181c] border border-[#2f3336] hover:border-[#1d9bf0]/50 transition text-left';

        const left = document.createElement('div');
        left.className = 'flex items-center gap-2.5 min-w-0';

        const avSrc = (u.avatar_url && !u.avatar_url.startsWith('/media/')) ? u.avatar_url : (u.remote_avatar_url || '');
        if (avSrc) {
          const img = document.createElement('img');
          img.src = avSrc;
          img.referrerPolicy = 'no-referrer';
          img.className = 'w-8 h-8 rounded-full object-cover bg-[#2f3336] shrink-0';
          img.addEventListener('error', () => { img.style.display = 'none'; });
          left.appendChild(img);
        } else {
          const badge = document.createElement('div');
          badge.className = 'w-8 h-8 rounded-full bg-[#1d9bf0]/20 text-[#1d9bf0] flex items-center justify-center text-xs font-bold shrink-0';
          badge.textContent = (u.username[0] || 'X').toUpperCase();
          left.appendChild(badge);
        }

        const meta = document.createElement('div');
        meta.className = 'min-w-0';
        meta.innerHTML = `<div class="text-xs font-bold text-[#e7e9ea] truncate">${esc(u.display_name || u.username)}</div>
                          <div class="text-[11px] text-[#71767b] truncate">@${esc(u.username)} · ${u.archived_posts || 0} arşiv</div>`;
        left.appendChild(meta);

        const right = document.createElement('div');
        right.className = 'flex items-center gap-1.5 shrink-0';
        if (u.deleted_posts > 0) {
          const delBadge = document.createElement('span');
          delBadge.className = 'px-1.5 py-0.5 rounded-full bg-[#f4212e]/15 text-[#f4212e] text-[10px] font-bold';
          delBadge.textContent = `${u.deleted_posts} silinen`;
          right.appendChild(delBadge);
        }
        const arrow = document.createElement('i');
        arrow.className = 'fa-solid fa-chevron-right text-[10px] text-[#71767b]';
        right.appendChild(arrow);

        row.appendChild(left);
        row.appendChild(right);
        row.addEventListener('click', () => {
          chrome.runtime.sendMessage({ type: 'OPEN_DASHBOARD', hash: `profile=${encodeURIComponent(u.username)}` });
        });
        usersListEl.appendChild(row);
      }
    } catch (err) {
      setStatus(`Yükleme hatası: ${err.message}`, true);
    }
  }

  openDashBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'OPEN_DASHBOARD' });
  });

  quickForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const uname = quickInput.value.trim().replace(/^@/, '');
    if (!uname) return;
    quickBtn.disabled = true;
    quickBtn.textContent = '...';
    setStatus(`@${uname} çekiliyor...`);
    try {
      await XArsivEngine.addUser(uname);
      quickInput.value = '';
      setStatus(`@${uname} takip listesine eklendi!`);
      await refreshView();
    } catch (err) {
      setStatus(err.message || 'Eklenemedi', true);
    } finally {
      quickBtn.disabled = false;
      quickBtn.textContent = 'Ekle';
    }
  });

  syncNowBtn.addEventListener('click', () => {
    setStatus('Arka plan senkronizasyonu başlatıldı...');
    chrome.runtime.sendMessage({ type: 'SYNC_ALL' }, async (res) => {
      if (chrome.runtime.lastError) {
        setStatus(chrome.runtime.lastError.message, true);
        return;
      }
      setStatus(`Senkronize edildi (${res?.synced || 0} hesap)`);
      await refreshView();
    });
  });

  importBtn.addEventListener('click', () => importInput.click());
  importInput.addEventListener('change', async () => {
    const file = importInput.files?.[0];
    if (!file) return;
    try {
      const txt = await file.text();
      const json = JSON.parse(txt);
      const res = await XArsivDB.importBackupJson(json);
      setStatus(`İçe aktarıldı: ${res.posts} gönderi, ${res.users} hesap`);
      await refreshView();
    } catch (err) {
      setStatus(`JSON hatası: ${err.message}`, true);
    }
    importInput.value = '';
  });

  exportBtn.addEventListener('click', async () => {
    const data = await XArsivEngine.buildExportJson();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'x_arsiv_yedek.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    setStatus('Yedek indirildi.');
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'DATA_UPDATED') refreshView();
  });

  refreshView();
});
